<!-- SPDX-License-Identifier: GPL-2.0-or-later -->
# Standalone removal commands

The shared [installation backend](../../docs/INSTALLATION.md), invoked by Goodix
Manager or the optional source installer, installs complete copies of
`remove.py` as `/usr/local/bin/goodix-uninstall` and
`/usr/local/bin/goodix-force-remove`, with a receipt under
`/usr/local/share/goodix-recovery/`. Neither command imports code from the clone
or needs a build directory after installation. These copies are outside RPM
ownership and remain available if the Manager package is removed. The Manager's
**Remove** action uses this same ordinary removal path.

Normal removal verifies project-owned software. Emergency removal follows a
fixed inventory and tolerates missing receipts or partial installation. Both
remove authentication entry points before runtime files, quiesce fprintd during
runtime mutation and retain host pairing state and fingerprint templates.
Neither command accesses the reader. Fedora's current configuration is exposed
without restoring old vendor files.

Use [Uninstall and emergency recovery](../../docs/UNINSTALL.md) for the normal
command, console prompts, removal scope and final restart instruction.

The synthetic removal suite uses temporary fixtures and substitutes privileged
host operations:

```bash
python3 -B deployment/recovery/test_remove.py
```

It is an offline software check, not a hardware or Fedora authentication test.
