/* SPDX-License-Identifier: LGPL-2.1-or-later */
/* Strict inbound-only binding from decrypted post-TLS events to enrollment. */
#include "goodix_enrollment_post_tls_events.h"

#include <string.h>

#define GOODIX_IRQ80_PER_WAIT_LIMIT 2u

typedef enum
{
  GOODIX_ENROLLMENT_POST_TLS_ERROR_ARGUMENT,
  GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
  GOODIX_ENROLLMENT_POST_TLS_ERROR_FRAME,
  GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
  GOODIX_ENROLLMENT_POST_TLS_ERROR_UNUSABLE_CONTACT,
} GoodixEnrollmentPostTlsError;

#define GOODIX_ENROLLMENT_POST_TLS_ERROR \
  (goodix_enrollment_post_tls_error_quark ())

struct _GoodixEnrollmentPostTlsEvents
{
  GoodixEnrollmentLifecycleAdapter *lifecycle;
  GoodixEnrollmentPostTlsEventsAudit internal_audit;
  GoodixEnrollmentPostTlsEventsAudit *audit;
  GoodixEnrollmentAuxiliaryB0Func auxiliary_ready;
  GoodixEnrollmentContactFunc contact;
  gpointer contact_data;
  gpointer user_data;
  GByteArray *b0_pending;
  gboolean failed;
  gboolean zero_eligible;
  gboolean zero_enabled;
  GoodixZeroMaskRecoveryAudit zero;
  guint irq80_count;
  /* The enrollment graph stays at IRQ2 throughout this completion/ACK-gated
   * exception. Its command and material are separate from stage transitions. */
  GoodixEnrollmentEvent irq80_rearm_event;
  GoodixEnrollmentPreparedCommand irq80_rearm;
};

static void
clear_pending (GByteArray *pending)
{
  if (pending == NULL)
    return;
  for (gsize i = 0u; i < pending->len; i++)
    ((volatile guint8 *) pending->data)[i] = 0;
  g_byte_array_set_size (pending, 0u);
}

static GQuark
goodix_enrollment_post_tls_error_quark (void)
{
  return g_quark_from_static_string ("goodix-enrollment-post-tls-events-error");
}

gboolean
goodix_enrollment_post_tls_events_error_is_unusable_contact (const GError *error)
{
  return g_error_matches (error, GOODIX_ENROLLMENT_POST_TLS_ERROR,
                          GOODIX_ENROLLMENT_POST_TLS_ERROR_UNUSABLE_CONTACT);
}

static gboolean
events_fail (GoodixEnrollmentPostTlsEvents *events,
             GoodixEnrollmentPostTlsError   code,
             const gchar                   *message,
             GError                       **error)
{
  if (events != NULL && !events->failed)
    {
      events->failed = TRUE;
      events->irq80_rearm_event = GOODIX_ENROLLMENT_EVENT_NONE;
      goodix_enrollment_prepared_command_clear (&events->irq80_rearm);
      goodix_enrollment_post_tls_events_close_zero_window (events);
      events->audit->failed = TRUE;
      /* A valid unusable contact is not protocol corruption. Keep the
       * exported audit layout stable; its reason travels in the GError. */
      if (code != GOODIX_ENROLLMENT_POST_TLS_ERROR_UNUSABLE_CONTACT)
        events->audit->rejected_inbound_count++;
      clear_pending (events->b0_pending);
    }
  if (error == NULL || *error == NULL)
    g_set_error_literal (error, GOODIX_ENROLLMENT_POST_TLS_ERROR, code,
                         message);
  return FALSE;
}

GoodixEnrollmentPostTlsEvents *
goodix_enrollment_post_tls_events_new (
  const GoodixEnrollmentModelConfig  *config,
  GoodixEnrollmentImageFunc           image_ready,
  GoodixEnrollmentTimestampFunc       timestamp_ready,
  GoodixEnrollmentAuxiliaryB0Func     auxiliary_ready,
  gpointer                            user_data,
  GoodixEnrollmentPostTlsEventsAudit *audit,
  GError                            **error)
{
  GoodixEnrollmentPostTlsEvents *events;

  if (auxiliary_ready == NULL)
    {
      g_set_error_literal (error, GOODIX_ENROLLMENT_POST_TLS_ERROR,
                           GOODIX_ENROLLMENT_POST_TLS_ERROR_ARGUMENT,
                           "auxiliary B0 callback is required");
      return NULL;
    }
  events = g_new0 (GoodixEnrollmentPostTlsEvents, 1);
  events->zero_eligible = config != NULL &&
    config->defer_intermediate_stage_delivery_until_release_ready &&
    (config->defer_terminal_stage_delivery ||
     config->defer_terminal_stage_delivery_until_release_ready);
  events->audit = audit != NULL ? audit : &events->internal_audit;
  *events->audit = (GoodixEnrollmentPostTlsEventsAudit) { 0 };
  events->auxiliary_ready = auxiliary_ready;
  events->user_data = user_data;
  events->b0_pending = g_byte_array_sized_new (
    GOODIX_ENROLLMENT_B0_MAX_PLAINTEXT_LENGTH);
  events->lifecycle = goodix_enrollment_lifecycle_adapter_new (
    config, image_ready, timestamp_ready, user_data,
    &events->audit->lifecycle, error);
  if (events->lifecycle == NULL)
    {
      g_byte_array_unref (events->b0_pending);
      g_free (events);
      return NULL;
    }
  return events;
}

void
goodix_enrollment_post_tls_events_free (GoodixEnrollmentPostTlsEvents *events)
{
  if (events == NULL)
    return;
  if (events->zero.recovered_count != 0u)
    g_message ("GOODIX_ZERO_MASK_RECOVERY event=closed recovered=%u "
               "LATE_0200_COUNT=%u REARM32_COUNT=%u HIDDEN_RETRY=0",
               events->zero.recovered_count, events->zero.late_release_count,
               events->zero.rearm32_count);
  clear_pending (events->b0_pending);
  goodix_enrollment_prepared_command_clear (&events->irq80_rearm);
  g_byte_array_unref (events->b0_pending);
  goodix_enrollment_lifecycle_adapter_free (events->lifecycle);
  g_free (events);
}

gboolean
goodix_enrollment_post_tls_events_set_contact_callback (
  GoodixEnrollmentPostTlsEvents *events,
  GoodixEnrollmentContactFunc    contact,
  gpointer                       user_data,
  GError                       **error)
{
  if (events == NULL || contact == NULL || events->contact != NULL ||
      events->audit->parsed_a0_count != 0u || events->b0_pending->len != 0u ||
      events->failed)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "contact callback must be configured once before input",
                        error);
  events->contact = contact;
  events->contact_data = user_data;
  return TRUE;
}

static gboolean
expected_ack_echo (GoodixEnrollmentEvent expected,
                   guint8               *echo)
{
  switch (expected)
    {
    case GOODIX_ENROLLMENT_EVENT_ACK_20: *echo = 0x20; return TRUE;
    case GOODIX_ENROLLMENT_EVENT_ACK_22: *echo = 0x22; return TRUE;
    case GOODIX_ENROLLMENT_EVENT_ACK_32: *echo = 0x32; return TRUE;
    case GOODIX_ENROLLMENT_EVENT_ACK_34: *echo = 0x34; return TRUE;
    case GOODIX_ENROLLMENT_EVENT_ACK_36: *echo = 0x36; return TRUE;
    case GOODIX_ENROLLMENT_EVENT_ACK_50: *echo = 0x50; return TRUE;
    case GOODIX_ENROLLMENT_EVENT_NONE:
    case GOODIX_ENROLLMENT_EVENT_IRQ2:
    case GOODIX_ENROLLMENT_EVENT_COMMAND_22:
    case GOODIX_ENROLLMENT_EVENT_PRIMARY_B0:
    case GOODIX_ENROLLMENT_EVENT_COMMAND_34:
    case GOODIX_ENROLLMENT_EVENT_IRQ0200:
    case GOODIX_ENROLLMENT_EVENT_COMMAND_20:
    case GOODIX_ENROLLMENT_EVENT_AUXILIARY_B0:
    case GOODIX_ENROLLMENT_EVENT_COMMAND_32:
    case GOODIX_ENROLLMENT_EVENT_COMMAND_50:
    case GOODIX_ENROLLMENT_EVENT_NAV:
    case GOODIX_ENROLLMENT_EVENT_COMMAND_36:
    case GOODIX_ENROLLMENT_EVENT_IRQ0100:
    case GOODIX_ENROLLMENT_EVENT_ZERO_MASK_RECOVERY:
      return FALSE;
    }
  return FALSE;
}

static gboolean
parse_nav_no_check (GBytes *frame)
{
  const guint8 *data;
  gsize length;
  guint16 outer_length;
  guint16 inner_length;

  if (frame == NULL)
    return FALSE;
  data = g_bytes_get_data (frame, &length);
  if (length != 2417u || data[0] != 0xa0 || data[4] != 0x50)
    return FALSE;
  outer_length = (guint16) ((guint16) data[1] |
                            ((guint16) data[2] << 8));
  inner_length = (guint16) ((guint16) data[5] |
                            ((guint16) data[6] << 8));
  return outer_length == 2413u && inner_length == 2410u &&
         data[3] == (guint8) (data[0] + data[1] + data[2]) &&
         data[7] == 0x50 && data[8] == 0x01 && data[length - 1u] == 0x88;
}

static gboolean
parse_irq (const GoodixA0Message *message,
           guint8                 expected_control,
           guint16                expected_irq,
           GoodixFdtFlagsContext  flags_context,
           guint16               *touch_flags,
           const guint8         **raw)
{
  const guint8 *body;
  gsize length;
  guint16 irq;
  guint16 flags;

  if (message->control != expected_control)
    return FALSE;
  body = g_bytes_get_data (message->body, &length);
  if (length != 16u)
    return FALSE;
  irq = (guint16) ((guint16) body[0] | ((guint16) body[1] << 8));
  flags = (guint16) ((guint16) body[2] | ((guint16) body[3] << 8));
  if (irq != expected_irq ||
      !goodix_fdt_irq_flags_valid (flags_context, flags))
    return FALSE;
  *touch_flags = flags;
  *raw = body + 4u;
  return TRUE;
}

/* Only classify the observed repeated-contact signature after A0 checksum
 * validation. Conservative raw bounds forbid wrapping or truncation; no table is
 * derived or installed, and zero does not mean physical release. */
static gboolean
is_unusable_zero_contact (const GoodixA0Message *message)
{
  gsize length;
  const guint8 *body = g_bytes_get_data (message->body, &length);
  if (message->control != 0x36 || length != 16u ||
      body[0] != 0x00 || body[1] != 0x01 || body[2] != 0 || body[3] != 0)
    return FALSE;
  for (guint i = 0; i < GOODIX_FDT_CHANNEL_COUNT; i++)
    {
      guint value = ((guint) body[4u + 2u * i] |
                    ((guint) body[5u + 2u * i] << 8)) >> 1;
      if (value < 1u || value > 254u)
        return FALSE;
    }
  return TRUE;
}

void
goodix_enrollment_post_tls_events_enable_zero_recovery (
  GoodixEnrollmentPostTlsEvents *events)
{
  g_return_if_fail (events != NULL && !events->failed &&
                   events->audit->parsed_a0_count == 0u);
  events->zero_enabled = events->zero_eligible;
}

const GoodixZeroMaskRecoveryAudit *
goodix_enrollment_post_tls_events_zero_audit (const GoodixEnrollmentPostTlsEvents *events)
{
  return events != NULL ? &events->zero : NULL;
}

void
goodix_enrollment_post_tls_events_close_zero_window (GoodixEnrollmentPostTlsEvents *events)
{
  if (events == NULL)
    return;
  events->zero.stale_window_open = FALSE;
  events->zero.awaiting_sample_request = FALSE;
  events->zero.late_seen = FALSE;
}

gboolean
goodix_enrollment_post_tls_events_request_zero_sample (
  GoodixEnrollmentPostTlsEvents *events, GError **error)
{
  if (events == NULL || events->failed || !events->zero.awaiting_sample_request ||
      goodix_enrollment_post_tls_events_get_expected_event (events) !=
        GOODIX_ENROLLMENT_EVENT_COMMAND_32)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "zero-mask has no pending next-sample request", error);
  events->zero.awaiting_sample_request = FALSE;
  return TRUE;
}

gboolean
goodix_enrollment_post_tls_events_consume_stale_release (
  GoodixEnrollmentPostTlsEvents *events, GBytes *frame,
  gboolean *handled, GError **error)
{
  GoodixA0Message message = { 0 };
  gsize length;
  const guint8 *wire = frame != NULL ? g_bytes_get_data (frame, &length) : NULL;
  *handled = FALSE;
  if (events == NULL || events->failed || !events->zero.stale_window_open ||
      wire == NULL || length < 5u || wire[4] != 0x34)
    return TRUE;
  *handled = TRUE;
  if (!goodix_a0_parse_frame (frame, 0x34, &message, error))
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_FRAME,
                        "malformed late release in zero-mask window", error);
  /* Reuse exact zero/raw validation with the release's control and IRQ
   * checked separately; the immutable input frame is never rewritten. */
  gsize n;
  const guint8 *body = g_bytes_get_data (message.body, &n);
  gboolean valid = n == 16u && body[0] == 0 && body[1] == 2 &&
                   body[2] == 0 && body[3] == 0;
  for (guint i = 0; valid && i < GOODIX_FDT_CHANNEL_COUNT; i++)
    {
      guint value = ((guint) body[4u + 2u*i] | ((guint) body[5u + 2u*i] << 8)) >> 1;
      valid = value >= 1u && value <= 254u;
    }
  goodix_a0_message_clear (&message);
  if (!valid || events->zero.late_seen)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                        "invalid or duplicate late release in zero-mask window", error);
  events->zero.late_seen = TRUE;
  events->zero.late_release_count++;
  events->audit->parsed_a0_count++;
  g_message ("GOODIX_ZERO_MASK_RECOVERY event=late-release LATE_0200_COUNT=%u "
             "sample_delivery=0 stage_increment=0 response_out=0",
             events->zero.late_release_count);
  return TRUE;
}

static void
record_a0_mismatch (GoodixEnrollmentPostTlsEvents *events,
                    GoodixEnrollmentEvent          expected,
                    const GoodixA0Message          *message)
{
  const guint8 *body;
  gsize length;

  events->audit->last_mismatch_expected_event = expected;
  events->audit->last_mismatch_observed_control = message->control;
  events->audit->last_mismatch_observed_irq_classified = FALSE;
  events->audit->last_mismatch_observed_irq = 0u;
  events->audit->last_mismatch_observed_irq_flags = 0u;
  body = g_bytes_get_data (message->body, &length);
  if (length == 16u &&
      (message->control == 0x32 || message->control == 0x34 ||
       message->control == 0x36))
    {
      events->audit->last_mismatch_observed_irq_classified = TRUE;
      events->audit->last_mismatch_observed_irq = (guint16) (
        (guint16) body[0] | ((guint16) body[1] << 8));
      events->audit->last_mismatch_observed_irq_flags = (guint16) (
        (guint16) body[2] | ((guint16) body[3] << 8));
    }
}

/* Diagnostic classification only. The acceptance predicate remains parse_irq;
 * this runs after a frame has already been rejected and never advances it. */
static const gchar *
a0_mismatch_reason (GoodixEnrollmentEvent  expected,
                    const GoodixA0Message *message,
                    const gchar          **policy)
{
  guint8 control;
  guint16 irq;
  guint16 flags;
  const guint8 *body;
  gsize length;

  *policy = "expected-event";
  switch (expected)
    {
    case GOODIX_ENROLLMENT_EVENT_IRQ2:
      control = 0x32;
      irq = 0x0002;
      *policy = "finger-down-nonzero-subset-0x003f";
      break;
    case GOODIX_ENROLLMENT_EVENT_IRQ0100:
      control = 0x36;
      irq = 0x0100;
      *policy = "contact-sample-nonzero-subset-0x003f";
      break;
    case GOODIX_ENROLLMENT_EVENT_IRQ0200:
      control = 0x34;
      irq = 0x0200;
      *policy = "finger-up-zero";
      break;
    default:
      return expected_ack_echo (expected, &control) ? "ack-shape" : "state";
    }
  if (message->control != control)
    return "control";
  body = g_bytes_get_data (message->body, &length);
  if (length != 16u)
    return "body-length";
  if (((guint16) body[0] | ((guint16) body[1] << 8)) != irq)
    return "irq";
  flags = (guint16) ((guint16) body[2] | ((guint16) body[3] << 8));
  if ((flags & (guint16) ~GOODIX_FDT_TOUCH_MASK) != 0u)
    return "flags-reserved";
  return flags == 0u ? "flags-zero" : "flags-nonzero";
}

gboolean
goodix_enrollment_post_tls_events_handle_a0 (
  GoodixEnrollmentPostTlsEvents *events,
  GBytes                        *frame,
  GError                       **error)
{
  GoodixEnrollmentEvent expected;
  GoodixA0Message message = { 0 };
  const guint8 *data;
  const guint8 *body;
  const guint8 *raw = NULL;
  gsize frame_length;
  gsize body_length;
  guint8 echo = 0u;
  guint16 touch_flags = 0u;
  gboolean accepted = FALSE;
  gboolean frame_matches_expected = FALSE;

  if (events == NULL || frame == NULL)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_ARGUMENT,
                        "post-TLS event adapter or frame is absent", error);
  if (events->failed || events->b0_pending->len != 0u)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "post-TLS event adapter is terminal", error);
  expected = goodix_enrollment_post_tls_events_get_expected_event (events);
  if (expected == GOODIX_ENROLLMENT_EVENT_NAV)
    {
      if (!parse_nav_no_check (frame))
        return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_FRAME,
                            "OEM NAV no-check frame mismatch", error);
      frame_matches_expected = TRUE;
      accepted = goodix_enrollment_lifecycle_adapter_observe (
        events->lifecycle, expected, NULL, 0u, NULL, 0u, 0u, error);
      if (accepted)
        {
          events->audit->parsed_a0_count++;
          events->audit->nav_count++;
        }
      goto out;
    }

  data = g_bytes_get_data (frame, &frame_length);
  if (frame_length < 5u ||
      !goodix_a0_parse_frame (frame, data[4], &message, error))
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_FRAME,
                        "decrypted A0 frame is malformed", error);
  events->audit->parsed_a0_count++;
  body = g_bytes_get_data (message.body, &body_length);

  if (expected == GOODIX_ENROLLMENT_EVENT_IRQ2 &&
      message.control == 0x32 && body_length == 16u &&
      body[0] == 0x80 && body[1] == 0u &&
      (body[2] & (guint8) ~GOODIX_FDT_TOUCH_MASK) == 0u && body[3] == 0u)
    {
      GoodixEnrollmentPreparedCommand rearm = { 0 };

      if (events->irq80_count >= GOODIX_IRQ80_PER_WAIT_LIMIT)
        {
          goodix_a0_message_clear (&message);
          g_message ("GOODIX_IRQ80 path=enrollment event=reject reason=limit count=%u contacts=%u",
                     events->irq80_count,
                     events->audit->lifecycle.plan.pipeline.protocol.observed_primary_stage_count);
          return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                              "Goodix enrollment IRQ0080 limit exceeded while waiting for IRQ2", error);
        }
      if (!goodix_enrollment_lifecycle_adapter_prepare_irq80_rearm (
            events->lifecycle, body + 4u, &rearm, error))
        {
          goodix_a0_message_clear (&message);
          return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                              "Goodix IRQ0080 rearm preparation failed", error);
        }
      events->irq80_rearm = rearm;
      events->irq80_rearm_event = GOODIX_ENROLLMENT_EVENT_COMMAND_32;
      events->irq80_count++;
      g_message ("GOODIX_IRQ80 path=enrollment event=rearm count=%u contacts=%u",
                 events->irq80_count,
                 events->audit->lifecycle.plan.pipeline.protocol.observed_primary_stage_count);
      goodix_a0_message_clear (&message);
      return TRUE;
    }

  if (expected_ack_echo (expected, &echo))
    {
      if (message.control != 0xb0 || body_length != 2u ||
          body[0] != echo || body[1] != 0x01)
        goto out;
      frame_matches_expected = TRUE;
      if (events->irq80_rearm_event == GOODIX_ENROLLMENT_EVENT_ACK_32)
        {
          events->irq80_rearm_event = GOODIX_ENROLLMENT_EVENT_NONE;
          goodix_enrollment_prepared_command_clear (&events->irq80_rearm);
          accepted = TRUE;
          g_message ("GOODIX_IRQ80 path=enrollment event=ack32 count=%u",
                     events->irq80_count);
        }
      else
        accepted = goodix_enrollment_lifecycle_adapter_observe (
          events->lifecycle, expected, NULL, 0u, NULL, 0u, 0u, error);
      if (accepted)
        events->audit->ack_count++;
    }
  else if (expected == GOODIX_ENROLLMENT_EVENT_IRQ2 &&
           parse_irq (&message, 0x32, 0x0002,
                      GOODIX_FDT_FLAGS_FINGER_DOWN, &touch_flags, &raw))
    {
      frame_matches_expected = TRUE;
      accepted = goodix_enrollment_lifecycle_adapter_observe (
        events->lifecycle, expected, NULL, 0u, raw, 12u, touch_flags, error);
      if (accepted)
        {
          events->zero.stale_window_open = FALSE;
          events->zero.late_seen = FALSE;
          events->audit->irq2_count++;
          if (events->contact != NULL &&
              !events->contact (events->audit->irq2_count, TRUE,
                                events->contact_data, error))
            accepted = FALSE;
          else if (events->contact != NULL)
            events->audit->finger_down_delivery_count++;
          if (accepted)
            events->irq80_count = 0u;
        }
    }
  else if (expected == GOODIX_ENROLLMENT_EVENT_IRQ0100 &&
           is_unusable_zero_contact (&message))
    {
      const GoodixEnrollmentModelAudit *p = &events->audit->lifecycle.plan.pipeline.protocol;
      if (events->zero_enabled && !events->zero.stale_window_open &&
          p->observed_primary_stage_count >= 2u &&
          p->observed_primary_stage_count == p->completed_stage_count + p->retry_stage_count + 1u)
        {
          frame_matches_expected = TRUE;
          accepted = goodix_enrollment_lifecycle_adapter_observe (
            events->lifecycle, GOODIX_ENROLLMENT_EVENT_ZERO_MASK_RECOVERY,
            NULL, 0u, body + 4u, 12u, 0u, error);
          if (accepted)
            {
              events->audit->irq0100_count++;
              events->zero.recovered_count++;
              events->zero.stale_window_open =
                !goodix_enrollment_lifecycle_adapter_is_complete (events->lifecycle);
              events->zero.awaiting_sample_request = events->zero.stale_window_open;
              events->zero.late_seen = FALSE;
              if (events->contact != NULL)
                {
                  accepted = events->contact (p->observed_primary_stage_count,
                    FALSE, events->contact_data, error);
                  if (accepted)
                    events->audit->finger_up_delivery_count++;
                }
              g_message ("GOODIX_ZERO_MASK_RECOVERY event=sample ZERO_MASK_RECOVERY=1 "
                         "contact=%u PRIMARY_PRESERVED=1 OPTIONAL_20_SENT=0 AUX_B0_COUNT=0 "
                         "FINAL_AUX_34_SENT=0 HIDDEN_RETRY=0 terminal=%u",
                         p->observed_primary_stage_count, (guint) !events->zero.stale_window_open);
            }
          goto out;
        }
      goodix_a0_message_clear (&message);
      /* Keep the pending primary undelivered. Returning FALSE freezes the
       * transaction before graph-ready submission; the owner cancels/drains. */
      return events_fail (
        events, GOODIX_ENROLLMENT_POST_TLS_ERROR_UNUSABLE_CONTACT,
        "Goodix zero-mask contact unusable: no active touch channels in the "
        "enrollment contact sample. Enrollment stopped safely; no sample saved "
        "for this contact. Start a new enrollment manually after closing this "
        "attempt, keeping the finger centered and steady.", error);
    }
  else if (expected == GOODIX_ENROLLMENT_EVENT_IRQ0100 &&
           parse_irq (&message, 0x36, 0x0100,
                      GOODIX_FDT_FLAGS_CONTACT_SAMPLE, &touch_flags, &raw))
    {
      frame_matches_expected = TRUE;
      accepted = goodix_enrollment_lifecycle_adapter_observe (
        events->lifecycle, expected, NULL, 0u, NULL, 0u, 0u, error);
      if (accepted)
        events->audit->irq0100_count++;
    }
  else if (expected == GOODIX_ENROLLMENT_EVENT_IRQ0200 &&
           parse_irq (&message, 0x34, 0x0200,
                      GOODIX_FDT_FLAGS_FINGER_UP, &touch_flags, &raw))
    {
      frame_matches_expected = TRUE;
      accepted = goodix_enrollment_lifecycle_adapter_observe (
        events->lifecycle, expected, NULL, 0u, raw, 12u, touch_flags, error);
      if (accepted)
        {
          events->audit->irq0200_count++;
          if (events->contact != NULL &&
              !events->contact (events->audit->irq0200_count, FALSE,
                                events->contact_data, error))
            accepted = FALSE;
          else if (events->contact != NULL)
            events->audit->finger_up_delivery_count++;
        }
    }

out:
  if (!accepted && !frame_matches_expected)
    {
      const GoodixEnrollmentModelAudit *protocol =
        &events->audit->lifecycle.plan.pipeline.protocol;
      const gchar *policy;
      const gchar *reason = a0_mismatch_reason (expected, &message, &policy);
      /* Metadata balance: an observed primary has not yet been accounted for
       * as a completed or retried stage. This does not inspect image memory. */
      gboolean pending_primary = protocol->observed_primary_stage_count >
        protocol->completed_stage_count + protocol->retry_stage_count;

      record_a0_mismatch (events, expected, &message);
      if (error != NULL && *error == NULL)
        {
          if (events->audit->last_mismatch_observed_irq_classified)
            g_set_error (
              error, GOODIX_ENROLLMENT_POST_TLS_ERROR,
              GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
              "A0 mismatch: expected %s, observed control 0x%02x IRQ 0x%04x flags 0x%04x; "
              "decision=reject reason=%s policy=%s contacts=%u stages=%u pending_primary=%u",
              goodix_enrollment_event_name (expected), message.control,
              events->audit->last_mismatch_observed_irq,
              events->audit->last_mismatch_observed_irq_flags,
              reason, policy, protocol->observed_primary_stage_count,
              protocol->completed_stage_count, (guint) pending_primary);
          else
            g_set_error (
              error, GOODIX_ENROLLMENT_POST_TLS_ERROR,
              GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
              "A0 mismatch: expected %s, observed control 0x%02x (not classified as IRQ); "
              "decision=reject reason=%s policy=%s contacts=%u stages=%u pending_primary=%u",
              goodix_enrollment_event_name (expected), message.control,
              reason, policy, protocol->observed_primary_stage_count,
              protocol->completed_stage_count, (guint) pending_primary);
        }
    }
  goodix_a0_message_clear (&message);
  if (!accepted)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                        "A0 frame does not match the expected enrollment event",
                        error);
  return TRUE;
}

gboolean
goodix_enrollment_post_tls_events_handle_primary_samples (
  GoodixEnrollmentPostTlsEvents *events,
  const uint16_t                *samples,
  size_t                         sample_count,
  GError                       **error)
{
  if (events == NULL || events->failed || events->b0_pending->len != 0u)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "post-TLS event adapter is absent or terminal", error);
  if (!goodix_enrollment_lifecycle_adapter_observe (
        events->lifecycle, GOODIX_ENROLLMENT_EVENT_PRIMARY_B0,
        samples, sample_count, NULL, 0u, 0u, error))
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                        "primary B0 samples are unexpected", error);
  events->audit->primary_b0_count++;
  return TRUE;
}

gboolean
goodix_enrollment_post_tls_events_handle_auxiliary_b0 (
  GoodixEnrollmentPostTlsEvents *events,
  GError                       **error)
{
  if (events == NULL || events->failed || events->b0_pending->len != 0u)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "post-TLS event adapter is absent or terminal", error);
  if (!goodix_enrollment_lifecycle_adapter_observe (
        events->lifecycle, GOODIX_ENROLLMENT_EVENT_AUXILIARY_B0,
        NULL, 0u, NULL, 0u, 0u, error))
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                        "auxiliary B0 is unexpected", error);
  events->audit->auxiliary_b0_count++;
  return TRUE;
}

gboolean
goodix_enrollment_post_tls_events_handle_plaintext_chunk (
  GoodixEnrollmentPostTlsEvents *events,
  GBytes                        *chunk,
  GError                       **error)
{
  GoodixEnrollmentEvent expected;
  const guint8 *data;
  gsize length;
  guint16 declared_length;
  gsize expected_length;
  g_autoptr(GBytes) complete = NULL;
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  GoodixImageDecodeAudit decode_audit;
  gboolean accepted;

  if (events == NULL || chunk == NULL)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_ARGUMENT,
                        "post-TLS event adapter or plaintext chunk is absent",
                        error);
  if (events->failed)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "post-TLS event adapter is terminal", error);
  expected = goodix_enrollment_post_tls_events_get_expected_event (events);
  if (expected != GOODIX_ENROLLMENT_EVENT_PRIMARY_B0 &&
      expected != GOODIX_ENROLLMENT_EVENT_AUXILIARY_B0)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "plaintext arrived outside an enrollment B0 slot",
                        error);
  data = g_bytes_get_data (chunk, &length);
  if (length == 0u ||
      length > GOODIX_ENROLLMENT_B0_MAX_PLAINTEXT_LENGTH ||
      events->b0_pending->len >
        GOODIX_ENROLLMENT_B0_MAX_PLAINTEXT_LENGTH - length)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_FRAME,
                        "B0 plaintext reassembly exceeds its bound", error);
  g_byte_array_append (events->b0_pending, data, (guint) length);
  events->audit->plaintext_chunk_count++;
  if (events->b0_pending->len < 3u)
    return TRUE;
  declared_length = (guint16) (
    (guint16) events->b0_pending->data[1] |
    ((guint16) events->b0_pending->data[2] << 8));
  expected_length = (gsize) declared_length + 3u;
  if (declared_length == 0u ||
      expected_length > GOODIX_ENROLLMENT_B0_MAX_PLAINTEXT_LENGTH ||
      (expected == GOODIX_ENROLLMENT_EVENT_PRIMARY_B0 &&
       expected_length != GOODIX_IMAGE_PLAINTEXT_LENGTH) ||
      events->b0_pending->len > expected_length)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_FRAME,
                        "B0 plaintext declared length is invalid", error);
  if (events->b0_pending->len < expected_length)
    return TRUE;

  complete = g_bytes_new (events->b0_pending->data,
                          events->b0_pending->len);
  events->audit->completed_b0_message_count++;
  if (expected == GOODIX_ENROLLMENT_EVENT_PRIMARY_B0)
    {
      if (!goodix_image_decode_plaintext (complete, samples, &decode_audit,
                                          error))
        {
          clear_pending (events->b0_pending);
          memset (samples, 0, sizeof samples);
          return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_FRAME,
                              "primary B0 image decode failed", error);
        }
      events->audit->primary_b0_decode_count++;
      /* The complete message is independently owned by @complete. */
      clear_pending (events->b0_pending);
      accepted = goodix_enrollment_post_tls_events_handle_primary_samples (
        events, samples, G_N_ELEMENTS (samples), error);
      memset (samples, 0, sizeof samples);
    }
  else
    {
      accepted = events->auxiliary_ready (complete, events->user_data, error);
      if (accepted)
        {
          events->audit->auxiliary_b0_delivery_count++;
          /* Clear before the lower-level typed call, whose direct API rejects
           * partially assembled plaintext. */
          clear_pending (events->b0_pending);
          accepted = goodix_enrollment_post_tls_events_handle_auxiliary_b0 (
            events, error);
          return accepted || events_fail (
            events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
            "auxiliary B0 lifecycle delivery failed", error);
        }
    }
  clear_pending (events->b0_pending);
  if (!accepted)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                        "complete B0 delivery failed", error);
  return TRUE;
}

gboolean
goodix_enrollment_post_tls_events_prepare (
  GoodixEnrollmentPostTlsEvents    *events,
  GoodixEnrollmentPreparedCommand *prepared,
  GError                          **error)
{
  if (events == NULL || events->failed || events->b0_pending->len != 0u ||
      events->zero.awaiting_sample_request)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "post-TLS event adapter is absent or terminal", error);
  if (events->irq80_rearm_event == GOODIX_ENROLLMENT_EVENT_COMMAND_32)
    {
      if (prepared == NULL)
        return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_ARGUMENT,
                            "IRQ0080 prepared-command output is absent", error);
      *prepared = events->irq80_rearm;
      return TRUE;
    }
  if (!goodix_enrollment_lifecycle_adapter_prepare (
        events->lifecycle, prepared, error))
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                        "enrollment command preparation failed", error);
  return TRUE;
}

gboolean
goodix_enrollment_post_tls_events_commit (
  GoodixEnrollmentPostTlsEvents *events,
  GoodixEnrollmentEvent          command_event,
  GError                       **error)
{
  if (events == NULL || events->failed || events->b0_pending->len != 0u)
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                        "post-TLS event adapter is absent or terminal", error);
  if (events->irq80_rearm_event != GOODIX_ENROLLMENT_EVENT_NONE)
    {
      if (events->irq80_rearm_event != GOODIX_ENROLLMENT_EVENT_COMMAND_32 ||
          command_event != GOODIX_ENROLLMENT_EVENT_COMMAND_32)
        return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_STATE,
                            "IRQ0080 rearm completion is unexpected", error);
      events->irq80_rearm_event = GOODIX_ENROLLMENT_EVENT_ACK_32;
      return TRUE;
    }
  if (!goodix_enrollment_lifecycle_adapter_commit (
        events->lifecycle, command_event, error))
    return events_fail (events, GOODIX_ENROLLMENT_POST_TLS_ERROR_EVENT,
                        "enrollment command commit failed", error);
  if (command_event == GOODIX_ENROLLMENT_EVENT_COMMAND_32 &&
      events->zero.stale_window_open)
    {
      events->zero.rearm32_count++;
      g_message ("GOODIX_ZERO_MASK_RECOVERY event=rearm REARM32_COUNT=%u HIDDEN_RETRY=0",
                 events->zero.rearm32_count);
    }
  return TRUE;
}

GoodixEnrollmentEvent
goodix_enrollment_post_tls_events_get_expected_event (
  const GoodixEnrollmentPostTlsEvents *events)
{
  return events != NULL && !events->failed ?
    (events->irq80_rearm_event != GOODIX_ENROLLMENT_EVENT_NONE ?
     events->irq80_rearm_event :
     goodix_enrollment_lifecycle_adapter_get_expected_event (events->lifecycle)) :
    GOODIX_ENROLLMENT_EVENT_NONE;
}

gboolean
goodix_enrollment_post_tls_events_is_complete (
  const GoodixEnrollmentPostTlsEvents *events)
{
  return events != NULL && !events->failed &&
    goodix_enrollment_lifecycle_adapter_is_complete (events->lifecycle);
}

gboolean
goodix_enrollment_post_tls_events_is_failed (
  const GoodixEnrollmentPostTlsEvents *events)
{
  return events == NULL || events->failed ||
    goodix_enrollment_lifecycle_adapter_is_failed (events->lifecycle);
}
