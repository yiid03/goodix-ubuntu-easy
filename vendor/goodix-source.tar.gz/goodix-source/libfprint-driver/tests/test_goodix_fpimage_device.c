/* SPDX-License-Identifier: LGPL-2.1-or-later */
/*
 * Host-only deterministic tests for the Goodix FpImageDevice shell.
 *
 * These tests exercise the real repository-local libfprint 1.94.100 FpImageDevice
 * state machine through public async actions, with an in-memory fake backend.
 */
#include "../goodix_fpimage_device.h"
#include "../goodix_a0_protocol.h"
#include "../goodix_pairing_crypto.h"
#include "../goodix_pairing_activation.h"
#include "../goodix_enrollment_fpi_usb_binding.h"
#include "../goodix_enrollment_post_tls_events.h"
#include "../goodix_fpi_usb_backend.h"
#include "../goodix_usb_router.h"
#include "../goodix_u16_to_fpimage.h"

#include "test_sigfm_control.h"

#include "fpi-image-device.h"
#include "fp-device.h"
#include "fp-image-device.h"
#include "fp-print.h"

#include <glib.h>
#include <glib/gstdio.h>
#include <openssl/evp.h>
#include <openssl/ssl.h>
#include <string.h>
#include <unistd.h>

#define TEST_TIMEOUT_MS 5000

void  goodix_test_gusb_reset_counts (void);
guint goodix_test_gusb_get_open_count (void);
guint goodix_test_gusb_get_close_count (void);
void  goodix_test_gusb_set_open_close_success (gboolean value);

typedef struct
{
  GMainLoop            *loop;
  GoodixFpImageDevice  *device;
  GoodixDeviceContext  *ctx;
  FpiImageDeviceState   last_state;

  gboolean              done;
  gboolean              timed_out;
  guint                 completion_count;
  gboolean              success;
  GError               *error;
  FpImage              *capture_image;
  FpPrint              *enroll_print;
  guint                 enroll_progress_count;
} TestFixture;

static void
host_only_usb_submit (GoodixFpiUsbBackend *backend,
                      GoodixUsbDirection   direction,
                      guint64              generation,
                      GBytes              *bytes,
                      gpointer             user_data)
{
  (void) backend;
  (void) direction;
  (void) generation;
  (void) bytes;
  (void) user_data;
}

static void
state_changed_cb (FpImageDevice      *dev,
                  FpiImageDeviceState  state,
                  gpointer             user_data)
{
  TestFixture *f = user_data;

  (void) dev;
  f->last_state = state;
}

static TestFixture *
test_fixture_new_with_device (GoodixFpImageDevice *device)
{
  TestFixture *f;

  f = g_new0 (TestFixture, 1);
  f->loop = g_main_loop_new (NULL, FALSE);
  f->device = device;
  f->ctx = goodix_fpimage_device_get_context (f->device);
  g_signal_connect (f->device, "fpi-image-device-state-changed",
                    G_CALLBACK (state_changed_cb), f);

  return f;
}

static TestFixture *
test_fixture_new (void)
{
  return test_fixture_new_with_device (goodix_fpimage_device_new ());
}

static void
test_fixture_free (TestFixture *f)
{
  if (f == NULL)
    return;

  g_print ("DEBUG fixture_free capture_image=%p device=%p loop=%p\n",
           f->capture_image, f->device, f->loop);
  g_clear_object (&f->capture_image);
  g_clear_object (&f->enroll_print);
  g_clear_error (&f->error);
  g_clear_object (&f->device);
  if (f->loop)
    g_main_loop_unref (f->loop);
  g_free (f);
}

static gboolean
test_timeout_cb (gpointer user_data)
{
  TestFixture *f = user_data;

  f->done = TRUE;
  f->timed_out = TRUE;
  f->success = FALSE;
  g_main_loop_quit (f->loop);
  return G_SOURCE_REMOVE;
}

static void
test_wait (TestFixture *f)
{
  guint timeout_id;

  if (f->done)
    return;
  f->timed_out = FALSE;
  timeout_id = g_timeout_add (TEST_TIMEOUT_MS, test_timeout_cb, f);
  g_main_loop_run (f->loop);
  if (!f->timed_out)
    g_source_remove (timeout_id);
  g_assert_false (f->timed_out);
}

static void
test_complete (TestFixture *f)
{
  f->done = TRUE;
  f->completion_count++;
  g_main_loop_quit (f->loop);
}

static void
open_cb (FpDevice *device, GAsyncResult *res, gpointer user_data)
{
  TestFixture *f = user_data;

  f->success = fp_device_open_finish (device, res, &f->error);
  test_complete (f);
}

static void
close_cb (FpDevice *device, GAsyncResult *res, gpointer user_data)
{
  TestFixture *f = user_data;

  f->success = fp_device_close_finish (device, res, &f->error);
  test_complete (f);
}

static void
capture_cb (FpDevice *device, GAsyncResult *res, gpointer user_data)
{
  TestFixture *f = user_data;

  f->capture_image = fp_device_capture_finish (device, res, &f->error);
  g_print ("DEBUG capture_cb image=%p error=%p\n", f->capture_image, f->error);
  f->success = (f->error == NULL);
  test_complete (f);
}

static void
enroll_cb (FpDevice *device, GAsyncResult *res, gpointer user_data)
{
  TestFixture *f = user_data;

  f->enroll_print = fp_device_enroll_finish (device, res, &f->error);
  f->success = (f->error == NULL);
  test_complete (f);
}

static void
identify_cb (FpDevice *device, GAsyncResult *res, gpointer user_data)
{
  TestFixture *f = user_data;
  g_autoptr(FpPrint) match = NULL;
  g_autoptr(FpPrint) print = NULL;

  f->success = fp_device_identify_finish (device, res, &match, &print,
                                           &f->error);
  test_complete (f);
}

static void
progress_cb (FpDevice     *device,
             gint          completed_stages,
             FpPrint      *print,
             gpointer      user_data,
             GError       *error)
{
  TestFixture *f = user_data;

  (void) device;
  (void) completed_stages;
  (void) print;
  (void) error;

  f->enroll_progress_count++;
}

static void
fixture_open (TestFixture *f)
{
  f->done = FALSE;
  f->completion_count = 0;
  fp_device_open (FP_DEVICE (f->device), NULL, (GAsyncReadyCallback) open_cb, f);
  test_wait (f);
  g_assert_true (f->success);
  g_assert_cmpuint (f->completion_count, ==, 1);
  f->ctx = goodix_fpimage_device_get_context (f->device);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
  f->completion_count = 0;
}

static void
fixture_close (TestFixture *f)
{
  f->done = FALSE;
  f->completion_count = 0;
  fp_device_close (FP_DEVICE (f->device), NULL, (GAsyncReadyCallback) close_cb, f);
  test_wait (f);
  g_assert_true (f->success);
}

static void
fill_gradient_samples (uint16_t *samples)
{
  size_t i;

  for (i = 0; i < GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT; i++)
    samples[i] = (uint16_t) (i % (GOODIX_SENSOR_SAMPLE_MAX + 1));
}

static gboolean
d279_20_image_ready (GoodixEnrollmentPipeline *pipeline,
                     guint                     stage_index,
                     FpImage                  *image,
                     gpointer                  user_data,
                     GError                  **error)
{
  (void) pipeline;
  (void) stage_index;
  (void) image;
  (void) user_data;
  (void) error;
  return TRUE;
}

static gboolean
d279_20_timestamp_ready (guint                           stage_index,
                         GoodixEnrollmentCommandPurpose purpose,
                         guint16                        *timestamp,
                         gpointer                        user_data,
                         GError                        **error)
{
  (void) stage_index;
  (void) purpose;
  (void) user_data;
  (void) error;
  *timestamp = 0x3000u;
  return TRUE;
}

static gboolean
d279_20_auxiliary_ready (GBytes   *plaintext,
                         gpointer  user_data,
                         GError  **error)
{
  (void) plaintext;
  (void) user_data;
  (void) error;
  return TRUE;
}

static GBytes *
d279_20_build_irq2 (void)
{
  guint8 body[16] = { 0x02, 0x00, 0x3f, 0x00 };
  g_autoptr(GError) error = NULL;
  GBytes *frame;

  for (guint i = 0u; i < 6u; i++)
    {
      guint16 word = (guint16) (0x88u + i * 2u);

      body[4u + i * 2u] = (guint8) word;
      body[5u + i * 2u] = (guint8) (word >> 8);
    }
  frame = goodix_a0_build_frame (0x32, 0x32, body, sizeof body, &error);
  g_assert_no_error (error);
  g_assert_nonnull (frame);
  return frame;
}

/* -------------------------------------------------------------
 * 7.1 Base lifecycle (capture)
 * ------------------------------------------------------------- */
static void
test_lifecycle_base_capture (void)
{
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  TestFixture *f = test_fixture_new ();

  fixture_open (f);

  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);

  /* Activate -> fake arm -> activate complete -> AWAIT_FINGER_ON. */
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING);
  g_assert_cmpuint (goodix_in_memory_backend_get_arm_count (f->ctx), ==, 1);

  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_ACTIVE);
  g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON);

  goodix_device_context_emit_finger_down (f->ctx);
  g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_CAPTURE);

  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);
  g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_OFF);

  goodix_device_context_emit_release_tail_complete (f->ctx);
  g_assert_true (goodix_device_context_get_release_tail_complete (f->ctx));

  goodix_device_context_emit_finger_up_ready (f->ctx);

  test_wait (f);
  g_assert_true (f->success);
  g_assert_cmpuint (f->completion_count, ==, 1);
  g_assert_nonnull (f->capture_image);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);

  fixture_close (f);
  test_fixture_free (f);
}

/* -------------------------------------------------------------
 * 7.2 Reentrancy: NON_ENROLL_FINGER_OFF_SYNCHRONOUS_DEACTIVATE
 * ------------------------------------------------------------- */
static void
test_non_enroll_finger_off_synchronous_deactivate (void)
{
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  TestFixture *f = test_fixture_new ();
  guint commands_before_deactivate;

  fixture_open (f);

  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

  commands_before_deactivate =
    goodix_device_context_get_backend_command_count (f->ctx);

  goodix_device_context_emit_release_tail_complete (f->ctx);
  goodix_device_context_emit_finger_up_ready (f->ctx);

  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
  g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));

  test_wait (f);

  /* No new fake backend command after the finger-off report. */
  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_before_deactivate + 1 /* disarm */);
  g_assert_cmpstr (goodix_in_memory_backend_get_last_command (f->ctx), ==,
                   "disarm");

  fixture_close (f);
  test_fixture_free (f);
}

/* -------------------------------------------------------------
 * 7.2 Reentrancy helpers for enrollment ordering
 * ------------------------------------------------------------- */
static void
run_enroll_cycle (TestFixture *f,
                  gboolean     block_minutiae,
                  gboolean     minutiae_done_before_finger_off)
{
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = fp_print_new (FP_DEVICE (f->device));
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];

  fill_gradient_samples (samples);

  f->enroll_progress_count = 0;
  goodix_test_sigfm_extract_set_block (block_minutiae);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template), cancellable,
                    progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);

  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

  if (minutiae_done_before_finger_off)
    {
      /* Wait for the host-only SIGFM double to report minutiae completion. */
      while (f->enroll_progress_count == 0)
        g_main_context_iteration (NULL, TRUE);
    }

  goodix_device_context_set_fresh_down_table (f->ctx, TRUE);
  goodix_device_context_emit_release_tail_complete (f->ctx);
  goodix_device_context_emit_finger_up_ready (f->ctx);

  if (block_minutiae)
    {
      gint64 deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;

      while (!goodix_test_sigfm_extract_is_blocked () &&
             g_get_monotonic_time () < deadline)
        g_main_context_iteration (NULL, FALSE);
      g_assert_true (goodix_test_sigfm_extract_is_blocked ());
      /* With minutiae still pending, re-arm must not happen yet. */
      g_assert_cmpuint (goodix_in_memory_backend_get_rearm_count (f->ctx), ==, 0);
      goodix_test_sigfm_extract_unblock ();
      /* Drain the GTask completion for minutiae extraction. */
      while (f->last_state != FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON)
        g_main_context_iteration (NULL, TRUE);
    }

  g_assert_cmpuint (goodix_in_memory_backend_get_rearm_count (f->ctx), ==, 1);

  /* Duplicate gate notifications in the same generation are idempotent. */
  goodix_device_context_set_fresh_down_table (f->ctx, TRUE);
  goodix_device_context_emit_release_tail_complete (f->ctx);
  g_assert_cmpuint (goodix_in_memory_backend_get_rearm_count (f->ctx), ==, 1);

  /* Cancel before the configured multistage enrollment proceeds further. */
  g_cancellable_cancel (cancellable);
  test_wait (f);
  g_assert_false (f->success);
}

static void
test_terminal_hold_release_before_sigfm_completion (void)
{
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  TestFixture *f = test_fixture_new ();
  gint64 deadline;

  fixture_open (f);
  fpi_device_set_nr_enroll_stages (FP_DEVICE (f->device), 1);
  template = fp_print_new (FP_DEVICE (f->device));
  fill_gradient_samples (samples);
  goodix_test_sigfm_extract_set_block (TRUE);

  f->done = FALSE;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  fpi_image_device_hold_enroll_completion (FP_IMAGE_DEVICE (f->device));
  goodix_device_context_emit_image_ready (
    f->ctx, samples, GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);
  goodix_device_context_emit_release_tail_complete (f->ctx);
  goodix_device_context_emit_finger_up_ready (f->ctx);
  fpi_image_device_release_enroll_completion (FP_IMAGE_DEVICE (f->device));

  deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;
  while (!goodix_test_sigfm_extract_is_blocked () &&
         g_get_monotonic_time () < deadline)
    g_main_context_iteration (NULL, FALSE);
  g_assert_true (goodix_test_sigfm_extract_is_blocked ());
  g_assert_false (f->done);
  g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_IDLE);

  goodix_test_sigfm_extract_unblock ();
  test_wait (f);
  g_assert_true (f->success);
  g_assert_cmpuint (f->enroll_progress_count, ==, 1u);
  fixture_close (f);
  test_fixture_free (f);
}

static void
test_terminal_release_before_sigfm_failure_is_fail_closed (void)
{
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  TestFixture *f = test_fixture_new ();

  fixture_open (f);
  fpi_device_set_nr_enroll_stages (FP_DEVICE (f->device), 1);
  template = fp_print_new (FP_DEVICE (f->device));
  fill_gradient_samples (samples);
  goodix_test_sigfm_extract_set_block (TRUE);

  f->done = FALSE;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  fpi_image_device_hold_enroll_completion (FP_IMAGE_DEVICE (f->device));
  g_test_expect_message ("libfprint-image_device", G_LOG_LEVEL_WARNING,
                         "*Failed to detect minutiae*");
  goodix_device_context_emit_image_ready (
    f->ctx, samples, GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

  g_assert_true (goodix_test_sigfm_extract_wait_blocked (
    TEST_TIMEOUT_MS * 1000));
  goodix_device_context_emit_release_tail_complete (f->ctx);
  goodix_device_context_emit_finger_up_ready (f->ctx);
  fpi_image_device_release_enroll_completion (FP_IMAGE_DEVICE (f->device));
  goodix_test_sigfm_extract_set_failure (TRUE);
  goodix_test_sigfm_extract_unblock ();

  test_wait (f);
  g_test_assert_expected_messages ();
  goodix_test_sigfm_extract_set_failure (FALSE);

  g_assert_false (f->success);
  g_assert_error (f->error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_DATA_INVALID);
  g_assert_cmpuint (f->enroll_progress_count, ==, 0u);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);

  fixture_close (f);
  test_fixture_free (f);
}

static void
test_enroll_minutiae_done_before_finger_off (void)
{
  TestFixture *f = test_fixture_new ();

  fixture_open (f);
  run_enroll_cycle (f, FALSE, TRUE);
  fixture_close (f);
  test_fixture_free (f);
}

static void
test_enroll_finger_off_before_minutiae_done (void)
{
  TestFixture *f = test_fixture_new ();

  fixture_open (f);
  run_enroll_cycle (f, TRUE, FALSE);
  fixture_close (f);
  test_fixture_free (f);
}

static void
test_enrollment_fixed_21_stage_policy (void)
{
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  TestFixture *f = test_fixture_new ();

  fixture_open (f);
  g_assert_cmpint (fp_device_get_nr_enroll_stages (FP_DEVICE (f->device)), ==,
                   (gint) GOODIX_SIGFM_ENROLL_REQUIRED_STAGES);
  template = fp_print_new (FP_DEVICE (f->device));
  fill_gradient_samples (samples);
  f->done = FALSE;
  f->completion_count = 0;
  f->enroll_progress_count = 0;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);

  for (guint stage = 1u; stage <= GOODIX_SIGFM_ENROLL_REQUIRED_STAGES; stage++)
    {
      gint64 deadline;
      gboolean final_stage = stage == GOODIX_SIGFM_ENROLL_REQUIRED_STAGES;

      g_assert_cmpint (f->last_state, ==,
                       FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON);
      goodix_device_context_emit_finger_down (f->ctx);
      g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_CAPTURE);
      samples[stage % G_N_ELEMENTS (samples)] = (uint16_t) (stage * 17u);
      if (final_stage)
        goodix_test_sigfm_extract_set_block (TRUE);
      goodix_device_context_emit_image_ready (
        f->ctx, samples, GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

      if (final_stage)
        {
          g_assert_true (goodix_test_sigfm_extract_wait_blocked (
            TEST_TIMEOUT_MS * 1000));
          goodix_device_context_emit_release_tail_complete (f->ctx);
          goodix_device_context_emit_finger_up_ready (f->ctx);
          g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_IDLE);
          goodix_test_sigfm_extract_unblock ();
        }

      deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;
      while (f->enroll_progress_count < stage && !f->done &&
             g_get_monotonic_time () < deadline)
        g_main_context_iteration (NULL, FALSE);
      g_assert_cmpuint (f->enroll_progress_count, ==, stage);

      if (!final_stage)
        {
          goodix_device_context_emit_release_tail_complete (f->ctx);
          goodix_device_context_emit_finger_up_ready (f->ctx);
          g_assert_cmpint (f->last_state, ==,
                           FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON);
        }
    }

  test_wait (f);
  g_assert_true (f->success);
  g_assert_nonnull (f->enroll_print);
  g_assert_cmpuint (f->completion_count, ==, 1u);
  g_assert_cmpuint (f->enroll_progress_count, ==,
                    GOODIX_SIGFM_ENROLL_REQUIRED_STAGES);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);

  fixture_close (f);
  test_fixture_free (f);
}

static void
test_no_rearm_before_both_gates (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = fp_print_new (FP_DEVICE (f->device));
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];

  fixture_open (f);
  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  f->enroll_progress_count = 0;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template), cancellable,
                    progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);

  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

  /* Release tail completes, but fresh down-table is intentionally false. */
  goodix_device_context_set_fresh_down_table (f->ctx, FALSE);
  goodix_device_context_emit_release_tail_complete (f->ctx);
  goodix_device_context_emit_finger_up_ready (f->ctx);

  g_assert_cmpuint (goodix_in_memory_backend_get_rearm_count (f->ctx), ==, 0);

  g_cancellable_cancel (cancellable);
  test_wait (f);
  g_assert_false (f->success);

  fixture_close (f);
  test_fixture_free (f);
}

static void
test_no_command_after_deactivate_fence (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  guint commands_before;

  fixture_open (f);
  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

  commands_before = goodix_device_context_get_backend_command_count (f->ctx);

  /* Cancel the action: this raises the terminal fence and deactivates. */
  g_cancellable_cancel (cancellable);

  /* Spin until the deactivate fence is observable. */
  while (!goodix_device_context_get_terminal_fence (f->ctx))
    g_main_context_iteration (NULL, TRUE);

  /* Old-generation events after the fence must be ignored. */
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_before + 1 /* disarm */);

  test_wait (f);
  g_assert_false (f->success);

  fixture_close (f);
  test_fixture_free (f);
}

/* -------------------------------------------------------------
 * 7.3 Cancellation per state
 * ------------------------------------------------------------- */
static void
test_cancellation_opening (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_open (FP_DEVICE (f->device), cancellable,
                  (GAsyncReadyCallback) open_cb, f);
  g_cancellable_cancel (cancellable);

  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
  g_assert_cmpuint (f->completion_count, ==, 1);

  test_fixture_free (f);
}

static void
test_cancellation_activating (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(GCancellable) second_cancellable = g_cancellable_new ();
  guint64 poisoned_generation;
  GLogLevelFlags old_fatal;
  guint commands_before;
  guint64 real_submits_before;
  guint64 out_submits_before;
  GoodixFpiUsbBackend *usb_backend;

  fixture_open (f);
  usb_backend = goodix_device_context_get_fpi_usb_backend (f->ctx);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING);
  /* The backend arm is reached before the cancellable can fire; the remaining
   * open epoch is therefore non-quiescent and must become sticky poisoned. */
  g_assert_cmpuint (goodix_in_memory_backend_get_arm_count (f->ctx), ==, 1);
  poisoned_generation = goodix_device_context_get_generation (f->ctx);
  g_assert_cmpuint (poisoned_generation, >, 0);

  g_cancellable_cancel (cancellable);

  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
  g_assert_cmpuint (f->completion_count, ==, 1);
  g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0);

  commands_before = goodix_device_context_get_backend_command_count (f->ctx);
  real_submits_before = goodix_fpi_usb_backend_get_real_submit_count (usb_backend);
  out_submits_before = goodix_fpi_usb_backend_get_out_submit_count (usb_backend);

  /* A second capture request in the same open epoch must be rejected by the
   * sticky poison gate without creating a new generation, backend command or
   * USB submit.  libfprint leaves FpImageDevice in ACTIVATING after
   * activate_complete(error), which would normally be a host-side warning; the
   * only assertion of interest here is that the driver stays poisoned and does
   * not reach the backend or USB. */
  g_clear_error (&f->error);
  f->done = FALSE;
  f->completion_count = 0;
  f->success = FALSE;
  old_fatal = g_log_set_always_fatal (0);
  fp_device_capture (FP_DEVICE (f->device), TRUE, second_cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  g_log_set_always_fatal (old_fatal);
  test_wait (f);

  g_assert_false (f->success);
  g_assert_error (f->error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0);
  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_before);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_real_submit_count (usb_backend),
                    ==, real_submits_before);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_out_submit_count (usb_backend),
                    ==, out_submits_before);

  /* Stale callbacks / events from the interrupted activation cannot reopen
   * the poisoned context. */
  goodix_device_context_complete_receive (f->ctx, poisoned_generation,
                                           NULL, 0, NULL);
  goodix_device_context_emit_finger_down_for_generation (
    f->ctx, poisoned_generation);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0);
  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_before);

  fixture_close (f);
  g_assert_null (goodix_fpimage_device_get_context (f->device));
  test_fixture_free (f);
}

static void
test_cancellation_await_finger_on (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();

  fixture_open (f);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON);

  g_cancellable_cancel (cancellable);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_cmpuint (f->completion_count, ==, 1);

  fixture_close (f);
  test_fixture_free (f);
}

static void
test_cancellation_capture (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];

  fixture_open (f);
  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_CAPTURE);

  g_cancellable_cancel (cancellable);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_cmpuint (f->completion_count, ==, 1);

  fixture_close (f);
  test_fixture_free (f);
}

static void
test_cancellation_await_finger_off (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];

  fixture_open (f);
  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);
  g_assert_cmpint (f->last_state, ==, FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_OFF);

  g_cancellable_cancel (cancellable);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_cmpuint (f->completion_count, ==, 1);

  fixture_close (f);
  test_fixture_free (f);
}

static void
test_cancellation_deactivating (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  guint completion_before;

  fixture_open (f);
  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);

  goodix_device_context_set_deactivation_held (f->ctx, TRUE);
  g_cancellable_cancel (cancellable);

  /* libfprint forwards external cancellation through an idle source.
   * Give that source a chance to invoke the driver's deactivate vfunc;
   * deactivation_held keeps the driver in DEACTIVATING until the test
   * explicitly completes it below. */
  while (g_main_context_pending (NULL))
    g_main_context_iteration (NULL, FALSE);

  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING);

  completion_before = f->completion_count;

  /* A second cancellation while deactivating must not produce a second
   * completion or any new backend command. */
  g_cancellable_cancel (cancellable);

  goodix_device_context_complete_deactivation (f->ctx);

  test_wait (f);
  g_assert_cmpuint (f->completion_count, ==, completion_before + 1);

  fixture_close (f);
  test_fixture_free (f);
}

/* -------------------------------------------------------------
 * 7.4 Stale callbacks / generation guard
 * ------------------------------------------------------------- */
static void
test_stale_callback_generation_guard (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  guint commands_before;
  guint64 old_generation;
  g_autoptr(GCancellable) second_cancellable = g_cancellable_new ();
  GoodixFpiUsbBackend *usb_backend;
  GoodixUsbRouter *router;
  const guint8 synthetic_a0[] = { 0xa0, 0x01, 0x00, 0xa1, 0x01 };

  fixture_open (f);
  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);

  old_generation = goodix_device_context_get_generation (f->ctx);
  usb_backend = goodix_device_context_get_fpi_usb_backend (f->ctx);
  router = goodix_device_context_get_usb_router (f->ctx);
  goodix_device_context_set_async_usb_submit_seam (f->ctx,
                                                    host_only_usb_submit, NULL);
  g_assert_true (goodix_device_context_arm_receive (f->ctx, NULL));

  /* Complete the action, invalidating the generation. */
  goodix_device_context_emit_image_ready (f->ctx, samples,
                                          GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);
  goodix_device_context_emit_release_tail_complete (f->ctx);
  goodix_device_context_emit_finger_up_ready (f->ctx);

  while (goodix_device_context_get_state (f->ctx) !=
         GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING)
    g_main_context_iteration (NULL, TRUE);
  g_assert_false (f->done);
  g_assert_false (goodix_fpi_usb_backend_is_drained (usb_backend));
  g_assert_cmpuint (goodix_fpi_usb_backend_get_outstanding (usb_backend), ==, 1);

  /* Cancellation requests only fence the transfer.  The synthetic callback
   * owns and releases N's physical-shaped token, which allows deactivation
   * completion without claiming device-side protocol quiescence. */
  g_autoptr(GError) cancelled = g_error_new_literal (
    G_IO_ERROR, G_IO_ERROR_CANCELLED, "synthetic cancelled IN completion");
  goodix_device_context_complete_receive (f->ctx, old_generation, NULL, 0,
                                           cancelled);
  g_assert_true (goodix_fpi_usb_backend_is_drained (usb_backend));
  test_wait (f);

  g_assert_true (f->success);
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, second_cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  guint64 current_generation = goodix_device_context_get_generation (f->ctx);
  g_assert_cmpuint (current_generation, !=, old_generation);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  g_assert_true (goodix_device_context_arm_receive (f->ctx, NULL));

  /* The late N callback is routed through the integrated context/backend
   * seam and cannot consume the N+1 router token. */
  goodix_device_context_complete_receive (f->ctx, old_generation,
                                           synthetic_a0,
                                           sizeof synthetic_a0, NULL);
  g_assert_cmpuint (goodix_usb_router_get_outstanding (router), ==, 1);
  g_assert_cmpuint (goodix_usb_router_get_delivery_count (router), ==, 0);
  goodix_device_context_complete_receive (f->ctx, current_generation,
                                           synthetic_a0,
                                           sizeof synthetic_a0, NULL);
  g_assert_cmpuint (goodix_usb_router_get_delivery_count (router), ==, 1);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_max_outstanding (usb_backend),
                    ==, 1);

  /* An N-1 callback must cause zero new backend commands. */
  commands_before = goodix_device_context_get_backend_command_count (f->ctx);
  goodix_device_context_emit_finger_down_for_generation (f->ctx,
                                                         old_generation);
  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_before);
  g_cancellable_cancel (second_cancellable);
  test_wait (f);

  fixture_close (f);
  test_fixture_free (f);
}

/* -------------------------------------------------------------
 * 7.5 Error path
 * ------------------------------------------------------------- */
static void
test_terminal_error_path (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(GError) terminal = NULL;
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  guint commands_after_error;

  fixture_open (f);
  fill_gradient_samples (samples);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);

  terminal = g_error_new (FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
                          "host-only terminal error");
  goodix_device_context_emit_terminal_error (f->ctx, terminal);

  test_wait (f);
  g_assert_false (f->success);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));
  g_assert_cmpuint (f->completion_count, ==, 1);

  /* fpi_image_device_session_error() deactivates the framework session, so
   * the expected teardown is exactly ARM + DISARM, with no REARM. */
  g_assert_cmpuint (goodix_in_memory_backend_get_arm_count (f->ctx), ==, 1);
  g_assert_cmpuint (goodix_in_memory_backend_get_disarm_count (f->ctx), ==, 1);
  g_assert_cmpuint (goodix_in_memory_backend_get_rearm_count (f->ctx), ==, 0);
  commands_after_error = goodix_device_context_get_backend_command_count (f->ctx);

  /* No further commands accepted after the terminal fence. */
  goodix_device_context_emit_finger_up_ready (f->ctx);
  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_after_error);

  fixture_close (f);
  test_fixture_free (f);
}

static void
test_poison_is_sticky_until_close (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) first_cancellable = g_cancellable_new ();
  g_autoptr(GCancellable) second_cancellable = g_cancellable_new ();
  g_autoptr(GError) terminal = NULL;
  GoodixFpiUsbBackend *usb_backend;
  guint64 poisoned_generation;
  guint64 real_submits_before;
  guint64 out_submits_before;
  guint commands_before;

  fixture_open (f);
  usb_backend = goodix_device_context_get_fpi_usb_backend (f->ctx);

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, first_cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  poisoned_generation = goodix_device_context_get_generation (f->ctx);
  g_assert_cmpuint (poisoned_generation, >, 0);

  terminal = g_error_new (FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
                          "host-only sticky poison trigger");
  goodix_device_context_emit_terminal_error (f->ctx, terminal);
  test_wait (f);

  g_assert_false (f->success);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0);

  commands_before = goodix_device_context_get_backend_command_count (f->ctx);
  real_submits_before =
    goodix_fpi_usb_backend_get_real_submit_count (usb_backend);
  out_submits_before =
    goodix_fpi_usb_backend_get_out_submit_count (usb_backend);

  g_clear_error (&f->error);
  f->done = FALSE;
  f->completion_count = 0;
  f->success = FALSE;
  fp_device_capture (FP_DEVICE (f->device), TRUE, second_cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  test_wait (f);

  g_assert_false (f->success);
  g_assert_error (f->error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0);
  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_before);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_real_submit_count (usb_backend),
                    ==, real_submits_before);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_out_submit_count (usb_backend),
                    ==, out_submits_before);

  /* Neither an old-generation callback nor a fake device event may reopen
   * the poisoned context or reach a backend command. */
  goodix_device_context_complete_receive (f->ctx, poisoned_generation,
                                           NULL, 0, NULL);
  goodix_device_context_emit_finger_down_for_generation (
    f->ctx, poisoned_generation);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0);
  g_assert_cmpuint (goodix_device_context_get_backend_command_count (f->ctx),
                    ==, commands_before);

  fixture_close (f);
  g_assert_null (goodix_fpimage_device_get_context (f->device));
  test_fixture_free (f);
}

static void
test_d276_04_context_ownership (void)
{
  static const guint8 synthetic_secret[] = { 0x44, 0x32, 0x37, 0x36, 0x2d, 0x30, 0x34 };
  TestFixture *f = test_fixture_new ();
  GoodixTlsAudit audit = { 0 };
  g_autoptr(GError) error = NULL;

  fixture_open (f);
  g_assert_nonnull (goodix_device_context_get_usb_router (f->ctx));
  g_assert_nonnull (goodix_device_context_get_fpi_usb_backend (f->ctx));
  g_assert_null (goodix_device_context_get_tls_server (f->ctx));
  g_assert_true (goodix_device_context_configure_tls (
    f->ctx, synthetic_secret, sizeof synthetic_secret, NULL, NULL, &audit,
    &error));
  g_assert_no_error (error);
  g_assert_nonnull (goodix_device_context_get_tls_server (f->ctx));
  fixture_close (f);
  g_assert_true (audit.project_secret_zeroized);
  test_fixture_free (f);
}

static void
test_d278_12_post_tls_context_ownership (void)
{
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  GoodixPostTlsMaterial material = { 0 };
  GoodixPostTlsAudit audit = { 0 };
  GoodixFpiUsbBackend *backend;
  GoodixUsbRouter *router;
  g_autoptr(GError) error = NULL;

  fixture_open (f);
  backend = goodix_device_context_get_fpi_usb_backend (f->ctx);
  router = goodix_device_context_get_usb_router (f->ctx);
  for (guint i = 0; i < 6u; i++)
    {
      material.initial_fdt_table[i * 2u] = 0x80;
      material.initial_fdt_table[i * 2u + 1u] = (guint8) (0x40u + i);
    }
  material.af_timestamp = 1;
  material.first_arm_timestamp = 2;
  material.second_arm_timestamp = 3;

  f->done = FALSE;
  f->completion_count = 0;
  fp_device_capture (FP_DEVICE (f->device), TRUE, cancellable,
                     (GAsyncReadyCallback) capture_cb, f);
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), >, 0u);
  g_assert_true (goodix_device_context_configure_post_tls_lifecycle (
    f->ctx, &material, &audit, &error));
  g_assert_no_error (error);
  g_assert_nonnull (goodix_device_context_get_post_tls_lifecycle (f->ctx));
  g_assert_true (goodix_device_context_get_fpi_usb_backend (f->ctx) == backend);
  g_assert_true (goodix_device_context_get_usb_router (f->ctx) == router);

  g_cancellable_cancel (cancellable);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
  fixture_close (f);
  test_fixture_free (f);
}

typedef struct
{
  GoodixFpImageDevice *device;
  GString *events;
  guint acquire_count;
  guint material_release_count;
  guint claim_count;
  guint interface_release_count;
  gboolean fail_acquire;
  gboolean fail_claim;
  gboolean fail_release;
  gboolean cancel_after_acquire;
  guint in_submit_count;
  guint out_submit_count;
  guint8 validator[32];
  guint8 config[GOODIX_SECURE_SESSION_CONFIG90_LENGTH];
  guint8 a2[3];
  guint8 chip[4];
  guint8 otp[64];
  guint8 synthetic_psk[GOODIX_SECURE_SESSION_PSK_LENGTH];
} ProductionOpenSeam;

static void
production_digest (const guint8 *data,
                   gsize         length,
                   guint8        output[32])
{
  unsigned int output_length = 0;

  g_assert_true (EVP_Digest (data, length, output, &output_length,
                             EVP_sha256 (), NULL));
  g_assert_cmpuint (output_length, ==, 32u);
}

typedef struct
{
  guint acquire_count;
  guint release_count;
} CoordinatorLegacySeam;

static gboolean
coordinator_legacy_acquire (
  GoodixRuntimeMaterial       **owner,
  GoodixSecureSessionMaterial  *secure_view,
  guint8                        fdt_seed[GOODIX_RUNTIME_FDT_SEED_LENGTH],
  GoodixRuntimeMaterialAudit   *audit,
  gpointer                      user_data,
  GError                      **error)
{
  CoordinatorLegacySeam *seam = user_data;

  (void) error;
  seam->acquire_count++;
  memset (secure_view, 0, sizeof *secure_view);
  memset (fdt_seed, 0, GOODIX_RUNTIME_FDT_SEED_LENGTH);
  memset (audit, 0, sizeof *audit);
  *owner = (GoodixRuntimeMaterial *) g_malloc0 (1u);
  return TRUE;
}

static void
coordinator_legacy_release (GoodixRuntimeMaterial *owner,
                            gpointer               user_data)
{
  CoordinatorLegacySeam *seam = user_data;

  seam->release_count++;
  g_free (owner);
}

static guint8
coordinator_crc8 (const guint8 *data,
                  gsize         length)
{
  guint8 crc = 0;

  for (gsize i = 0; i < length; i++)
    {
      crc ^= data[i];
      for (guint bit = 0; bit < 8u; bit++)
        {
          guint shifted = (guint) crc << 1;

          crc = (guint8) ((crc & 0x80u) != 0u ?
                            shifted ^ 0x07u : shifted);
        }
    }
  return (guint8) ~crc;
}

static void
coordinator_make_otp (guint8 otp[GOODIX_CONFIG90_OTP_LENGTH])
{
  guint8 buffer[27] = { 0 };

  for (guint i = 0; i < GOODIX_CONFIG90_OTP_LENGTH; i++)
    otp[i] = (guint8) (i * 7u + 3u);
  otp[27] = 0x22u;
  otp[42] = 0x42u;
  otp[43] = 0xbdu;
  otp[45] = 0x42u;
  otp[50] = 0x21u;
  otp[51] = 0x31u;
  otp[52] = 0x41u;
  otp[53] = 0x51u;
  otp[62] = coordinator_crc8 (otp + 50, 4u);
  memcpy (buffer, otp, 11u);
  memcpy (buffer + 11, otp + 36, 4u);
  otp[60] = coordinator_crc8 (buffer, 15u);
  memcpy (buffer, otp + 11, 9u);
  buffer[9] = otp[28];
  memcpy (buffer + 10, otp + 50, 4u);
  memcpy (buffer + 14, otp + 56, 4u);
  buffer[18] = otp[62];
  otp[61] = coordinator_crc8 (buffer, 19u);
  memcpy (buffer, otp + 20, 8u);
  memcpy (buffer + 8, otp + 29, 7u);
  memcpy (buffer + 15, otp + 40, 10u);
  memcpy (buffer + 25, otp + 54, 2u);
  otp[63] = coordinator_crc8 (buffer, 27u);
}

static void
coordinator_remove_directory (const gchar *directory)
{
  GDir *dir = g_dir_open (directory, 0, NULL);
  const gchar *name;

  if (dir != NULL)
    {
      while ((name = g_dir_read_name (dir)) != NULL)
        {
          g_autofree gchar *path = g_build_filename (directory, name, NULL);

          g_assert_cmpint (g_unlink (path), ==, 0);
        }
      g_dir_close (dir);
    }
  g_assert_cmpint (g_rmdir (directory), ==, 0);
}

static void
test_p5_coordinator_migration_selection (void)
{
  static const guint8 a2[] = { 0x11u, 0x22u, 0x33u };
  static const guint8 chip[] = { 0x25u, 0x04u, 0x12u, 0x50u };
  g_autofree gchar *root = g_dir_make_tmp ("goodix-coordinator.XXXXXX", NULL);
  g_autofree gchar *state_dir = g_build_filename (root, "state", NULL);
  g_autofree gchar *legacy_dir = g_build_filename (root, "legacy", NULL);
  GoodixRuntimeCoordinatorPaths paths = { 0 };
  GoodixRuntimeCoordinatorPolicy policy = { 0 };
  GoodixRuntimeCoordinatorLiveEvidence live = { 0 };
  GoodixRuntimeCoordinatorAudit audit;
  GoodixRuntimeMaterialAudit legacy_audit;
  CoordinatorLegacySeam seam = { 0 };
  GoodixRuntimeCoordinator *coordinator;
  guint8 otp[GOODIX_CONFIG90_OTP_LENGTH];
  guint8 validator[GOODIX_SELF_STATE_DIGEST_LENGTH];
  GError *error = NULL;

  g_assert_nonnull (root);
  g_assert_cmpint (g_mkdir (state_dir, 0700), ==, 0);
  g_assert_cmpint (g_mkdir (legacy_dir, 0700), ==, 0);
  paths.state_directory = state_dir;
  paths.legacy.directory_path = legacy_dir;
  goodix_self_state_policy_for_owner (&policy.state, getuid (), getgid ());
  policy.legacy.directory_owner_uid = getuid ();
  policy.legacy.directory_owner_gid = getgid ();
  policy.legacy.directory_mode = 0700;
  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, NULL, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_no_error (error);
  g_assert_nonnull (coordinator);
  g_assert_cmpint (goodix_runtime_coordinator_get_source (coordinator), ==,
                   GOODIX_RUNTIME_COORDINATOR_SOURCE_LEGACY);
  g_assert_true (audit.coexistence_observed);
  g_assert_false (audit.writer_enabled);
  g_assert_cmpuint (audit.pairing_write_count, ==, 0u);
  g_assert_cmpuint (seam.acquire_count, ==, 1u);
  goodix_runtime_coordinator_free (coordinator);
  g_assert_cmpuint (seam.release_count, ==, 1u);

  coordinator_make_otp (otp);
  memset (validator, 0x44, sizeof validator);
  live = (GoodixRuntimeCoordinatorLiveEvidence) {
    .vid = 0x27c6u,
    .pid = 0x5125u,
    .chip_id = 0x2504u,
    .app = "APP12509",
    .a2_response = a2,
    .a2_response_length = sizeof a2,
    .chip_response = chip,
    .chip_response_length = sizeof chip,
    .otp = otp,
    .otp_length = sizeof otp,
    .live_validator = validator,
    .live_validator_length = sizeof validator,
  };
  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, &live, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_no_error (error);
  g_assert_nonnull (coordinator);
  g_assert_cmpint (audit.state_load_result, ==,
                   GOODIX_SELF_STATE_LOAD_ABSENT);
  g_assert_cmpint (audit.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_READY_LEGACY);
  g_assert_cmpuint (seam.acquire_count, ==, 2u);
  goodix_runtime_coordinator_free (coordinator);
  g_assert_cmpuint (seam.release_count, ==, 2u);

  coordinator_remove_directory (legacy_dir);
  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, NULL, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_null (coordinator);
  g_assert_nonnull (error);
  g_clear_error (&error);
  g_assert_cmpint (audit.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_NEEDS_LIVE_PREFLIGHT);
  g_assert_false (audit.writer_enabled);
  g_assert_cmpuint (audit.pairing_write_count, ==, 0u);
  g_assert_cmpuint (seam.acquire_count, ==, 2u);
  coordinator_remove_directory (state_dir);
  g_assert_cmpint (g_rmdir (root), ==, 0);
}

static void
test_p5_coordinator_active_state (void)
{
  static const guint8 a2[] = { 0x11u, 0x22u, 0x33u };
  static const guint8 chip[] = { 0x25u, 0x04u, 0x12u, 0x50u };
  g_autofree gchar *root = g_dir_make_tmp ("goodix-coordinator.XXXXXX", NULL);
  g_autofree gchar *state_dir = g_build_filename (root, "state", NULL);
  g_autofree gchar *legacy_dir = g_build_filename (root, "legacy", NULL);
  GoodixRuntimeCoordinatorPaths paths = { 0 };
  GoodixRuntimeCoordinatorPolicy policy = { 0 };
  GoodixRuntimeCoordinatorLiveEvidence live = { 0 };
  GoodixRuntimeCoordinatorAudit audit;
  GoodixRuntimeMaterialAudit legacy_audit;
  GoodixSelfStateBinding binding = { 0 };
  GoodixSelfStateRecord record = { 0 };
  GoodixConfig90Calibration calibration;
  GoodixSelfState *prepared = NULL;
  GoodixRuntimeCoordinator *coordinator;
  GoodixSecureSessionMaterial view;
  CoordinatorLegacySeam seam = { 0 };
  guint8 otp[GOODIX_CONFIG90_OTP_LENGTH];
  guint8 config[GOODIX_CONFIG90_LENGTH];
  guint8 validator[GOODIX_SELF_STATE_DIGEST_LENGTH];
  guint8 psk[GOODIX_SELF_STATE_PSK_LENGTH];
  guint8 bb010002[GOODIX_BB010002_LENGTH];
  GError *error = NULL;

  g_assert_nonnull (root);
  g_assert_cmpint (g_mkdir (state_dir, 0700), ==, 0);
  coordinator_make_otp (otp);
  for (guint i = 0; i < sizeof validator; i++)
    {
      validator[i] = (guint8) (0x20u + i);
      psk[i] = (guint8) (0xa0u + i);
    }
  memset (bb010002, 0x6cu, sizeof bb010002);
  g_assert_true (goodix_config90_derive (0x2504u, otp, sizeof otp, config,
                                         &calibration, NULL));
  binding.vid = 0x27c6u;
  binding.pid = 0x5125u;
  binding.chip_profile = 0x2504u;
  g_strlcpy (binding.app, "APP12509", sizeof binding.app);
  production_digest (otp, sizeof otp, binding.otp_sha256);
  production_digest (config, sizeof config, binding.config90_sha256);
  record.phase = GOODIX_SELF_STATE_PREPARED;
  record.generation = 1u;
  memcpy (record.expected_validator, validator, sizeof validator);
  record.e0_attempted = TRUE;
  record.bb010002_sha256_present = TRUE;
  production_digest (bb010002, sizeof bb010002,
                     record.bb010002_sha256);
  record.fdt_present = TRUE;
  memset (record.fdt_table, 0x5au, sizeof record.fdt_table);
  goodix_self_state_policy_for_owner (&policy.state, getuid (), getgid ());
  g_assert_true (goodix_self_state_write_prepared (
    state_dir, &binding, &record, psk, &policy.state, NULL));
  g_assert_cmpint (goodix_self_state_load (state_dir, &binding, &policy.state,
                                           &prepared, NULL), ==,
                   GOODIX_SELF_STATE_LOAD_VALID);
  goodix_self_state_free (prepared);
  paths.state_directory = state_dir;
  paths.legacy.directory_path = legacy_dir;
  policy.legacy.directory_owner_uid = getuid ();
  policy.legacy.directory_owner_gid = getgid ();
  policy.legacy.directory_mode = 0700;
  live = (GoodixRuntimeCoordinatorLiveEvidence) {
    .vid = 0x27c6u,
    .pid = 0x5125u,
    .chip_id = 0x2504u,
    .app = "APP12509",
    .a2_response = a2,
    .a2_response_length = sizeof a2,
    .chip_response = chip,
    .chip_response_length = sizeof chip,
    .otp = otp,
    .otp_length = sizeof otp,
    .live_validator = validator,
    .live_validator_length = sizeof validator,
    .bb010002 = bb010002,
    .bb010002_length = sizeof bb010002,
  };
  bb010002[0] ^= 1u;
  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, &live, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_null (coordinator);
  g_assert_nonnull (error);
  g_clear_error (&error);
  g_assert_cmpint (audit.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_RECOVERY_REQUIRED);
  bb010002[0] ^= 1u;
  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, &live, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_no_error (error);
  g_assert_nonnull (coordinator);
  g_assert_cmpint (audit.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_READY_RETRY_TLS);
  g_assert_true (goodix_runtime_coordinator_promote_after_tls (coordinator,
                                                               &error));
  g_assert_no_error (error);
  goodix_runtime_coordinator_free (coordinator);

  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, &live, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_no_error (error);
  g_assert_nonnull (coordinator);
  g_assert_cmpint (audit.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_READY_ACTIVE);
  g_assert_cmpint (audit.source, ==,
                   GOODIX_RUNTIME_COORDINATOR_SOURCE_STATE_V2);
  g_assert_false (audit.writer_enabled);
  g_assert_cmpuint (audit.pairing_write_count, ==, 0u);
  g_assert_cmpuint (seam.acquire_count, ==, 0u);
  g_assert_true (goodix_runtime_coordinator_get_secure_view (
    coordinator, &view, NULL));
  g_assert_cmpmem (view.psk, view.psk_length, psk, sizeof psk);
  g_assert_cmpmem (view.config90, view.config90_length, config, sizeof config);
  goodix_runtime_coordinator_free (coordinator);

  live.app = "APP12507";
  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, &live, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_null (coordinator);
  g_assert_nonnull (error);
  g_clear_error (&error);
  g_assert_cmpint (audit.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_FAIL_CLOSED);

  live.app = "";
  coordinator = goodix_runtime_coordinator_acquire (
    &paths, &policy, &live, coordinator_legacy_acquire,
    coordinator_legacy_release, &seam, &legacy_audit, &audit, &error);
  g_assert_null (coordinator);
  g_assert_nonnull (error);
  g_clear_error (&error);
  g_assert_cmpint (audit.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_FAIL_CLOSED);

  coordinator_remove_directory (state_dir);
  g_assert_cmpint (g_rmdir (root), ==, 0);
}

static void
production_set_config_finalizer (
  guint8 config[GOODIX_SECURE_SESSION_CONFIG90_LENGTH])
{
  guint32 sum = 0;
  guint16 finalizer;

  for (guint i = 0; i < 111u; i++)
    sum += (guint16) ((guint16) config[i * 2u] |
                     (guint16) ((guint16) config[i * 2u + 1u] << 8));
  finalizer = (guint16) (0u - 0xa5a5u - sum);
  config[222] = (guint8) finalizer;
  config[223] = (guint8) (finalizer >> 8);
}

static void
production_material_init (ProductionOpenSeam *seam)
{
  static const guint8 registers[4][2] = {
    { 0x20, 0x02 }, { 0x36, 0x02 }, { 0x38, 0x02 }, { 0x3a, 0x02 }
  };
  static const guint8 values[4][2] = {
    { 0xd8, 0x0b }, { 0xbe, 0x00 }, { 0xbd, 0x00 }, { 0xbc, 0x00 }
  };
  static const guint offsets[] = { 117, 121, 125, 129 };

  for (guint i = 0; i < 32u; i++)
    {
      seam->validator[i] = (guint8) (0x20u + i);
      seam->synthetic_psk[i] = (guint8) (0x80u + i);
    }
  seam->a2[0] = 0x11;
  seam->a2[1] = 0x22;
  seam->a2[2] = 0x33;
  seam->chip[0] = 0x25;
  seam->chip[1] = 0x04;
  seam->chip[2] = 0x12;
  seam->chip[3] = 0x50;
  for (guint i = 0; i < sizeof seam->otp; i++)
    seam->otp[i] = (guint8) (i * 3u + 1u);
  for (guint i = 0; i < G_N_ELEMENTS (offsets); i++)
    {
      memcpy (seam->config + offsets[i], registers[i], 2u);
      memcpy (seam->config + offsets[i] + 2u, values[i], 2u);
    }
  production_set_config_finalizer (seam->config);
}

static gboolean
production_acquire_seam (
  GoodixRuntimeCoordinator    **owner,
  GoodixSecureSessionMaterial  *secure_view,
  guint8                        fdt_seed[GOODIX_RUNTIME_FDT_SEED_LENGTH],
  GoodixRuntimeCoordinatorAudit *coordinator_audit,
  GoodixRuntimeMaterialAudit   *audit,
  gpointer                      user_data,
  GError                      **error)
{
  ProductionOpenSeam *seam = user_data;
  static const guint8 identity[] = "GF_ST411SEC_APP_12509";
  static const guint8 values[4][2] = {
    { 0xd8, 0x0b }, { 0xbe, 0x00 }, { 0xbd, 0x00 }, { 0xbc, 0x00 }
  };

  seam->acquire_count++;
  g_string_append_c (seam->events, 'A');
  g_assert_cmpuint (goodix_test_gusb_get_open_count (), ==,
                    seam->acquire_count);
  memset (audit, 0, sizeof *audit);
  memset (coordinator_audit, 0, sizeof *coordinator_audit);
  coordinator_audit->source = GOODIX_RUNTIME_COORDINATOR_SOURCE_LEGACY;
  coordinator_audit->decision =
    GOODIX_RUNTIME_COORDINATOR_DECISION_READY_LEGACY;
  memset (secure_view, 0, sizeof *secure_view);
  memset (fdt_seed, 0x80, GOODIX_RUNTIME_FDT_SEED_LENGTH);
  if (seam->fail_acquire)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                           "synthetic runtime material failure");
      return FALSE;
    }
  secure_view->expected_identity = identity;
  secure_view->expected_identity_length = sizeof identity;
  secure_view->e4_validator = seam->validator;
  secure_view->e4_validator_length = sizeof seam->validator;
  secure_view->config90 = seam->config;
  secure_view->config90_length = sizeof seam->config;
  secure_view->psk = seam->synthetic_psk;
  secure_view->psk_length = sizeof seam->synthetic_psk;
  memcpy (secure_view->dac_values, values, sizeof values);
  production_digest (seam->validator, sizeof seam->validator,
                     secure_view->e4_validator_sha256);
  production_digest (seam->a2, sizeof seam->a2,
                     secure_view->a2_response_sha256);
  production_digest (seam->chip, sizeof seam->chip,
                     secure_view->chip82_response_sha256);
  production_digest (seam->otp, sizeof seam->otp,
                     secure_view->otp_a6_response_sha256);
  production_digest (seam->config, sizeof seam->config,
                     secure_view->config90_sha256);
  *owner = (GoodixRuntimeCoordinator *) g_malloc0 (1u);
  if (seam->cancel_after_acquire)
    g_cancellable_cancel (
      fpi_device_get_cancellable (FP_DEVICE (seam->device)));
  return TRUE;
}

static void
production_material_release_seam (GoodixRuntimeCoordinator *owner,
                                  gpointer                  user_data)
{
  ProductionOpenSeam *seam = user_data;

  seam->material_release_count++;
  g_string_append_c (seam->events, 'F');
  g_free (owner);
}

static gboolean
production_claim_seam (GUsbDevice *usb_device,
                       guint8      interface_number,
                       gpointer    user_data,
                       GError    **error)
{
  ProductionOpenSeam *seam = user_data;
  GoodixDeviceContext *ctx =
    goodix_fpimage_device_get_context (seam->device);

  (void) usb_device;
  g_assert_cmpuint (interface_number, ==, 0u);
  g_assert_true (goodix_device_context_has_runtime_material (ctx));
  g_assert_false (goodix_device_context_has_usb_claim (ctx));
  seam->claim_count++;
  g_string_append_c (seam->events, 'C');
  if (seam->fail_claim)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                           "synthetic interface claim failure");
      return FALSE;
    }
  return TRUE;
}

static gboolean
production_release_seam (GUsbDevice *usb_device,
                         guint8      interface_number,
                         gpointer    user_data,
                         GError    **error)
{
  ProductionOpenSeam *seam = user_data;
  GoodixDeviceContext *ctx =
    goodix_fpimage_device_get_context (seam->device);

  (void) usb_device;
  g_assert_cmpuint (interface_number, ==, 0u);
  g_assert_true (goodix_device_context_has_runtime_material (ctx));
  g_assert_true (goodix_device_context_has_usb_claim (ctx));
  seam->interface_release_count++;
  g_string_append_c (seam->events, 'R');
  if (seam->fail_release)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                           "synthetic interface release failure");
      return FALSE;
    }
  return TRUE;
}

static TestFixture *
production_fixture_new (ProductionOpenSeam *seam)
{
  g_autoptr(GUsbDevice) usb_device = NULL;
  TestFixture *f;

  goodix_test_gusb_reset_counts ();
  goodix_test_gusb_set_open_close_success (TRUE);
  usb_device = (GUsbDevice *) g_object_new (G_USB_TYPE_DEVICE, NULL);
  f = test_fixture_new_with_device (
    goodix_fpimage_device_new_for_usb (usb_device));
  seam->device = f->device;
  seam->events = g_string_new (NULL);
  production_material_init (seam);
  goodix_fpimage_device_set_production_open_seams (
    f->device, production_acquire_seam, production_material_release_seam,
    production_claim_seam, production_release_seam, seam);
  return f;
}

static void
production_seam_clear (ProductionOpenSeam *seam)
{
  if (seam->events != NULL)
    g_string_free (seam->events, TRUE);
  seam->events = NULL;
  memset (seam->synthetic_psk, 0, sizeof seam->synthetic_psk);
  memset (seam->validator, 0, sizeof seam->validator);
  memset (seam->config, 0, sizeof seam->config);
  memset (seam->a2, 0, sizeof seam->a2);
  memset (seam->chip, 0, sizeof seam->chip);
  memset (seam->otp, 0, sizeof seam->otp);
}

static void
production_graph_submit_seam (GoodixFpiUsbBackend *backend,
                              GoodixUsbDirection   direction,
                              guint64              generation,
                              GBytes              *bytes,
                              gpointer             user_data)
{
  ProductionOpenSeam *seam = user_data;

  (void) backend;
  g_assert_cmpuint (generation, >, 0u);
  if (direction == GOODIX_USB_TRANSFER_IN)
    {
      g_assert_null (bytes);
      seam->in_submit_count++;
    }
  else
    {
      g_assert_nonnull (bytes);
      seam->out_submit_count++;
    }
}

static void
wait_for_context_state (GoodixDeviceContext      *ctx,
                        GoodixDeviceContextState  state)
{
  gint64 deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;

  while (goodix_device_context_get_state (ctx) != state &&
         g_get_monotonic_time () < deadline)
    g_main_context_iteration (NULL, TRUE);
  g_assert_cmpint (goodix_device_context_get_state (ctx), ==, state);
}

static void
test_d279_08_production_open_close_ownership (void)
{
  ProductionOpenSeam seam = { 0 };
  TestFixture *f = production_fixture_new (&seam);

  fixture_open (f);
  g_assert_false (goodix_device_context_has_runtime_material (f->ctx));
  g_assert_false (goodix_device_context_has_usb_claim (f->ctx));
  g_assert_cmpstr (seam.events->str, ==, "");
  fixture_close (f);
  g_assert_null (goodix_fpimage_device_get_context (f->device));
  g_assert_cmpstr (seam.events->str, ==, "");

  /* Discovery/open remains inert on every logical open. */
  fixture_open (f);
  fixture_close (f);
  g_assert_cmpstr (seam.events->str, ==, "");
  g_assert_cmpuint (seam.acquire_count, ==, 0u);
  g_assert_cmpuint (seam.claim_count, ==, 0u);
  g_assert_cmpuint (seam.interface_release_count, ==, 0u);
  g_assert_cmpuint (seam.material_release_count, ==, 0u);

  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_d279_08_production_open_failures (void)
{
  ProductionOpenSeam acquire_failure = { .fail_acquire = TRUE };
  ProductionOpenSeam claim_failure = { .fail_claim = TRUE };
  ProductionOpenSeam cancelled = { .cancel_after_acquire = TRUE };
  g_autoptr(GCancellable) cancellable = NULL;
  g_autoptr(FpPrint) template = NULL;
  TestFixture *f;

  f = production_fixture_new (&acquire_failure);
  fixture_open (f);
  template = fp_print_new (FP_DEVICE (f->device));
  f->done = FALSE;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template), NULL,
                    progress_cb, f, NULL, (GAsyncReadyCallback) enroll_cb, f);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_FAILED);
  g_assert_cmpstr (acquire_failure.events->str, ==, "A");
  g_clear_error (&f->error);
  fixture_close (f);
  test_fixture_free (f);
  production_seam_clear (&acquire_failure);

  f = production_fixture_new (&claim_failure);
  fixture_open (f);
  template = fp_print_new (FP_DEVICE (f->device));
  f->done = FALSE;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template), NULL,
                    progress_cb, f, NULL, (GAsyncReadyCallback) enroll_cb, f);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_FAILED);
  g_assert_cmpstr (claim_failure.events->str, ==, "ACF");
  g_assert_cmpuint (claim_failure.material_release_count, ==, 1u);
  g_assert_cmpuint (claim_failure.interface_release_count, ==, 0u);
  g_clear_error (&f->error);
  fixture_close (f);
  test_fixture_free (f);
  production_seam_clear (&claim_failure);

  f = production_fixture_new (&cancelled);
  fixture_open (f);
  cancellable = g_cancellable_new ();
  template = fp_print_new (FP_DEVICE (f->device));
  f->done = FALSE;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
  g_assert_cmpstr (cancelled.events->str, ==, "AF");
  g_assert_cmpuint (cancelled.claim_count, ==, 0u);
  g_assert_cmpuint (cancelled.material_release_count, ==, 1u);
  g_clear_error (&f->error);
  fixture_close (f);
  test_fixture_free (f);
  production_seam_clear (&cancelled);
}

static void
test_d279_08_production_release_failure (void)
{
  ProductionOpenSeam seam = { .fail_release = TRUE };
  TestFixture *f = production_fixture_new (&seam);
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  g_autoptr(GError) cancelled = NULL;
  guint64 generation;

  fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, production_graph_submit_seam, &seam);
  template = fp_print_new (FP_DEVICE (f->device));
  f->done = FALSE;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  generation = goodix_device_context_get_generation (f->ctx);
  g_cancellable_cancel (cancellable);
  cancelled = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_CANCELLED,
                                   "synthetic cancelled receive");
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           cancelled);
  test_wait (f);
  g_assert_false (f->success);
  g_clear_error (&f->error);
  f->done = FALSE;
  f->completion_count = 0;
  fp_device_close (FP_DEVICE (f->device), NULL,
                   (GAsyncReadyCallback) close_cb, f);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_FAILED);
  g_assert_cmpstr (seam.events->str, ==, "ACRF");
  g_assert_cmpuint (seam.material_release_count, ==, 1u);
  g_assert_null (goodix_fpimage_device_get_context (f->device));
  g_assert_cmpuint (goodix_test_gusb_get_close_count (), ==, 1u);

  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
login_expired (GoodixFpImageDevice *dev, gboolean ready, const char *reason, gpointer data)
{
  (void) dev;
  g_assert_false (ready);
  g_assert_nonnull (strstr (reason, "expired"));
  *((gboolean *) data) = TRUE;
}

static void
test_login_prepare_deadline (void)
{
  ProductionOpenSeam seam = { 0 };
  TestFixture *f = production_fixture_new (&seam);
  gboolean started = FALSE, expired = FALSE;
  fixture_open (f);
  g_signal_connect (f->device, "goodix-login-prepared", G_CALLBACK (login_expired), &expired);
  g_signal_emit_by_name (f->device, "goodix-login-prepare", &started);
  g_assert_false (started);
  g_assert_false (expired);
  g_assert_false (goodix_device_context_get_poisoned (f->ctx));
  g_assert_cmpuint (seam.out_submit_count, ==, 0);
  fixture_close (f);
  g_assert_cmpstr (seam.events->str, ==, "");
  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_login_prepare_close_pending_rx (void)
{
  ProductionOpenSeam seam = { 0 };
  TestFixture *f = production_fixture_new (&seam);
  gboolean started = FALSE;
  fixture_open (f);
  g_signal_emit_by_name (f->device, "goodix-login-prepare", &started);
  g_assert_false (started);
  g_assert_cmpint (fpi_device_get_current_action (FP_DEVICE (f->device)), ==,
                   FPI_DEVICE_ACTION_NONE);
  g_assert_cmpuint (seam.acquire_count, ==, 0);
  g_assert_cmpuint (seam.claim_count, ==, 0);
  g_assert_cmpuint (seam.in_submit_count, ==, 0);
  g_assert_cmpuint (seam.out_submit_count, ==, 0);
  g_signal_emit_by_name (f->device, "goodix-login-prepare", &started);
  g_assert_false (started);
  g_assert_cmpuint (seam.in_submit_count, ==, 0);
  f->done = FALSE;
  fp_device_close (FP_DEVICE (f->device), NULL, (GAsyncReadyCallback) close_cb, f);
  test_wait (f);
  g_assert_true (f->success);
  g_assert_null (goodix_fpimage_device_get_context (f->device));
  g_assert_cmpstr (seam.events->str, ==, "");
  /* Ordinary next open remains inert as well. */
  fixture_open (f);
  fixture_close (f);
  g_assert_cmpstr (seam.events->str, ==, "");
  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_d279_09_production_activation_binding (void)
{
  ProductionOpenSeam seam = { 0 };
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  g_autoptr(GError) timeout = NULL;
  g_autoptr(GError) cancelled = NULL;
  TestFixture *f = production_fixture_new (&seam);
  GoodixFpiUsbBackend *backend;
  GoodixPreSessionRxSyncAudit sync_audit;
  guint64 generation;

  fixture_open (f);
  backend = goodix_device_context_get_fpi_usb_backend (f->ctx);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, production_graph_submit_seam, &seam);

  f->done = FALSE;
  f->completion_count = 0;
  template = fp_print_new (FP_DEVICE (f->device));
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  generation = goodix_device_context_get_generation (f->ctx);
  g_assert_cmpuint (generation, >, 0u);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING);
  g_assert_cmpuint (seam.in_submit_count, ==, 1u);
  g_assert_cmpuint (seam.out_submit_count, ==, 0u);
  g_assert_cmpint (goodix_fpi_usb_backend_get_receive_purpose (backend), ==,
                   GOODIX_USB_RECEIVE_PRE_SESSION_SYNC_RX);

  timeout = g_error_new_literal (G_USB_DEVICE_ERROR,
                                 G_USB_DEVICE_ERROR_TIMED_OUT,
                                 "synthetic quiet boundary");
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           timeout);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_ACTIVE);
  g_assert_cmpint (f->last_state, ==,
                   FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON);
  g_assert_nonnull (goodix_device_context_get_secure_session (f->ctx));
  g_assert_nonnull (goodix_device_context_get_post_tls_lifecycle (f->ctx));
  g_assert_true (goodix_device_context_runtime_handoff_views_cleared (f->ctx));
  g_assert_cmpuint (seam.out_submit_count, ==, 1u);
  g_assert_cmpuint (seam.in_submit_count, ==, 2u);
  goodix_device_context_get_pre_session_rx_sync_audit (f->ctx, &sync_audit);
  g_assert_cmpint (sync_audit.pre_session_rx_result, ==,
                   GOODIX_PRE_SESSION_RX_SYNC_PASS);
  g_assert_true (sync_audit.first_protocol_out_after_rx_sync);

  g_cancellable_cancel (cancellable);
  wait_for_context_state (f->ctx, GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING);
  cancelled = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_CANCELLED,
                                   "synthetic cancelled transfer");
  goodix_fpi_usb_backend_complete_out (backend, generation, cancelled);
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           cancelled);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_true (goodix_device_context_has_runtime_material (f->ctx));
  g_assert_cmpuint (seam.material_release_count, ==, 0u);

  fixture_close (f);
  g_assert_cmpstr (seam.events->str, ==, "ACRF");
  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_d279_09_production_activation_sync_failure (void)
{
  ProductionOpenSeam seam = { 0 };
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(GCancellable) enroll_cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  g_autoptr(FpPrint) first_template = NULL;
  g_autoptr(GError) transport_error = NULL;
  TestFixture *f = production_fixture_new (&seam);
  GLogLevelFlags old_fatal;
  guint in_submits_before;
  guint out_submits_before;
  guint64 generation;

  fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, production_graph_submit_seam, &seam);
  f->done = FALSE;
  f->completion_count = 0;
  first_template = fp_print_new (FP_DEVICE (f->device));
  fp_device_enroll (FP_DEVICE (f->device),
                    g_steal_pointer (&first_template), cancellable,
                    progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  generation = goodix_device_context_get_generation (f->ctx);
  transport_error = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_FAILED,
                                         "synthetic sync transport failure");
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           transport_error);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_FAILED);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_cmpuint (seam.out_submit_count, ==, 0u);
  g_assert_cmpuint (seam.in_submit_count, ==, 1u);

  /* The enrollment policy gate must not mask an existing sticky poison. */
  in_submits_before = seam.in_submit_count;
  out_submits_before = seam.out_submit_count;
  template = fp_print_new (FP_DEVICE (f->device));
  g_clear_error (&f->error);
  f->done = FALSE;
  f->completion_count = 0;
  old_fatal = g_log_set_always_fatal (0);
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    enroll_cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  g_log_set_always_fatal (old_fatal);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_FAILED);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0u);
  g_assert_cmpuint (seam.in_submit_count, ==, in_submits_before);
  g_assert_cmpuint (seam.out_submit_count, ==, out_submits_before);
  fixture_close (f);
  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_d279_28_production_enrollment_starts_reviewed_graph (void)
{
  ProductionOpenSeam seam = { 0 };
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  g_autoptr(GError) timeout = NULL;
  g_autoptr(GError) cancelled = NULL;
  TestFixture *f = production_fixture_new (&seam);
  GoodixProductionEnrollmentAudit audit;
  GoodixFpiUsbBackend *backend;
  guint64 generation;

  fixture_open (f);
  backend = goodix_device_context_get_fpi_usb_backend (f->ctx);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, production_graph_submit_seam, &seam);
  template = fp_print_new (FP_DEVICE (f->device));
  f->done = FALSE;
  f->completion_count = 0;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  generation = goodix_device_context_get_generation (f->ctx);
  g_assert_cmpuint (generation, >, 0u);
  g_assert_cmpuint (seam.in_submit_count, ==, 1u);
  g_assert_cmpuint (seam.out_submit_count, ==, 0u);
  timeout = g_error_new_literal (G_USB_DEVICE_ERROR,
                                 G_USB_DEVICE_ERROR_TIMED_OUT,
                                 "synthetic host-side receive deadline");
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           timeout);
  g_assert_nonnull (goodix_device_context_get_secure_session (f->ctx));
  g_assert_nonnull (goodix_device_context_get_post_tls_lifecycle (f->ctx));
  g_assert_true (goodix_device_context_has_pending_enrollment_graph (f->ctx));
  goodix_device_context_get_production_enrollment_audit (f->ctx, &audit);
  g_assert_true (audit.production_action_consumed);
  g_assert_cmpuint (seam.out_submit_count, ==, 1u);

  g_cancellable_cancel (cancellable);
  wait_for_context_state (f->ctx, GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING);
  cancelled = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_CANCELLED,
                                   "synthetic cancelled transfer");
  goodix_fpi_usb_backend_complete_out (backend, generation, cancelled);
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           cancelled);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
  fixture_close (f);
  goodix_fpimage_device_get_production_enrollment_audit (f->device, &audit);
  g_assert_true (audit.context_closed);
  g_assert_false (audit.usb_interface_claimed);
  g_assert_true (audit.usb_backend_drained);
  g_assert_false (audit.runtime_material_present);
  g_assert_cmpuint (audit.usb_outstanding_count, ==, 0u);
  g_assert_cmpuint (audit.usb_out_outstanding_count, ==, 0u);
  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_d279_28_production_non_enrollment_rejected (void)
{
  ProductionOpenSeam seam = { 0 };
  TestFixture *f = production_fixture_new (&seam);
  GoodixProductionEnrollmentAudit audit;

  fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, production_graph_submit_seam, &seam);
  f->done = FALSE;
  f->completion_count = 0u;
  fp_device_capture (FP_DEVICE (f->device), TRUE, NULL,
                     (GAsyncReadyCallback) capture_cb, f);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_SUPPORTED);
  g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, 0u);
  g_assert_cmpuint (seam.in_submit_count, ==, 0u);
  g_assert_cmpuint (seam.out_submit_count, ==, 0u);
  goodix_device_context_get_production_enrollment_audit (f->ctx, &audit);
  g_assert_false (audit.production_action_consumed);
  fixture_close (f);
  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_p6_e4_contract_diagnostics (void)
{
  guint8 body[41] = {
    0x00, 0x03, 0x00, 0x02, 0xbb, 0x20, 0x00, 0x00, 0x00
  };
  guint8 validator[32];
  guint8 validator_sha256[32];

  memset (validator, 0xa5, sizeof validator);
  memcpy (body + 9, validator, sizeof validator);
  production_digest (validator, sizeof validator, validator_sha256);
  g_assert_cmpint (goodix_secure_session_test_check_e4_contract (
                     body, sizeof body, validator, validator_sha256),
                   ==, GOODIX_E4_CONTRACT_MATCH);

  body[0] ^= 1u;
  g_assert_cmpint (goodix_secure_session_test_check_e4_contract (
                     body, sizeof body, validator, validator_sha256),
                   ==, GOODIX_E4_CONTRACT_PREFIX_MISMATCH);
  body[0] ^= 1u;

  body[9] ^= 1u;
  {
    GoodixE4ContractResult result =
      goodix_secure_session_test_check_e4_contract (
        body, sizeof body, validator, validator_sha256);

    g_assert_cmpint (result, ==, GOODIX_E4_CONTRACT_VALIDATOR_MISMATCH);
    g_assert_cmpint (goodix_secure_session_test_e4_failure_kind (result), ==,
                     GOODIX_PROTOCOL_FAILURE_TYPED_VALUE_MISMATCH);
    g_assert_cmpstr (goodix_secure_session_test_e4_failure_message (result),
                     ==,
                     "E4 live validator differs from the expected pairing state");
  }
  body[9] ^= 1u;

  validator_sha256[0] ^= 1u;
  g_assert_cmpint (goodix_secure_session_test_check_e4_contract (
                     body, sizeof body, validator, validator_sha256),
                   ==, GOODIX_E4_CONTRACT_DIGEST_MISMATCH);
  validator_sha256[0] ^= 1u;

  g_assert_cmpint (goodix_secure_session_test_check_e4_contract (
                     body, sizeof body - 1u, validator, validator_sha256),
                   ==, GOODIX_E4_CONTRACT_BODY_LENGTH_MISMATCH);

  g_assert_true (goodix_fpimage_device_test_action_requires_live_preflight (
    FPI_DEVICE_ACTION_IDENTIFY));
  g_assert_true (goodix_fpimage_device_test_action_requires_live_preflight (
    FPI_DEVICE_ACTION_ENROLL));
  g_assert_true (goodix_fpimage_device_test_action_requires_live_preflight (
    FPI_DEVICE_ACTION_VERIFY));
}

/* --- P6 production pairing activation integration (offline fake USB) --- */

static const guint8 pairing_graph_provider_guid[16] = {
  0xd0, 0x8c, 0x9d, 0xdf, 0x01, 0x15, 0xd1, 0x11,
  0x8c, 0x7a, 0x00, 0xc0, 0x4f, 0xc2, 0x97, 0xeb
};

typedef struct
{
  guint64 generation;
  GBytes *bytes;
} PairingGraphSubmission;

typedef struct
{
  GoodixFpImageDevice *device;
  guint64 generation;
  guint in_submit_count;
  guint out_submit_count;
  guint e0_frame_count;
  guint e4_typed_index;
  guint claim_count;
  guint interface_release_count;
  guint8 bb010002[GOODIX_BB010002_LENGTH];
  guint8 otp[GOODIX_CONFIG90_OTP_LENGTH];
  guint8 live_validator[32];
  guint8 expected_validator[32];
  guint8 psk[GOODIX_SELF_STATE_PSK_LENGTH];
  GQueue *out;
  GByteArray *server_record;
} PairingGraphSeam;

typedef struct
{
  SSL_CTX *context;
  SSL *ssl;
  const guint8 *psk;
  gsize psk_length;
} PairingGraphTlsClient;

static void
pairing_graph_put_u32 (guint8 *data,
                       gsize  *cursor,
                       guint32 value)
{
  data[(*cursor)++] = (guint8) value;
  data[(*cursor)++] = (guint8) (value >> 8);
  data[(*cursor)++] = (guint8) (value >> 16);
  data[(*cursor)++] = (guint8) (value >> 24);
}

static void
pairing_graph_put_pattern (guint8 *data,
                           gsize  *cursor,
                           gsize   length,
                           guint8  seed)
{
  for (gsize i = 0; i < length; i++)
    data[(*cursor)++] = (guint8) (seed + (guint8) i);
}

static void
pairing_graph_make_bb010002 (guint8 data[GOODIX_BB010002_LENGTH])
{
  static const guint8 description[64] = {
    'T', 0, 'h', 0, 'i', 0, 's', 0, ' ', 0, 'i', 0, 's', 0, ' ', 0,
    't', 0, 'h', 0, 'e', 0, ' ', 0, 'd', 0, 'e', 0, 's', 0, 'c', 0,
    'r', 0, 'i', 0, 'p', 0, 't', 0, 'i', 0, 'o', 0, 'n', 0, ' ', 0,
    's', 0, 't', 0, 'r', 0, 'i', 0, 'n', 0, 'g', 0, '.', 0, 0, 0
  };
  gsize cursor = 0;

  memset (data, 0, GOODIX_BB010002_LENGTH);
  pairing_graph_put_u32 (data, &cursor, 1u);
  memcpy (data + cursor, pairing_graph_provider_guid,
          sizeof pairing_graph_provider_guid);
  cursor += sizeof pairing_graph_provider_guid;
  pairing_graph_put_u32 (data, &cursor, 1u);
  pairing_graph_put_pattern (data, &cursor, 16u, 0x31u);
  pairing_graph_put_u32 (data, &cursor, 4u);
  pairing_graph_put_u32 (data, &cursor, sizeof description);
  memcpy (data + cursor, description, sizeof description);
  cursor += sizeof description;
  pairing_graph_put_u32 (data, &cursor, 0x6610u);
  pairing_graph_put_u32 (data, &cursor, 256u);
  pairing_graph_put_u32 (data, &cursor, 32u);
  pairing_graph_put_pattern (data, &cursor, 32u, 0x51u);
  pairing_graph_put_u32 (data, &cursor, 0u);
  pairing_graph_put_u32 (data, &cursor, 0x800eu);
  pairing_graph_put_u32 (data, &cursor, 512u);
  pairing_graph_put_u32 (data, &cursor, 32u);
  pairing_graph_put_pattern (data, &cursor, 32u, 0x71u);
  pairing_graph_put_u32 (data, &cursor, 48u);
  pairing_graph_put_pattern (data, &cursor, 48u, 0x91u);
  pairing_graph_put_u32 (data, &cursor, 64u);
  pairing_graph_put_pattern (data, &cursor, 64u, 0xb1u);
  pairing_graph_put_pattern (data, &cursor, 8u, 0xf1u);
  g_assert_cmpuint (cursor, ==, GOODIX_BB010002_LENGTH);
}

static gchar *
pairing_graph_new_directory (const gchar *name_template)
{
  gchar *directory = g_dir_make_tmp (name_template, NULL);

  g_assert_nonnull (directory);
  g_assert_cmpint (g_chmod (directory, 0700), ==, 0);
  return directory;
}

static void
pairing_graph_remove_directory (const gchar *directory)
{
  GDir *dir = g_dir_open (directory, 0, NULL);
  const gchar *name;

  g_assert_nonnull (dir);
  while ((name = g_dir_read_name (dir)) != NULL)
    {
      g_autofree gchar *path = g_build_filename (directory, name, NULL);
      g_assert_cmpint (g_unlink (path), ==, 0);
    }
  g_dir_close (dir);
  g_assert_cmpint (g_rmdir (directory), ==, 0);
}

static void
pairing_graph_submission_free (PairingGraphSubmission *submission)
{
  if (submission == NULL)
    return;
  g_bytes_unref (submission->bytes);
  g_free (submission);
}

static void
pairing_graph_submit_seam (GoodixFpiUsbBackend *backend,
                           GoodixUsbDirection   direction,
                           guint64              generation,
                           GBytes              *bytes,
                           gpointer             user_data)
{
  PairingGraphSeam *seam = user_data;
  PairingGraphSubmission *submission;

  (void) backend;
  g_assert_cmpuint (generation, >, 0u);
  if (direction == GOODIX_USB_TRANSFER_IN)
    {
      g_assert_null (bytes);
      seam->in_submit_count++;
      return;
    }
  g_assert_nonnull (bytes);
  seam->out_submit_count++;
  {
    gsize length;
    const guint8 *data = g_bytes_get_data (bytes, &length);
    g_assert_cmpuint (length, >=, 5u);
    if (data[4] == 0xe0u)
      seam->e0_frame_count++;
  }
  submission = g_new0 (PairingGraphSubmission, 1);
  submission->generation = generation;
  submission->bytes = g_bytes_ref (bytes);
  g_queue_push_tail (seam->out, submission);
}

static PairingGraphSubmission *
pairing_graph_pop_out (PairingGraphSeam *seam)
{
  PairingGraphSubmission *submission = g_queue_pop_head (seam->out);

  g_assert_nonnull (submission);
  return submission;
}

static const guint8 *
pairing_graph_submission_data (PairingGraphSubmission *submission,
                               gsize                  *length)
{
  return g_bytes_get_data (submission->bytes, length);
}

static void
pairing_graph_complete_out (TestFixture              *f,
                            PairingGraphSubmission   *submission,
                            const GError             *error)
{
  goodix_fpi_usb_backend_complete_out (
    goodix_device_context_get_fpi_usb_backend (f->ctx),
    submission->generation, error);
  pairing_graph_submission_free (submission);
}

static void
pairing_graph_clear_queue (PairingGraphSeam *seam)
{
  while (!g_queue_is_empty (seam->out))
    pairing_graph_submission_free (g_queue_pop_head (seam->out));
}

static gboolean
pairing_graph_claim_seam (GUsbDevice *usb_device,
                          guint8      interface_number,
                          gpointer    user_data,
                          GError    **error)
{
  PairingGraphSeam *seam = user_data;

  (void) usb_device;
  (void) error;
  g_assert_cmpuint (interface_number, ==, 0u);
  seam->claim_count++;
  return TRUE;
}

static gboolean
pairing_graph_release_seam (GUsbDevice *usb_device,
                            guint8      interface_number,
                            gpointer    user_data,
                            GError    **error)
{
  PairingGraphSeam *seam = user_data;

  (void) usb_device;
  (void) interface_number;
  (void) error;
  seam->interface_release_count++;
  return TRUE;
}

static TestFixture *
pairing_graph_fixture_new (PairingGraphSeam *seam,
                           const gchar      *state_directory,
                           const gchar      *legacy_directory,
                           const guint8     *psk)
{
  g_autoptr(GUsbDevice) usb_device = NULL;
  TestFixture *f;

  goodix_test_gusb_reset_counts ();
  goodix_test_gusb_set_open_close_success (TRUE);
  usb_device = (GUsbDevice *) g_object_new (G_USB_TYPE_DEVICE, NULL);
  f = test_fixture_new_with_device (
    goodix_fpimage_device_new_for_usb (usb_device));
  seam->device = f->device;
  goodix_fpimage_device_set_production_open_seams (
    f->device, NULL, NULL, pairing_graph_claim_seam,
    pairing_graph_release_seam, seam);
  goodix_fpimage_device_test_set_production_state_override (
    state_directory, legacy_directory, getuid (), getgid (), psk);
  return f;
}

static GBytes *
pairing_graph_frame (guint8        control,
                     const guint8 *body,
                     gsize         length)
{
  return goodix_a0_build_frame (control, control, body, length, NULL);
}

static void
pairing_graph_deliver (TestFixture *f,
                       GBytes      *frame)
{
  gsize length;
  const guint8 *data = g_bytes_get_data (frame, &length);

  goodix_device_context_complete_receive (
    f->ctx, goodix_device_context_get_generation (f->ctx), data, length,
    NULL);
}

static GBytes *
pairing_graph_e4_typed (guint32       type,
                        const guint8 *payload,
                        gsize         payload_length)
{
  g_autofree guint8 *body = g_malloc0 (9u + payload_length);
  gsize cursor = 1u;

  pairing_graph_put_u32 (body, &cursor, type);
  pairing_graph_put_u32 (body, &cursor, (guint32) payload_length);
  memcpy (body + cursor, payload, payload_length);
  return pairing_graph_frame (0xe4u, body, 9u + payload_length);
}

static void
pairing_graph_start_identify (TestFixture      *f,
                              PairingGraphSeam *seam,
                              GCancellable     *cancellable)
{
  g_autoptr(GPtrArray) gallery = g_ptr_array_new_with_free_func (
    g_object_unref);
  g_autoptr(GError) timeout = g_error_new_literal (
    G_USB_DEVICE_ERROR, G_USB_DEVICE_ERROR_TIMED_OUT,
    "synthetic quiet boundary");
  guint in_before = seam->in_submit_count;

  f->done = FALSE;
  f->completion_count = 0;
  f->success = FALSE;
  g_clear_error (&f->error);
  fp_device_identify (FP_DEVICE (f->device), gallery, cancellable,
                      NULL, NULL, NULL, (GAsyncReadyCallback) identify_cb, f);
  seam->generation = goodix_device_context_get_generation (f->ctx);
  g_assert_cmpuint (seam->generation, >, 0u);
  g_assert_cmpuint (seam->in_submit_count, ==, in_before + 1u);
  goodix_device_context_complete_receive (f->ctx, seam->generation, NULL, 0,
                                          timeout);
}

static void
pairing_graph_respond_preflight (TestFixture      *f,
                                 PairingGraphSeam *seam,
                                 guint8            expected_control)
{
  static const guint8 a2_body[] = { 0x00, 0x00, 0x00 };
  static const guint8 app_body[] = "GF_ST411SEC_APP_12509";
  static const guint8 chip_body[] = { 0x5a, 0x04, 0x25, 0xa5 };
  PairingGraphSubmission *submission = pairing_graph_pop_out (seam);
  guint8 ack_body[2];
  g_autoptr(GBytes) ack = NULL;
  g_autoptr(GBytes) typed = NULL;
  gsize out_length;
  const guint8 *out = pairing_graph_submission_data (submission,
                                                     &out_length);

  g_assert_cmpuint (out_length, >=, 5u);
  g_assert_cmphex (out[0], ==, 0xa0u);
  g_assert_cmphex (out[4], ==, expected_control);
  pairing_graph_complete_out (f, submission, NULL);
  ack_body[0] = expected_control;
  ack_body[1] = 0x01u;
  ack = pairing_graph_frame (0xb0u, ack_body, sizeof ack_body);
  switch (expected_control)
    {
    case 0xa2u:
      typed = pairing_graph_frame (0xa2u, a2_body, sizeof a2_body);
      break;
    case 0xa8u:
      typed = pairing_graph_frame (0xa8u, app_body, sizeof app_body);
      break;
    case 0x82u:
      typed = pairing_graph_frame (0x82u, chip_body, sizeof chip_body);
      break;
    case 0xa6u:
      typed = pairing_graph_frame (0xa6u, seam->otp, sizeof seam->otp);
      break;
    case 0xe4u:
      typed = seam->e4_typed_index++ == 0u ?
        pairing_graph_e4_typed (0xbb010002u, seam->bb010002,
                                sizeof seam->bb010002) :
        pairing_graph_e4_typed (0xbb020003u, seam->live_validator,
                                sizeof seam->live_validator);
      break;
    default:
      g_assert_not_reached ();
    }
  pairing_graph_deliver (f, ack);
  pairing_graph_deliver (f, typed);
}

static void
pairing_graph_run_preflight (TestFixture      *f,
                             PairingGraphSeam *seam)
{
  static const guint8 controls[] =
    { 0xa2u, 0xa8u, 0xe4u, 0xe4u, 0xa2u, 0x82u, 0xa6u };

  seam->e4_typed_index = 0u;
  for (guint i = 0; i < G_N_ELEMENTS (controls); i++)
    pairing_graph_respond_preflight (f, seam, controls[i]);
}

static void
pairing_graph_complete_e0 (TestFixture      *f,
                           PairingGraphSeam *seam)
{
  static const guint8 e0_ack_body[] = { 0xe0u, 0x01u };
  static const guint8 e0_done_body[] = { 0x00u, 0x03u };
  PairingGraphSubmission *submission = pairing_graph_pop_out (seam);
  g_autoptr(GBytes) ack = pairing_graph_frame (0xb0u, e0_ack_body,
                                               sizeof e0_ack_body);
  g_autoptr(GBytes) done = pairing_graph_frame (0xe0u, e0_done_body,
                                                sizeof e0_done_body);
  gsize out_length;
  const guint8 *out = pairing_graph_submission_data (submission,
                                                     &out_length);

  g_assert_cmphex (out[4], ==, 0xe0u);
  g_assert_cmpuint (out_length, ==, GOODIX_PAIRING_PROVISION_E0_FRAME_LENGTH);
  g_assert_cmpuint (seam->e0_frame_count, ==, 1u);
  pairing_graph_complete_out (f, submission, NULL);
  pairing_graph_deliver (f, ack);
  pairing_graph_deliver (f, done);
}

static void
pairing_graph_respond_readback (TestFixture      *f,
                                PairingGraphSeam *seam,
                                guint32           type,
                                const guint8     *payload,
                                gsize             payload_length)
{
  static const guint8 e4_ack_body[] = { 0xe4u, 0x01u };
  PairingGraphSubmission *submission = pairing_graph_pop_out (seam);
  g_autoptr(GBytes) ack = pairing_graph_frame (0xb0u, e4_ack_body,
                                               sizeof e4_ack_body);
  g_autoptr(GBytes) typed = pairing_graph_e4_typed (type, payload,
                                                    payload_length);
  gsize out_length;
  const guint8 *out = pairing_graph_submission_data (submission,
                                                     &out_length);

  g_assert_cmphex (out[4], ==, 0xe4u);
  pairing_graph_complete_out (f, submission, NULL);
  pairing_graph_deliver (f, ack);
  pairing_graph_deliver (f, typed);
}

static void
pairing_graph_assert_state_phase (PairingGraphSeam    *seam,
                                  const gchar         *state_directory,
                                  GoodixSelfStatePhase phase,
                                  guint64              generation)
{
  GoodixSelfStateBinding binding = { 0 };
  GoodixSelfStatePolicy policy;
  GoodixSelfState *state = NULL;
  GoodixConfig90Calibration calibration = { 0 };
  guint8 config90[GOODIX_CONFIG90_LENGTH];

  g_assert_true (goodix_config90_derive (0x2504u, seam->otp,
                                         sizeof seam->otp, config90,
                                         &calibration, NULL));
  binding.vid = 0x27c6u;
  binding.pid = 0x5125u;
  binding.chip_profile = 0x2504u;
  g_strlcpy (binding.app, "APP12509", sizeof binding.app);
  production_digest (seam->otp, sizeof seam->otp, binding.otp_sha256);
  production_digest (config90, sizeof config90, binding.config90_sha256);
  goodix_self_state_policy_for_owner (&policy, getuid (), getgid ());
  g_assert_cmpint (goodix_self_state_load (state_directory, &binding, &policy,
                                           &state, NULL), ==,
                   GOODIX_SELF_STATE_LOAD_VALID);
  g_assert_cmpint (goodix_self_state_get_record (state)->phase, ==, phase);
  g_assert_cmpuint (goodix_self_state_get_record (state)->generation, ==,
                    generation);
  goodix_self_state_free (state);
}

static guint8
pairing_graph_secure_control (GoodixSecurePhase phase)
{
  switch (phase)
    {
    case GOODIX_SECURE_PHASE_A8: return 0xa8;
    case GOODIX_SECURE_PHASE_E4: return 0xe4;
    case GOODIX_SECURE_PHASE_REENTRY_RECOVERY_A2:
    case GOODIX_SECURE_PHASE_OEM_COLD_START_A2_1:
    case GOODIX_SECURE_PHASE_OEM_COLD_START_A2_2: return 0xa2;
    case GOODIX_SECURE_PHASE_CHIP_82: return 0x82;
    case GOODIX_SECURE_PHASE_OTP_A6: return 0xa6;
    case GOODIX_SECURE_PHASE_MODE_70: return 0x70;
    case GOODIX_SECURE_PHASE_DAC_220:
    case GOODIX_SECURE_PHASE_DAC_236:
    case GOODIX_SECURE_PHASE_DAC_238:
    case GOODIX_SECURE_PHASE_DAC_23A: return 0x80;
    case GOODIX_SECURE_PHASE_CONFIG_90: return 0x90;
    case GOODIX_SECURE_PHASE_D1: return 0xd1;
    default: return 0;
    }
}

static GBytes *
pairing_graph_secure_typed (PairingGraphSeam *seam,
                            GoodixSecurePhase phase)
{
  static const guint8 a2_body[] = { 0x00, 0x00, 0x00 };
  static const guint8 app_body[] = "GF_ST411SEC_APP_12509";
  static const guint8 chip_body[] = { 0x5a, 0x04, 0x25, 0xa5 };
  static const guint8 done90[] = { 1, 0 };
  guint8 e4[41] = { 0x00, 0x03, 0x00, 0x02, 0xbb, 0x20, 0, 0, 0 };

  switch (phase)
    {
    case GOODIX_SECURE_PHASE_A8:
      return pairing_graph_frame (0xa8, app_body, sizeof app_body);
    case GOODIX_SECURE_PHASE_E4:
      memcpy (e4 + 9, seam->expected_validator,
              sizeof seam->expected_validator);
      return pairing_graph_frame (0xe4, e4, sizeof e4);
    case GOODIX_SECURE_PHASE_REENTRY_RECOVERY_A2:
    case GOODIX_SECURE_PHASE_OEM_COLD_START_A2_1:
    case GOODIX_SECURE_PHASE_OEM_COLD_START_A2_2:
      return pairing_graph_frame (0xa2, a2_body, sizeof a2_body);
    case GOODIX_SECURE_PHASE_CHIP_82:
      return pairing_graph_frame (0x82, chip_body, sizeof chip_body);
    case GOODIX_SECURE_PHASE_OTP_A6:
      return pairing_graph_frame (0xa6, seam->otp, sizeof seam->otp);
    case GOODIX_SECURE_PHASE_CONFIG_90:
      return pairing_graph_frame (0x90, done90, sizeof done90);
    default:
      return NULL;
    }
}

static void
pairing_graph_respond_secure (TestFixture      *f,
                              PairingGraphSeam *seam)
{
  GoodixSecureSession *session =
    goodix_device_context_get_secure_session (f->ctx);
  GoodixSecurePhase phase = goodix_secure_session_get_phase (session);
  PairingGraphSubmission *submission = pairing_graph_pop_out (seam);
  guint8 control = pairing_graph_secure_control (phase);
  guint8 ack_body[2];
  g_autoptr(GBytes) ack = NULL;
  g_autoptr(GBytes) typed = NULL;
  gsize length;
  const guint8 *data = pairing_graph_submission_data (submission, &length);

  g_assert_cmpuint (length, !=, 64u);
  g_assert_cmphex (data[0], ==, 0xa0u);
  g_assert_cmphex (data[4], ==, control);
  pairing_graph_complete_out (f, submission, NULL);
  if (phase == GOODIX_SECURE_PHASE_D1)
    return;
  ack_body[0] = control;
  ack_body[1] = 0x01u;
  ack = pairing_graph_frame (0xb0u, ack_body, sizeof ack_body);
  typed = pairing_graph_secure_typed (seam, phase);
  pairing_graph_deliver (f, ack);
  if (typed != NULL)
    pairing_graph_deliver (f, typed);
}

static unsigned int
pairing_graph_client_psk_cb (SSL          *ssl,
                             const char   *hint,
                             char         *identity,
                             unsigned int  identity_max,
                             unsigned char *psk,
                             unsigned int  psk_max)
{
  PairingGraphTlsClient *client = SSL_get_app_data (ssl);

  (void) hint;
  g_strlcpy (identity, "Client_identity", identity_max);
  g_assert_cmpuint (psk_max, >=, client->psk_length);
  memcpy (psk, client->psk, client->psk_length);
  return (unsigned int) client->psk_length;
}

static void
pairing_graph_client_init (PairingGraphTlsClient *client,
                           PairingGraphSeam      *seam)
{
  BIO *input;
  BIO *output;

  memset (client, 0, sizeof *client);
  client->psk = seam->psk;
  client->psk_length = sizeof seam->psk;
  client->context = SSL_CTX_new (TLS_client_method ());
  g_assert_nonnull (client->context);
  g_assert_cmpint (SSL_CTX_set_min_proto_version (client->context,
                                                  TLS1_2_VERSION), ==, 1);
  g_assert_cmpint (SSL_CTX_set_max_proto_version (client->context,
                                                  TLS1_2_VERSION), ==, 1);
  g_assert_cmpint (SSL_CTX_set_cipher_list (client->context,
                                            "PSK-AES128-GCM-SHA256"), ==, 1);
  SSL_CTX_set_psk_client_callback (client->context,
                                   pairing_graph_client_psk_cb);
  client->ssl = SSL_new (client->context);
  g_assert_nonnull (client->ssl);
  SSL_set_app_data (client->ssl, client);
  input = BIO_new (BIO_s_mem ());
  output = BIO_new (BIO_s_mem ());
  g_assert_nonnull (input);
  g_assert_nonnull (output);
  BIO_set_mem_eof_return (input, -1);
  SSL_set_bio (client->ssl, input, output);
  SSL_set_connect_state (client->ssl);
}

static void
pairing_graph_client_clear (PairingGraphTlsClient *client)
{
  SSL_free (client->ssl);
  SSL_CTX_free (client->context);
}

static void
pairing_graph_feed_client_records (TestFixture         *f,
                                   PairingGraphTlsClient *client)
{
  GoodixSecureSession *session =
    goodix_device_context_get_secure_session (f->ctx);
  guint8 buffer[8192];
  int read_length;
  g_autoptr(GByteArray) pending = g_byte_array_new ();

  while ((read_length = BIO_read (SSL_get_wbio (client->ssl), buffer,
                                  sizeof buffer)) > 0)
    g_byte_array_append (pending, buffer, (guint) read_length);
  while (pending->len >= 5)
    {
      gsize record_length = 5u + ((gsize) pending->data[3] << 8) +
                            pending->data[4];
      guint8 header[4];
      g_autoptr(GByteArray) b0 = NULL;

      if (pending->len < record_length)
        break;
      if (goodix_secure_session_get_phase (session) ==
            GOODIX_SECURE_PHASE_TERMINAL)
        {
          g_byte_array_set_size (pending, 0);
          break;
        }
      header[0] = 0xb0;
      header[1] = (guint8) record_length;
      header[2] = (guint8) (record_length >> 8);
      header[3] = (guint8) (header[0] + header[1] + header[2]);
      b0 = g_byte_array_sized_new ((guint) record_length + 4u);
      g_byte_array_append (b0, header, sizeof header);
      g_byte_array_append (b0, pending->data, (guint) record_length);
      goodix_device_context_complete_receive (
        f->ctx, goodix_device_context_get_generation (f->ctx),
        b0->data, b0->len, NULL);
      g_byte_array_remove_range (pending, 0, (guint) record_length);
    }
  g_assert_cmpuint (pending->len, ==, 0u);
}

static void
pairing_graph_drain_server_records (TestFixture           *f,
                                    PairingGraphSeam      *seam,
                                    PairingGraphTlsClient *client)
{
  GoodixSecureSession *session =
    goodix_device_context_get_secure_session (f->ctx);

  if (g_queue_is_empty (seam->out) &&
      goodix_secure_session_get_phase (session) !=
        GOODIX_SECURE_PHASE_STOP &&
      goodix_secure_session_get_phase (session) !=
        GOODIX_SECURE_PHASE_TERMINAL)
    {
      /* Bounds only the host-side wait for the session's record pacing. */
      gint64 host_deadline = g_get_monotonic_time () + 1000000;

      while (g_queue_is_empty (seam->out) &&
             g_get_monotonic_time () < host_deadline)
        g_main_context_iteration (NULL, FALSE);
    }
  while (!g_queue_is_empty (seam->out))
    {
      PairingGraphSubmission *submission = pairing_graph_pop_out (seam);
      gsize length;
      const guint8 *data = pairing_graph_submission_data (submission,
                                                          &length);

      if (goodix_secure_session_get_phase (session) ==
            GOODIX_SECURE_PHASE_STOP &&
          length != 0 && data[0] == 0xa0)
        {
          g_queue_push_head (seam->out, submission);
          break;
        }
      g_assert_cmpuint (length, ==, 64u);
      g_byte_array_append (seam->server_record, data, (guint) length);
      if (seam->server_record->len >= 4)
        {
          guint16 payload_length = (guint16) (
            (guint16) seam->server_record->data[1] |
            (guint16) ((guint16) seam->server_record->data[2] << 8));
          gsize logical_length = (gsize) payload_length + 4u;

          if (seam->server_record->len >= logical_length)
            {
              g_assert_cmphex (seam->server_record->data[0], ==, 0xb0);
              g_assert_cmphex (seam->server_record->data[3], ==,
                               (guint8) (0xb0u +
                                         seam->server_record->data[1] +
                                         seam->server_record->data[2]));
              g_assert_cmpint (
                BIO_write (SSL_get_rbio (client->ssl),
                           seam->server_record->data + 4, payload_length),
                ==, (int) payload_length);
              g_byte_array_set_size (seam->server_record, 0);
            }
        }
      pairing_graph_complete_out (f, submission, NULL);
    }
  g_assert_cmpuint (seam->server_record->len, ==, 0u);
}

static gboolean
pairing_graph_pump_tls (TestFixture           *f,
                        PairingGraphSeam      *seam,
                        PairingGraphTlsClient *client)
{
  GoodixSecureSession *session =
    goodix_device_context_get_secure_session (f->ctx);

  for (guint iteration = 0; iteration < 64u; iteration++)
    {
      int result = SSL_do_handshake (client->ssl);

      if (result != 1)
        {
          int ssl_error = SSL_get_error (client->ssl, result);

          if (ssl_error != SSL_ERROR_WANT_READ &&
              ssl_error != SSL_ERROR_WANT_WRITE)
            return FALSE;
        }
      pairing_graph_feed_client_records (f, client);
      pairing_graph_drain_server_records (f, seam, client);
      if (SSL_is_init_finished (client->ssl) &&
          goodix_secure_session_get_phase (session) ==
            GOODIX_SECURE_PHASE_STOP)
        return TRUE;
      if (goodix_secure_session_get_phase (session) ==
            GOODIX_SECURE_PHASE_TERMINAL)
        return FALSE;
    }
  return FALSE;
}

static void
pairing_graph_drive_secure_to_stop (TestFixture      *f,
                                    PairingGraphSeam *seam)
{
  PairingGraphTlsClient client;
  GoodixSecureSession *session =
    goodix_device_context_get_secure_session (f->ctx);

  g_assert_nonnull (session);
  while (goodix_secure_session_get_phase (session) < GOODIX_SECURE_PHASE_D1)
    pairing_graph_respond_secure (f, seam);
  pairing_graph_respond_secure (f, seam);
  pairing_graph_client_init (&client, seam);
  g_assert_true (pairing_graph_pump_tls (f, seam, &client));
  pairing_graph_client_clear (&client);
  g_assert_cmpint (goodix_secure_session_get_phase (session), ==,
                   GOODIX_SECURE_PHASE_STOP);
}

static void
pairing_graph_cancel_and_close (TestFixture      *f,
                                PairingGraphSeam *seam,
                                GCancellable     *cancellable)
{
  GoodixFpiUsbBackend *backend =
    goodix_device_context_get_fpi_usb_backend (f->ctx);
  g_autoptr(GError) cancelled = g_error_new_literal (
    G_IO_ERROR, G_IO_ERROR_CANCELLED, "synthetic cancelled transfer");
  gint64 deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;

  g_cancellable_cancel (cancellable);
  while (!f->done && g_get_monotonic_time () < deadline)
    {
      while (!g_queue_is_empty (seam->out))
        pairing_graph_complete_out (f, pairing_graph_pop_out (seam),
                                    cancelled);
      if (goodix_fpi_usb_backend_get_outstanding (backend) != 0u)
        goodix_device_context_complete_receive (
          f->ctx, seam->generation, NULL, 0, cancelled);
      g_main_context_iteration (NULL, FALSE);
    }
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
  g_clear_error (&f->error);
  fixture_close (f);
}

static void
pairing_graph_close_tolerant (TestFixture *f)
{
  f->done = FALSE;
  f->completion_count = 0;
  fp_device_close (FP_DEVICE (f->device), NULL,
                   (GAsyncReadyCallback) close_cb, f);
  test_wait (f);
  g_clear_error (&f->error);
  f->success = TRUE;
  g_assert_null (goodix_fpimage_device_get_context (f->device));
}

static void
pairing_graph_seam_init (PairingGraphSeam *seam,
                         const guint8      psk[GOODIX_SELF_STATE_PSK_LENGTH],
                         guint8            validator_seed)
{
  guint8 envelope[GOODIX_PAIRING_ENVELOPE_LENGTH];

  memcpy (seam->psk, psk, sizeof seam->psk);
  g_assert_true (goodix_pairing_crypto_derive (
                   psk, GOODIX_SELF_STATE_PSK_LENGTH, envelope,
                   seam->expected_validator, NULL));
  pairing_graph_make_bb010002 (seam->bb010002);
  coordinator_make_otp (seam->otp);
  for (guint i = 0; i < sizeof seam->live_validator; i++)
    seam->live_validator[i] = (guint8) (validator_seed + (guint8) i);
  seam->out = g_queue_new ();
  seam->server_record = g_byte_array_new ();
}

static void
pairing_graph_seam_clear (PairingGraphSeam *seam)
{
  pairing_graph_clear_queue (seam);
  g_clear_pointer (&seam->out, g_queue_free);
  g_clear_pointer (&seam->server_record, g_byte_array_unref);
  memset (seam->psk, 0, sizeof seam->psk);
}

static void
test_p6_pairing_activation_production_graph (void)
{
  PairingGraphSeam seam = { 0 };
  TestFixture *f;
  g_autoptr(GCancellable) first_cancellable = g_cancellable_new ();
  g_autoptr(GCancellable) second_cancellable = g_cancellable_new ();
  g_autofree gchar *state_directory =
    pairing_graph_new_directory ("goodix-p6-pairing-state.XXXXXX");
  g_autofree gchar *legacy_directory =
    g_strconcat (state_directory, "-legacy-absent", NULL);
  guint8 psk[GOODIX_SELF_STATE_PSK_LENGTH];
  GoodixProductionEnrollmentAudit audit;

  for (guint i = 0; i < sizeof psk; i++)
    psk[i] = (guint8) (0x11u + i);
  pairing_graph_seam_init (&seam, psk, 0x70u);
  f = pairing_graph_fixture_new (&seam, state_directory, legacy_directory,
                                 psk);
  fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, pairing_graph_submit_seam, &seam);

  /* Epoch 1: read-only preflight, then exactly one qualified E0 pairing
   * transaction with both readbacks, then the strict secure session with a
   * real TLS 1.2 PSK handshake proving the new pairing. */
  pairing_graph_start_identify (f, &seam, first_cancellable);
  pairing_graph_run_preflight (f, &seam);
  pairing_graph_complete_e0 (f, &seam);
  pairing_graph_respond_readback (f, &seam, 0xbb010002u, seam.bb010002,
                                  sizeof seam.bb010002);
  pairing_graph_respond_readback (f, &seam, 0xbb020003u,
                                  seam.expected_validator,
                                  sizeof seam.expected_validator);
  g_assert_nonnull (goodix_device_context_get_secure_session (f->ctx));
  g_assert_cmpint (
    goodix_secure_session_get_phase (
      goodix_device_context_get_secure_session (f->ctx)), ==,
    GOODIX_SECURE_PHASE_REENTRY_RECOVERY_A2);
  pairing_graph_drive_secure_to_stop (f, &seam);

  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_ACTIVE);
  g_assert_nonnull (goodix_device_context_get_secure_session (f->ctx));
  g_assert_nonnull (goodix_device_context_get_post_tls_lifecycle (f->ctx));
  goodix_device_context_get_production_enrollment_audit (f->ctx, &audit);
  g_assert_true (audit.live_preflight.complete);
  g_assert_cmpuint (audit.live_preflight.command_count, ==, 7u);
  g_assert_cmpuint (audit.live_preflight.persistent_write_count, ==, 0u);
  g_assert_true (audit.pairing_activation.prepared_journaled);
  g_assert_true (audit.pairing_activation.e0_reserved_before_submit);
  g_assert_cmpuint (audit.pairing_activation.persistent_write_count, ==, 1u);
  g_assert_cmpuint (audit.pairing_activation.provision.logical_e0_count,
                    ==, 1u);
  g_assert_cmpuint (audit.pairing_activation.provision.retry_count, ==, 0u);
  g_assert_true (audit.pairing_activation.bb010002_readback_match);
  g_assert_true (audit.pairing_activation.validator_readback_match);
  g_assert_true (audit.pairing_activation.tls_proven);
  g_assert_true (audit.pairing_activation.active_promoted);
  g_assert_false (audit.pairing_activation.recovered_without_e0);
  g_assert_false (audit.pairing_activation.active_reused_without_e0);
  g_assert_cmpuint (audit.tls.handshake_count, ==, 1u);
  g_assert_cmpint (audit.runtime_coordinator.source, ==,
                   GOODIX_RUNTIME_COORDINATOR_SOURCE_STATE_V2);
  g_assert_cmpint (audit.runtime_coordinator.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_STATE_V2_PAIRING_ACTIVATION);
  g_assert_cmpint (audit.pairing_activation.disposition, ==,
                   GOODIX_PAIRING_ACTIVATION_DISPOSITION_NEW_PSK);
  g_assert_true (audit.runtime_coordinator.writer_enabled);
  g_assert_cmpuint (audit.runtime_coordinator.pairing_write_count, ==, 1u);
  g_assert_true (audit.runtime_coordinator.zero_fdt_seed);
  g_assert_cmpuint (seam.e0_frame_count, ==, 1u);
  pairing_graph_assert_state_phase (&seam, state_directory,
                                    GOODIX_SELF_STATE_ACTIVE, 2u);
  pairing_graph_cancel_and_close (f, &seam, first_cancellable);

  /* Epoch 2: the ordinary ACTIVE reopen proves the paired state read-only
   * and performs zero E0. */
  memcpy (seam.live_validator, seam.expected_validator,
          sizeof seam.live_validator);
  fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, pairing_graph_submit_seam, &seam);
  pairing_graph_start_identify (f, &seam, second_cancellable);
  pairing_graph_run_preflight (f, &seam);
  g_assert_cmpuint (seam.e0_frame_count, ==, 1u);
  g_assert_true (goodix_device_context_has_runtime_material (f->ctx));
  g_assert_nonnull (goodix_device_context_get_secure_session (f->ctx));
  goodix_device_context_get_production_enrollment_audit (f->ctx, &audit);
  g_assert_true (audit.live_preflight.complete);
  g_assert_cmpuint (audit.pairing_activation.persistent_write_count, ==, 0u);
  g_assert_false (audit.pairing_activation.prepared_journaled);
  g_assert_false (audit.pairing_activation.e0_reserved_before_submit);
  g_assert_false (audit.pairing_activation.tls_proven);
  g_assert_false (audit.pairing_activation.active_promoted);
  g_assert_cmpint (audit.runtime_coordinator.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_READY_ACTIVE);
  g_assert_cmpint (audit.pairing_activation.disposition, ==,
                   GOODIX_PAIRING_ACTIVATION_DISPOSITION_NONE);
  g_assert_cmpint (audit.runtime_coordinator.source, ==,
                   GOODIX_RUNTIME_COORDINATOR_SOURCE_STATE_V2);
  g_assert_false (audit.runtime_coordinator.writer_enabled);
  g_assert_cmpuint (audit.runtime_coordinator.pairing_write_count, ==, 0u);
  g_assert_true (audit.runtime_coordinator.zero_fdt_seed);
  pairing_graph_cancel_and_close (f, &seam, second_cancellable);

  test_fixture_free (f);
  goodix_fpimage_device_test_clear_production_state_override ();
  pairing_graph_seam_clear (&seam);
  pairing_graph_remove_directory (state_directory);
}

static void
test_p6_pairing_activation_fail_closed_after_reservation (void)
{
  PairingGraphSeam seam = { 0 };
  TestFixture *f;
  g_autoptr(GCancellable) first_cancellable = g_cancellable_new ();
  g_autoptr(GCancellable) second_cancellable = g_cancellable_new ();
  g_autofree gchar *state_directory =
    pairing_graph_new_directory ("goodix-p6-pairing-fail.XXXXXX");
  g_autofree gchar *legacy_directory =
    g_strconcat (state_directory, "-legacy-absent", NULL);
  guint8 psk[GOODIX_SELF_STATE_PSK_LENGTH];
  guint8 corrupted[GOODIX_BB010002_LENGTH];
  GoodixProductionEnrollmentAudit audit;

  for (guint i = 0; i < sizeof psk; i++)
    psk[i] = (guint8) (0x21u + i);
  pairing_graph_seam_init (&seam, psk, 0x90u);
  f = pairing_graph_fixture_new (&seam, state_directory, legacy_directory,
                                 psk);
  fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, pairing_graph_submit_seam, &seam);

  /* Epoch 1: the E0 is accepted but the BB010002 readback proof fails. */
  pairing_graph_start_identify (f, &seam, first_cancellable);
  pairing_graph_run_preflight (f, &seam);
  pairing_graph_complete_e0 (f, &seam);
  memcpy (corrupted, seam.bb010002, sizeof corrupted);
  corrupted[64] ^= 0xffu;
  pairing_graph_respond_readback (f, &seam, 0xbb010002u, corrupted,
                                  sizeof corrupted);
  pairing_graph_respond_readback (f, &seam, 0xbb020003u,
                                  seam.expected_validator,
                                  sizeof seam.expected_validator);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_nonnull (f->error);
  g_assert_true (goodix_device_context_get_poisoned (f->ctx));
  g_assert_cmpuint (seam.e0_frame_count, ==, 1u);
  goodix_device_context_get_production_enrollment_audit (f->ctx, &audit);
  g_assert_true (audit.pairing_activation.prepared_journaled);
  g_assert_true (audit.pairing_activation.e0_reserved_before_submit);
  g_assert_cmpuint (audit.pairing_activation.persistent_write_count, ==, 1u);
  g_assert_false (audit.pairing_activation.bb010002_readback_match);
  g_assert_false (audit.pairing_activation.validator_readback_match);
  g_assert_false (audit.pairing_activation.tls_proven);
  g_assert_false (audit.pairing_activation.active_promoted);
  pairing_graph_assert_state_phase (&seam, state_directory,
                                    GOODIX_SELF_STATE_PREPARED, 1u);
  g_clear_error (&f->error);
  f->success = TRUE;
  pairing_graph_close_tolerant (f);

  /* Epoch 2: the device still reports the stale validator, so the reserved
   * transaction is ambiguous.  Recovery must fail closed with zero E0. */
  fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, pairing_graph_submit_seam, &seam);
  pairing_graph_start_identify (f, &seam, second_cancellable);
  pairing_graph_run_preflight (f, &seam);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_nonnull (f->error);
  g_assert_cmpuint (seam.e0_frame_count, ==, 1u);
  goodix_device_context_get_production_enrollment_audit (f->ctx, &audit);
  g_assert_cmpint (audit.runtime_coordinator.decision, ==,
                   GOODIX_RUNTIME_COORDINATOR_DECISION_USE_PRIOR_REQUIRED);
  g_assert_cmpuint (audit.pairing_activation.persistent_write_count, ==, 0u);
  g_assert_false (audit.pairing_activation.prepared_journaled);
  g_assert_false (audit.pairing_activation.e0_reserved_before_submit);
  g_clear_error (&f->error);
  f->success = TRUE;
  pairing_graph_close_tolerant (f);

  test_fixture_free (f);
  goodix_fpimage_device_test_clear_production_state_override ();
  pairing_graph_seam_clear (&seam);
  pairing_graph_remove_directory (state_directory);
}

static void
test_d279_55_production_identify_single_acquisition (void)
{
  ProductionOpenSeam seam = { 0 };
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(GPtrArray) gallery = g_ptr_array_new_with_free_func (
    g_object_unref);
  g_autoptr(GError) timeout = NULL;
  g_autoptr(GError) cancelled = NULL;
  TestFixture *f = production_fixture_new (&seam);
  GoodixProductionEnrollmentAudit audit;
  GoodixFpiUsbBackend *backend;
  GoodixPostTlsLifecycle *post_tls;
  guint64 generation;

  fixture_open (f);
  backend = goodix_device_context_get_fpi_usb_backend (f->ctx);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, production_graph_submit_seam, &seam);
  f->done = FALSE;
  f->completion_count = 0u;
  fp_device_identify (FP_DEVICE (f->device), gallery, cancellable,
                      NULL, NULL, NULL,
                      (GAsyncReadyCallback) identify_cb, f);
  generation = goodix_device_context_get_generation (f->ctx);
  g_assert_cmpuint (generation, >, 0u);
  g_assert_cmpuint (seam.in_submit_count, ==, 1u);
  g_assert_cmpuint (seam.out_submit_count, ==, 0u);
  timeout = g_error_new_literal (G_USB_DEVICE_ERROR,
                                 G_USB_DEVICE_ERROR_TIMED_OUT,
                                 "synthetic host-side receive deadline");
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           timeout);
  post_tls = goodix_device_context_get_post_tls_lifecycle (f->ctx);
  g_assert_nonnull (goodix_device_context_get_secure_session (f->ctx));
  g_assert_nonnull (post_tls);
  g_assert_cmpint (goodix_post_tls_lifecycle_get_capture_profile (post_tls),
                   ==, GOODIX_POST_TLS_CAPTURE_PROFILE_SINGLE_ACQUISITION);
  g_assert_false (goodix_device_context_has_pending_enrollment_graph (f->ctx));
  goodix_device_context_get_production_enrollment_audit (f->ctx, &audit);
  g_assert_true (audit.production_action_consumed);
  g_assert_cmpuint (seam.out_submit_count, ==, 1u);

  g_cancellable_cancel (cancellable);
  wait_for_context_state (f->ctx, GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING);
  cancelled = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_CANCELLED,
                                   "synthetic cancelled transfer");
  goodix_fpi_usb_backend_complete_out (backend, generation, cancelled);
  goodix_device_context_complete_receive (f->ctx, generation, NULL, 0,
                                           cancelled);
  test_wait (f);
  g_assert_false (f->success);
  g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
  fixture_close (f);
  goodix_fpimage_device_get_production_enrollment_audit (f->device, &audit);
  g_assert_true (audit.context_closed);
  g_assert_false (audit.usb_interface_claimed);
  g_assert_true (audit.usb_backend_drained);
  g_assert_false (audit.runtime_material_present);
  g_assert_cmpuint (audit.usb_outstanding_count, ==, 0u);
  g_assert_cmpuint (audit.usb_out_outstanding_count, ==, 0u);
  test_fixture_free (f);
  production_seam_clear (&seam);
}

static void
test_d278_14_non_null_usb_binding (void)
{
  g_autoptr(GUsbDevice) usb_device = NULL;
  g_autoptr(GoodixFpImageDevice) device = NULL;
  GoodixDeviceContext *ctx;
  GoodixFpiUsbBackend *backend;
  GoodixUsbRouter *router;
  FpDeviceClass *device_class;

  goodix_test_gusb_reset_counts ();
  usb_device = (GUsbDevice *) g_object_new (G_USB_TYPE_DEVICE, NULL);
  g_assert_nonnull (usb_device);

  device = goodix_fpimage_device_new_for_usb (usb_device);
  g_assert_nonnull (device);
  g_assert_true (fpi_device_get_usb_device (FP_DEVICE (device)) == usb_device);
  device_class = FP_DEVICE_GET_CLASS (device);
  g_assert_cmpint (device_class->type, ==, FP_DEVICE_TYPE_USB);
  g_assert_cmpstr (device_class->id, ==, "goodix_27c6_5125");
  g_assert_cmpstr (device_class->full_name, ==,
                   "Goodix 27c6:5125 Fingerprint Sensor");
  g_assert_nonnull (device_class->id_table);
  g_assert_cmpuint (device_class->id_table[0].vid, ==, 0x27c6u);
  g_assert_cmpuint (device_class->id_table[0].pid, ==, 0x5125u);
  g_assert_cmpuint (device_class->id_table[0].driver_data, ==, 0u);
  g_assert_cmpuint (device_class->id_table[1].vid, ==, 0u);
  g_assert_cmpuint (device_class->id_table[1].pid, ==, 0u);
  g_assert_cmpuint (fpi_device_goodix_27c6_5125_get_type (), ==,
                    G_OBJECT_TYPE (device));

  ctx = goodix_fpimage_device_get_context (device);
  backend = goodix_device_context_get_fpi_usb_backend (ctx);
  router = goodix_device_context_get_usb_router (ctx);
  g_assert_nonnull (ctx);
  g_assert_nonnull (backend);
  g_assert_nonnull (router);
  g_assert_true (goodix_device_context_get_fpi_usb_backend (ctx) == backend);
  g_assert_true (goodix_device_context_get_usb_router (ctx) == router);
  g_assert_true (goodix_fpi_usb_backend_is_drained (backend));
  g_assert_cmpuint (goodix_fpi_usb_backend_get_outstanding (backend), ==, 0u);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_out_outstanding (backend), ==,
                    0u);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_real_submit_count (backend), ==,
                    0u);
  g_assert_cmpuint (goodix_test_gusb_get_open_count (), ==, 0u);
  g_assert_cmpuint (goodix_test_gusb_get_close_count (), ==, 0u);

  g_print ("NON_NULL_GUSBDEVICE_FPDEVICE_BINDING_HOST_ONLY_PROVEN=true\n");
}

static void
test_d282_direct_enroll_feature_profile (void)
{
  g_autoptr(GUsbDevice) usb_device = NULL;
  g_autoptr(GoodixFpImageDevice) device = NULL;

  usb_device = (GUsbDevice *) g_object_new (G_USB_TYPE_DEVICE, NULL);
  device = goodix_fpimage_device_new_for_usb (usb_device);
  g_assert_nonnull (device);

#ifdef GOODIX_PRODUCTION_FPRINTD_ACTION_PROFILE
  g_assert_true (fp_device_has_feature (
    FP_DEVICE (device), FP_DEVICE_FEATURE_IDENTIFY));
  g_assert_true (fp_device_has_feature (
    FP_DEVICE (device), FP_DEVICE_FEATURE_VERIFY));
  g_print ("D293_02_IDENTIFY_FEATURE_ADVERTISED=true\n");
  g_print ("D293_02_VERIFY_FEATURE_ADVERTISED=true\n");
#else
  g_assert_true (fp_device_has_feature (
    FP_DEVICE (device), FP_DEVICE_FEATURE_IDENTIFY));
#endif
}

static GBytes *
d279_24_build_response (guint8        control,
                        const guint8 *body,
                        gsize         body_length)
{
  g_autoptr(GError) error = NULL;
  GBytes *frame = goodix_a0_build_frame (
    control, control, body, body_length, &error);

  g_assert_no_error (error);
  g_assert_nonnull (frame);
  return frame;
}

static GBytes *
d279_24_build_ack (guint8 command)
{
  const guint8 body[2] = { command, 0x01 };

  return d279_24_build_response (0xb0, body, sizeof body);
}

static GBytes *
d279_24_build_event (guint8  control,
                     guint16 irq,
                     guint16 flags,
                     guint16 base)
{
  guint8 body[16];

  body[0] = (guint8) irq;
  body[1] = (guint8) (irq >> 8);
  body[2] = (guint8) flags;
  body[3] = (guint8) (flags >> 8);
  for (guint i = 0u; i < 6u; i++)
    {
      guint16 word = (guint16) (base + i * 2u);
      body[4u + i * 2u] = (guint8) word;
      body[5u + i * 2u] = (guint8) (word >> 8);
    }
  return d279_24_build_response (control, body, sizeof body);
}

static GBytes *
d279_24_build_nav (void)
{
  guint8 body[2409] = { 0x50, 0x01 };
  g_autoptr(GBytes) additive = d279_24_build_response (
    0x50, body, sizeof body);
  gsize length;
  const guint8 *source = g_bytes_get_data (additive, &length);
  guint8 *copy = g_memdup2 (source, length);

  copy[length - 1u] = 0x88;
  return g_bytes_new_take (copy, length);
}

static void
d279_24_complete_out (GoodixDeviceContext *ctx,
                      guint64              generation)
{
  GoodixFpiUsbBackend *backend =
    goodix_device_context_get_fpi_usb_backend (ctx);

  g_assert_cmpuint (goodix_fpi_usb_backend_get_out_outstanding (backend), ==,
                    1u);
  goodix_fpi_usb_backend_complete_out (backend, generation, NULL);
}

static gboolean
d279_24_auxiliary_ready (GBytes   *plaintext,
                         gpointer  user_data,
                         GError  **error)
{
  guint *count = user_data;

  (void) error;
  g_assert_nonnull (plaintext);
  (*count)++;
  return TRUE;
}

static guint32
d279_25_crc32_mpeg2 (const guint8 *data,
                     gsize         length)
{
  guint32 crc = UINT32_C (0xffffffff);

  for (gsize i = 0u; i < length; i++)
    {
      crc ^= (guint32) data[i] << 24;
      for (guint bit = 0u; bit < 8u; bit++)
        crc = (crc & UINT32_C (0x80000000)) != 0u ?
          (crc << 1) ^ UINT32_C (0x04c11db7) : crc << 1;
    }
  return crc;
}

static GBytes *
d279_25_build_primary_plaintext (guint stage)
{
  guint8 bytes[GOODIX_IMAGE_PLAINTEXT_LENGTH] = { 0 };
  guint32 crc;

  bytes[0] = 0x20;
  bytes[1] = 0x0a;
  bytes[2] = 0x1e;
  bytes[8u + stage] = (guint8) stage;
  crc = d279_25_crc32_mpeg2 (bytes + 8u, GOODIX_IMAGE_PACKED_LENGTH);
  bytes[7688] = (guint8) (crc >> 8);
  bytes[7689] = (guint8) crc;
  bytes[7690] = (guint8) (crc >> 24);
  bytes[7691] = (guint8) (crc >> 16);
  bytes[7692] = 0x88;
  return g_bytes_new (bytes, sizeof bytes);
}

static GBytes *
d279_25_wrap_b0 (GBytes *plaintext)
{
  gsize length;
  const guint8 *data = g_bytes_get_data (plaintext, &length);
  guint8 header[4];
  g_autoptr(GByteArray) frame = NULL;

  g_assert_cmpuint (length, <=, G_MAXUINT16);
  header[0] = 0xb0;
  header[1] = (guint8) length;
  header[2] = (guint8) (length >> 8);
  header[3] = (guint8) (header[0] + header[1] + header[2]);
  frame = g_byte_array_sized_new ((guint) length + 4u);
  g_byte_array_append (frame, header, sizeof header);
  g_byte_array_append (frame, data, (guint) length);
  return g_byte_array_free_to_bytes (g_steal_pointer (&frame));
}

static void
d279_25_feed_context_frame (GoodixDeviceContext *ctx,
                            guint64              generation,
                            GBytes              *frame)
{
  GoodixFpiUsbBackend *backend =
    goodix_device_context_get_fpi_usb_backend (ctx);
  gsize length;
  const guint8 *data = g_bytes_get_data (frame, &length);

  g_assert_cmpuint (goodix_fpi_usb_backend_get_outstanding (backend), ==, 1u);
  g_assert_cmpint (goodix_fpi_usb_backend_get_receive_purpose (backend), ==,
                   GOODIX_USB_RECEIVE_PROTOCOL_RX);
  goodix_device_context_complete_receive (
    ctx, generation, data, length, NULL);
  if (goodix_device_context_get_terminal_fence (ctx))
    {
      const GError *error = goodix_device_context_get_terminal_error (ctx);
      g_error ("D279/25 context fenced after input: %s",
               error != NULL ? error->message : "unknown error");
    }
}

static void
d279_25_complete_and_ack (GoodixDeviceContext *ctx,
                          guint64              generation,
                          guint8               command)
{
  g_autoptr(GBytes) ack = d279_24_build_ack (command);

  d279_24_complete_out (ctx, generation);
  d279_25_feed_context_frame (ctx, generation, ack);
}

static void
d279_25_feed_plaintext (GoodixDeviceContext *ctx,
                        guint64              generation,
                        GBytes              *plaintext)
{
  g_autoptr(GBytes) frame = d279_25_wrap_b0 (plaintext);

  d279_25_feed_context_frame (ctx, generation, frame);
}

static void
test_d279_24_context_first_arm_enrollment_handoff (gconstpointer scenario)
{
  GoodixEnrollmentModelConfig config = {
    .required_stage_count = GOODIX_SIGFM_ENROLL_REQUIRED_STAGES,
    .defer_terminal_stage_delivery = TRUE,
    .defer_intermediate_stage_delivery_until_release_ready = TRUE,
  };
  GoodixEnrollmentPostTlsEventsAudit events_audit;
  GoodixEnrollmentFpiUsbBindingAudit binding_audit;
  GoodixPostTlsMaterial material = { 0 };
  GoodixPostTlsAudit post_audit;
  TestFixture *f = test_fixture_new ();
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(FpPrint) template = NULL;
  g_autoptr(GError) error = NULL;
  GoodixFpiUsbBackend *backend;
  GoodixPostTlsLifecycle *post_tls;
  guint64 generation;
  guint auxiliary_count = 0u;
  guint8 af[16] = { 0 };
  const guint8 typed82_body[2] = { 0x00, 0x20 };
  g_autoptr(GBytes) baseline = d279_25_build_primary_plaintext (0u);

  fixture_open (f);
  backend = goodix_device_context_get_fpi_usb_backend (f->ctx);
  goodix_device_context_set_async_usb_submit_seam (
    f->ctx, host_only_usb_submit, NULL);
  template = fp_print_new (FP_DEVICE (f->device));
  f->done = FALSE;
  f->completion_count = 0u;
  f->enroll_progress_count = 0u;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template),
                    cancellable, progress_cb, f, NULL,
                    (GAsyncReadyCallback) enroll_cb, f);
  generation = goodix_device_context_get_generation (f->ctx);
  for (guint i = 0u; i < 6u; i++)
    {
      material.initial_fdt_table[i * 2u] = 0x80;
      material.initial_fdt_table[i * 2u + 1u] = (guint8) (0x40u + i);
    }
  material.af_timestamp = 0x1234;
  material.first_arm_timestamp = 0x2345;
  material.second_arm_timestamp = 0x3456;
  g_assert_true (goodix_device_context_configure_post_tls_lifecycle (
    f->ctx, &material, &post_audit, &error));
  g_assert_true (goodix_device_context_configure_enrollment_graph (
    f->ctx, &config, d279_24_auxiliary_ready, &auxiliary_count,
    &events_audit, &binding_audit, &error));
  g_assert_true (goodix_device_context_has_pending_enrollment_graph (f->ctx));
  g_assert_false (goodix_device_context_has_dormant_enrollment_binding (f->ctx));
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  g_assert_cmpint (f->last_state, ==,
                   FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON);
  post_tls = goodix_device_context_get_post_tls_lifecycle (f->ctx);
  g_assert_true (goodix_post_tls_lifecycle_start (post_tls, &error));

  d279_24_complete_out (f->ctx, generation);
  {
    g_autoptr(GBytes) frame = d279_24_build_ack (0xd4);
    goodix_post_tls_lifecycle_handle_a0 (post_tls, frame);
  }
  d279_24_complete_out (f->ctx, generation);
  af[1] = 0x02;
  {
    g_autoptr(GBytes) frame = d279_24_build_response (0xae, af, sizeof af);
    goodix_post_tls_lifecycle_handle_a0 (post_tls, frame);
  }
  for (guint fdt_index = 0u; fdt_index < 3u; fdt_index++)
    {
      d279_24_complete_out (f->ctx, generation);
      {
        g_autoptr(GBytes) ack = d279_24_build_ack (0x36);
        goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
      }
      {
        g_autoptr(GBytes) event = d279_24_build_event (
          0x36, 0x0100, 0x0000,
          (guint16) (0x0300u + fdt_index * 0x20u));
        goodix_post_tls_lifecycle_handle_a0 (post_tls, event);
      }
      if (fdt_index == 0u)
        {
          d279_24_complete_out (f->ctx, generation);
          {
            g_autoptr(GBytes) ack = d279_24_build_ack (0x50);
            g_autoptr(GBytes) nav = d279_24_build_nav ();
            goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, nav);
          }
        }
      else if (fdt_index == 1u)
        {
          d279_24_complete_out (f->ctx, generation);
          {
            g_autoptr(GBytes) ack = d279_24_build_ack (0x82);
            g_autoptr(GBytes) typed = d279_24_build_response (
              0x82, typed82_body, sizeof typed82_body);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, typed);
          }
          d279_24_complete_out (f->ctx, generation);
          {
            g_autoptr(GBytes) ack = d279_24_build_ack (0x20);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
            goodix_post_tls_lifecycle_handle_plaintext (post_tls, baseline);
          }
        }
    }
  d279_24_complete_out (f->ctx, generation);
  {
    g_autoptr(GBytes) ack = d279_24_build_ack (0x32);
    goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
  }

  g_assert_cmpint (goodix_post_tls_lifecycle_get_phase (post_tls), ==,
                   GOODIX_POST_TLS_PHASE_STOP);
  g_assert_cmpuint (post_audit.first_arm_handoff_count, ==, 1u);
  g_assert_cmpuint (post_audit.command_count, ==, 9u);
  g_assert_false (goodix_device_context_has_pending_enrollment_graph (f->ctx));
  g_assert_true (goodix_device_context_has_dormant_enrollment_binding (f->ctx));
  g_assert_cmpuint (auxiliary_count, ==, 0u);

  {
    g_autoptr(GBytes) irq = d279_20_build_irq2 ();
    gsize length;
    const guint8 *bytes = g_bytes_get_data (irq, &length);

    g_assert_true (goodix_device_context_arm_receive (f->ctx, &error));
    goodix_device_context_complete_receive (
      f->ctx, generation, bytes, length, NULL);
  }
  g_assert_cmpuint (binding_audit.graph_ready_submit_count, ==, 1u);
  g_assert_cmpuint (events_audit.irq2_count, ==, 1u);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_out_outstanding (backend), ==,
                    1u);
  d279_24_complete_out (f->ctx, generation);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_outstanding (backend), ==, 1u);
  g_assert_cmpint (goodix_fpi_usb_backend_get_receive_purpose (backend), ==,
                   GOODIX_USB_RECEIVE_PROTOCOL_RX);

  for (guint stage = 1u;
       stage <= GOODIX_SIGFM_ENROLL_REQUIRED_STAGES;
       stage++)
    {
      g_autoptr(GBytes) primary = d279_25_build_primary_plaintext (stage);
      const guint8 auxiliary_bytes[] = { 0x20, 0x01, 0x00, 0x88 };
      g_autoptr(GBytes) auxiliary = g_bytes_new_static (
        auxiliary_bytes, sizeof auxiliary_bytes);

      if (stage > 1u)
        {
          g_autoptr(GBytes) irq2 = d279_24_build_event (
            0x32, 0x0002, 0x002f, (guint16) (0x80u + stage * 8u));
          d279_25_feed_context_frame (f->ctx, generation, irq2);
          d279_25_complete_and_ack (f->ctx, generation, 0x22);
        }
      else
        {
          g_autoptr(GBytes) ack22 = d279_24_build_ack (0x22);
          d279_25_feed_context_frame (f->ctx, generation, ack22);
        }
      d279_25_feed_plaintext (f->ctx, generation, primary);
      d279_25_complete_and_ack (f->ctx, generation, 0x34);
      if (stage == 1u)
        {
          g_autoptr(GBytes) irq0200 = d279_24_build_event (
            0x34, 0x0200, 0x0000, 0x48);
          g_autoptr(GBytes) nav = d279_24_build_nav ();

          d279_25_feed_context_frame (f->ctx, generation, irq0200);
          d279_25_complete_and_ack (f->ctx, generation, 0x20);
          d279_25_feed_plaintext (f->ctx, generation, auxiliary);
          d279_25_complete_and_ack (f->ctx, generation, 0x32);
          d279_25_complete_and_ack (f->ctx, generation, 0x50);
          d279_25_feed_context_frame (f->ctx, generation, nav);
          d279_25_complete_and_ack (f->ctx, generation, 0x32);
        }
      else
        {
          g_autoptr(GBytes) irq0100 = d279_24_build_event (
            0x36, 0x0100, 0x003f, (guint16) (0x80u + stage * 8u));
          g_autoptr(GBytes) irq0200 = d279_24_build_event (
            0x34, 0x0200, 0x0000, (guint16) (0x40u + stage * 8u));

          d279_25_complete_and_ack (f->ctx, generation, 0x36);
          guint contact_case = GPOINTER_TO_UINT (scenario);
          if (contact_case >= 100u && stage == contact_case % 100u)
            {
              guint kind = contact_case / 100u;
              guint64 out_before = goodix_fpi_usb_backend_get_out_submit_count (backend);
              guint images_before = events_audit.lifecycle.plan.pipeline.fpimage_delivery_count;
              guint primary_before = events_audit.primary_b0_count;
              guint auxiliary_before = auxiliary_count;
              g_autoptr(GBytes) zero = d279_24_build_event (
                kind == 7u ? 0x34 : 0x36,
                kind == 5u ? 0x0200 : 0x0100,
                kind == 6u ? 0x0040 : 0, 0x88);
              gsize length;
              const guint8 *bytes = g_bytes_get_data (zero, &length);
              g_autofree guint8 *copy = g_memdup2 (bytes, length);
              if (kind == 4u) copy[length - 1u] ^= 1u;
              if (kind == 3u)
                {
                  g_cancellable_cancel (cancellable);
                  gint64 deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;
                  while (!goodix_device_context_get_terminal_fence (f->ctx) &&
                         g_get_monotonic_time () < deadline)
                    g_main_context_iteration (NULL, FALSE);
                }
              goodix_device_context_complete_receive (f->ctx, generation, copy, length, NULL);
              if (kind == 1u || kind == 8u || kind == 9u || kind == 10u)
                {
                  g_assert_false (goodix_device_context_get_terminal_fence (f->ctx));
                  g_assert_cmpuint (events_audit.lifecycle.plan.pipeline.fpimage_delivery_count, ==, images_before + 1u);
                  g_assert_cmpuint (auxiliary_count, ==, auxiliary_before);
                  /* Host extraction is asynchronous: no rearm before its normal
                   * next-sample request. A stale callback cannot supply it. */
                  g_assert_cmpuint (goodix_fpi_usb_backend_get_out_submit_count (backend), ==, out_before);
                  goodix_device_context_complete_receive (f->ctx, generation - 1u, copy, length, NULL);
                  if (kind == 8u)
                    d279_25_feed_context_frame (f->ctx, generation, irq0200);
                  gint64 deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;
                  while (f->enroll_progress_count < stage && !f->done &&
                         g_get_monotonic_time () < deadline)
                    g_main_context_iteration (NULL, FALSE);
                  g_assert_cmpuint (f->enroll_progress_count, ==, stage);
                  if (stage < GOODIX_SIGFM_ENROLL_REQUIRED_STAGES)
                    {
                      g_assert_cmpuint (goodix_fpi_usb_backend_get_out_submit_count (backend), ==, out_before + 1u);
                      g_assert_cmpuint (goodix_fpi_usb_backend_get_out_outstanding (backend), ==, 1u);
                      if (kind == 10u)
                        {
                          g_autoptr(GError) out_error = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_FAILED, "synthetic OUT32 error");
                          g_autoptr(GError) cancel_error = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_CANCELLED, "synthetic IN drain");
                          goodix_fpi_usb_backend_complete_out (backend, generation, out_error);
                          g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));
                          goodix_device_context_complete_receive (f->ctx, generation, NULL, 0, cancel_error);
                          test_wait (f);
                          g_assert_false (f->success);
                          g_assert_cmpuint (f->completion_count, ==, 1u);
                          g_assert_nonnull (strstr (f->error->message, "OUT32 error"));
                          g_assert_cmpuint (goodix_fpi_usb_backend_get_out_submit_count (backend), ==, out_before + 1u);
                          g_assert_true (goodix_fpi_usb_backend_is_drained (backend));
                          g_clear_error (&f->error);
                          fixture_close (f);
                          g_assert_null (goodix_fpimage_device_get_context (f->device));
                          test_fixture_free (f);
                          return;
                        }
                      if (kind == 9u)
                        d279_25_feed_context_frame (f->ctx, generation, irq0200);
                      d279_25_complete_and_ack (f->ctx, generation, 0x32);
                    }
                  else
                    g_assert_cmpuint (goodix_fpi_usb_backend_get_out_submit_count (backend), ==, out_before);
                  goto stage_done;
                }
              if (kind == 2u)
                {
                  g_cancellable_cancel (cancellable);
                  gint64 deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;
                  while (!goodix_device_context_get_terminal_fence (f->ctx) &&
                         g_get_monotonic_time () < deadline)
                    g_main_context_iteration (NULL, FALSE);
                }
              g_assert_true (goodix_device_context_get_terminal_fence (f->ctx));
              /* No direct OUT or duplicate zero can revive the terminated graph. */
              for (guint command = 0; command < 256u; command++)
                {
                  g_autoptr(GBytes) out = d279_24_build_response ((guint8) command, NULL, 0);
                  g_autoptr(GError) blocked = NULL;
                  g_assert_false (goodix_fpi_usb_backend_submit_out (backend, generation, out, &blocked));
                }
              goodix_device_context_complete_receive (f->ctx, generation, copy, length, NULL);
              test_wait (f);
              g_assert_false (f->success);
              g_assert_null (f->enroll_print);
              g_assert_cmpuint (f->completion_count, ==, 1u);
              g_assert_cmpuint (events_audit.rejected_inbound_count, ==, kind <= 3u ? 0u : 1u);
              if (kind == 1u)
                {
                  g_assert_error (f->error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_GENERAL);
                  g_assert_nonnull (strstr (f->error->message, "zero-mask contact unusable"));
                  g_assert_nonnull (strstr (f->error->message, "new enrollment manually"));
                }
              else if (kind <= 3u)
                g_assert_error (f->error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
              else
                {
                  g_assert_false (goodix_enrollment_post_tls_events_error_is_unusable_contact (f->error));
                  g_assert_cmpuint (events_audit.rejected_inbound_count, ==, 1u);
                }
              g_assert_cmpuint (events_audit.lifecycle.plan.pipeline.fpimage_delivery_count, ==, images_before + (kind == 2u ? 1u : 0u));
              g_assert_cmpuint (events_audit.primary_b0_count, ==, primary_before);
              g_assert_cmpuint (auxiliary_count, ==, auxiliary_before);
              g_assert_cmpuint (binding_audit.retry_count, ==, 0u);
              g_assert_cmpuint (events_audit.lifecycle.plan.pipeline.protocol.retry_stage_count, ==, 0u);
              g_assert_cmpuint (goodix_fpi_usb_backend_get_out_submit_count (backend), ==, out_before);
              g_assert_true (goodix_fpi_usb_backend_is_drained (backend));
              g_assert_cmpuint (goodix_fpi_usb_backend_get_outstanding (backend), ==, 0u);
              g_assert_cmpuint (goodix_fpi_usb_backend_get_out_outstanding (backend), ==, 0u);
              g_assert_cmpuint (goodix_fpi_usb_backend_get_real_submit_count (backend), ==, 0u);
              g_clear_error (&f->error);
              fixture_close (f);
              g_assert_null (goodix_fpimage_device_get_context (f->device));
              GoodixProductionEnrollmentAudit closed;
              goodix_fpimage_device_get_production_enrollment_audit (f->device, &closed);
              g_assert_true (closed.context_closed);
              g_assert_true (closed.usb_backend_drained);
              fixture_open (f);
              g_assert_false (goodix_device_context_get_poisoned (f->ctx));
              fixture_close (f);
              test_fixture_free (f);
              return;
            }
          d279_25_feed_context_frame (f->ctx, generation, irq0100);
          d279_25_complete_and_ack (f->ctx, generation, 0x20);
          d279_25_feed_plaintext (f->ctx, generation, auxiliary);
          d279_25_complete_and_ack (f->ctx, generation, 0x34);
          d279_25_feed_context_frame (f->ctx, generation, irq0200);
          if (stage < GOODIX_SIGFM_ENROLL_REQUIRED_STAGES)
            d279_25_complete_and_ack (f->ctx, generation, 0x32);
        }
stage_done:
      {
        gint64 deadline = g_get_monotonic_time () + TEST_TIMEOUT_MS * 1000;

        while (f->enroll_progress_count < stage && !f->done &&
               g_get_monotonic_time () < deadline)
          g_main_context_iteration (NULL, FALSE);
        g_assert_cmpuint (f->enroll_progress_count, ==, stage);
        if (stage < GOODIX_SIGFM_ENROLL_REQUIRED_STAGES)
          g_assert_cmpint (f->last_state, ==,
                           FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON);
      }
    }

  g_assert_true (events_audit.lifecycle.plan.pipeline.protocol.complete);
  g_assert_cmpuint (
    events_audit.lifecycle.plan.pipeline.protocol.configured_required_stage_count,
    ==, GOODIX_SIGFM_ENROLL_REQUIRED_STAGES);
  guint case_kind = GPOINTER_TO_UINT (scenario) / 100u;
  guint recovered = (case_kind == 1u || case_kind == 8u || case_kind == 9u) ? 1u : 0u;
  guint late = case_kind == 8u || case_kind == 9u ? 1u : 0u;
  g_assert_cmpuint (events_audit.parsed_a0_count, ==,
                    9u * GOODIX_SIGFM_ENROLL_REQUIRED_STAGES - 1u -
                    3u * recovered + late);
  g_assert_cmpuint (events_audit.primary_b0_count, ==,
                    GOODIX_SIGFM_ENROLL_REQUIRED_STAGES);
  g_assert_cmpuint (events_audit.auxiliary_b0_count, ==,
                    GOODIX_SIGFM_ENROLL_REQUIRED_STAGES - recovered);
  g_assert_cmpuint (events_audit.lifecycle.plan.pipeline.fpimage_delivery_count,
                    ==, GOODIX_SIGFM_ENROLL_REQUIRED_STAGES);
  g_assert_cmpuint (events_audit.finger_down_delivery_count, ==,
                    GOODIX_SIGFM_ENROLL_REQUIRED_STAGES);
  g_assert_cmpuint (events_audit.finger_up_delivery_count, ==,
                    GOODIX_SIGFM_ENROLL_REQUIRED_STAGES);
  g_assert_cmpuint (events_audit.auxiliary_b0_delivery_count, ==,
                    GOODIX_SIGFM_ENROLL_REQUIRED_STAGES - recovered);
  g_assert_cmpuint (auxiliary_count, ==, GOODIX_SIGFM_ENROLL_REQUIRED_STAGES - recovered);
  g_assert_cmpuint (binding_audit.graph_ready_submit_count, ==,
                    6u * GOODIX_SIGFM_ENROLL_REQUIRED_STAGES - 1u -
                    2u * recovered);
  g_assert_cmpuint (binding_audit.transaction.committed_after_completion_count,
                    ==, 6u * GOODIX_SIGFM_ENROLL_REQUIRED_STAGES - 1u -
                    2u * recovered);
  g_assert_cmpuint (binding_audit.retry_count, ==, 0u);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_outstanding (backend), ==, 0u);

  test_wait (f);
  g_assert_true (f->success);
  g_assert_nonnull (f->enroll_print);
  g_assert_cmpuint (f->completion_count, ==, 1u);
  g_assert_cmpint (goodix_device_context_get_state (f->ctx), ==,
                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
  g_assert_cmpuint (binding_audit.cancellation_count, ==, 0u);
  g_assert_false (binding_audit.terminal);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_real_submit_count (backend), ==,
                    0u);
  fixture_close (f);
  test_fixture_free (f);
  g_print ("D279_24_CONTEXT_FIRST_ARM_ENROLLMENT_HANDOFF=PASS\n");
  g_print ("ENROLLMENT_FIXED_21_CONTEXT_TRANSCRIPT=PASS\n");
}

static void
test_d279_20_dormant_enrollment_context_ownership (void)
{
  GoodixEnrollmentModelConfig config = {
    .required_stage_count = 2u,
    .defer_terminal_stage_delivery = TRUE,
  };
  GoodixEnrollmentPostTlsEventsAudit events_audit;
  GoodixEnrollmentFpiUsbBindingAudit binding_audit;
  GoodixEnrollmentPostTlsEventsAudit foreign_events_audit;
  GoodixEnrollmentFpiUsbBindingAudit foreign_binding_audit;
  g_autoptr(GCancellable) cancellable = g_cancellable_new ();
  g_autoptr(GError) error = NULL;
  g_autoptr(GError) cancelled = g_error_new_literal (
    G_IO_ERROR, G_IO_ERROR_CANCELLED, "synthetic context cancellation");
  g_autoptr(GBytes) irq = d279_20_build_irq2 ();
  GoodixFpImageDevice *device = goodix_fpimage_device_new ();
  GoodixDeviceContext *ctx = goodix_fpimage_device_get_context (device);
  GoodixFpiUsbBackend *backend =
    goodix_device_context_get_fpi_usb_backend (ctx);
  GoodixEnrollmentPostTlsEvents *events;
  GoodixEnrollmentFpiUsbBinding *binding;
  GoodixUsbRouter *foreign_router;
  GoodixFpiUsbBackend *foreign_backend;
  GoodixEnrollmentPostTlsEvents *foreign_events;
  GoodixEnrollmentFpiUsbBinding *foreign_binding;
  guint64 generation;

  goodix_device_context_set_async_usb_submit_seam (
    ctx, host_only_usb_submit, NULL);
  g_assert_true (goodix_device_context_begin_operator_epoch (
    ctx, cancellable, &error));
  generation = goodix_device_context_get_generation (ctx);

  foreign_router = goodix_usb_router_new (NULL, NULL, NULL);
  foreign_backend = goodix_fpi_usb_backend_new (
    NULL, foreign_router, 0x81, 0x01, 8192u);
  goodix_usb_router_begin_generation (foreign_router, generation);
  g_assert_true (goodix_fpi_usb_backend_begin_generation (
    foreign_backend, generation, cancellable, &error));
  foreign_events = goodix_enrollment_post_tls_events_new (
    &config, d279_20_image_ready, d279_20_timestamp_ready,
    d279_20_auxiliary_ready, NULL, &foreign_events_audit, &error);
  foreign_binding = goodix_enrollment_fpi_usb_binding_new (
    foreign_events, foreign_backend, generation, &foreign_binding_audit,
    &error);
  g_assert_nonnull (foreign_binding);
  g_assert_false (goodix_device_context_adopt_dormant_enrollment_binding (
    ctx, foreign_binding, &error));
  g_assert_error (error, G_IO_ERROR, G_IO_ERROR_CLOSED);
  g_clear_error (&error);
  g_assert_false (goodix_device_context_has_dormant_enrollment_binding (ctx));
  goodix_enrollment_fpi_usb_binding_free (foreign_binding);
  goodix_fpi_usb_backend_free (foreign_backend);
  goodix_usb_router_free (foreign_router);

  events = goodix_enrollment_post_tls_events_new (
    &config, d279_20_image_ready, d279_20_timestamp_ready,
    d279_20_auxiliary_ready, NULL, &events_audit, &error);
  g_assert_nonnull (events);
  binding = goodix_enrollment_fpi_usb_binding_new (
    events, backend, generation, &binding_audit, &error);
  g_assert_nonnull (binding);
  g_assert_true (goodix_device_context_adopt_dormant_enrollment_binding (
    ctx, binding, &error));
  g_assert_true (goodix_device_context_has_dormant_enrollment_binding (ctx));
  g_assert_true (goodix_enrollment_fpi_usb_binding_handle_a0 (
    binding, irq, &error));
  g_assert_cmpuint (goodix_fpi_usb_backend_get_out_outstanding (backend), ==,
                    1u);

  goodix_device_context_stop_operator_epoch (ctx);
  g_assert_true (goodix_enrollment_fpi_usb_binding_is_failed (binding));
  g_assert_cmpuint (binding_audit.cancellation_count, ==, 1u);
  g_assert_false (goodix_device_context_operator_epoch_is_drained (ctx));
  g_assert_cmpuint (events_audit.lifecycle.plan.committed_command_count, ==,
                    0u);

  goodix_fpi_usb_backend_complete_out (backend, generation, cancelled);
  g_assert_true (goodix_device_context_operator_epoch_is_drained (ctx));
  g_assert_cmpuint (events_audit.lifecycle.plan.committed_command_count, ==,
                    0u);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_real_submit_count (backend), ==,
                    0u);

  g_object_unref (device);
  g_print ("D279_20_DORMANT_CONTEXT_OWNERSHIP=PASS\n");
}

/* -------------------------------------------------------------
 * Main
 * ------------------------------------------------------------- */
static gboolean login_test_match;
static void
login_verify_done (FpDevice *device, GAsyncResult *res, gpointer data)
{
  TestFixture *f = data;
  f->success = fp_device_verify_finish (device, res, &login_test_match, NULL, &f->error);
  test_complete (f);
}

static void
login_identify_done (FpDevice *device, GAsyncResult *res, gpointer data)
{
  TestFixture *f = data;
  g_autoptr(FpPrint) match = NULL;
  f->success = fp_device_identify_finish (device, res, &match, NULL, &f->error);
  login_test_match = match != NULL;
  test_complete (f);
}

static void
test_login_series (gconstpointer data)
{
  /* Upper digit: terminal attempt; lower: 1 match, 0 no-match, 2 cancel,
   * 3 malformed protocol. Start after a synthetic secure-session handoff. */
  guint scenario = GPOINTER_TO_UINT (data) % 100, target = scenario / 10, outcome = scenario % 10;
  gboolean identify = GPOINTER_TO_UINT (data) >= 100;
  g_autoptr(GPtrArray) gallery = g_ptr_array_new ();
  TestFixture *f = test_fixture_new ();
  uint16_t samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  g_autoptr(FpPrint) template = NULL;
  g_autoptr(GError) error = NULL;
  GoodixPostTlsMaterial material = { .capture_profile = GOODIX_POST_TLS_CAPTURE_PROFILE_SINGLE_ACQUISITION };
  GoodixPostTlsAudit audit;
  goodix_test_sigfm_match_reset_audit ();
  guint8 af[16] = { 0 };
  const guint8 typed82_body[2] = { 0, 0x20 };
  g_autoptr(GBytes) baseline = d279_25_build_primary_plaintext (0);
  /* Obtain a real synthetic libfprint print, without reading any templates. */
  fixture_open (f);
  fpi_device_set_nr_enroll_stages (FP_DEVICE (f->device), 1);
  template = fp_print_new (FP_DEVICE (f->device));
  fill_gradient_samples (samples);
  f->done = FALSE;
  fp_device_enroll (FP_DEVICE (f->device), g_steal_pointer (&template), NULL,
                   progress_cb, f, NULL, (GAsyncReadyCallback) enroll_cb, f);
  goodix_device_context_emit_arm_complete (f->ctx, NULL);
  goodix_device_context_emit_finger_down (f->ctx);
  goodix_device_context_emit_image_ready (f->ctx, samples, G_N_ELEMENTS (samples));
  goodix_device_context_emit_release_tail_complete (f->ctx);
  goodix_device_context_emit_finger_up_ready (f->ctx);
  test_wait (f); g_assert_no_error (f->error);
  template = g_object_ref (f->enroll_print);
  g_ptr_array_add (gallery, template);
  fixture_close (f); fixture_open (f);
  goodix_device_context_set_async_usb_submit_seam (f->ctx, host_only_usb_submit, NULL);
  for (guint i = 0; i < 6; i++)
    { material.initial_fdt_table[i * 2] = 0x80; material.initial_fdt_table[i * 2 + 1] = (guint8) (0x40 + i); }
  g_assert_true (goodix_device_context_test_login_post_tls (f->ctx, &material, &audit, &error));
  GoodixPostTlsLifecycle *post_tls = goodix_device_context_get_post_tls_lifecycle (f->ctx);
  GoodixFpiUsbBackend *backend = goodix_device_context_get_fpi_usb_backend (f->ctx);
  guint64 generation = goodix_device_context_get_generation (f->ctx);
  d279_24_complete_out (f->ctx, generation);
  {
    g_autoptr(GBytes) frame = d279_24_build_ack (0xd4);
    goodix_post_tls_lifecycle_handle_a0 (post_tls, frame);
  }
  d279_24_complete_out (f->ctx, generation);
  af[1] = 0x02;
  {
    g_autoptr(GBytes) frame = d279_24_build_response (0xae, af, sizeof af);
    goodix_post_tls_lifecycle_handle_a0 (post_tls, frame);
  }
  for (guint fdt_index = 0u; fdt_index < 3u; fdt_index++)
    {
      d279_24_complete_out (f->ctx, generation);
      {
        g_autoptr(GBytes) ack = d279_24_build_ack (0x36);
        goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
      }
      {
        g_autoptr(GBytes) event = d279_24_build_event (
          0x36, 0x0100, 0x0000,
          (guint16) (0x0300u + fdt_index * 0x20u));
        goodix_post_tls_lifecycle_handle_a0 (post_tls, event);
      }
      if (fdt_index == 0u)
        {
          d279_24_complete_out (f->ctx, generation);
          {
            g_autoptr(GBytes) ack = d279_24_build_ack (0x50);
            g_autoptr(GBytes) nav = d279_24_build_nav ();
            goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, nav);
          }
        }
      else if (fdt_index == 1u)
        {
          d279_24_complete_out (f->ctx, generation);
          {
            g_autoptr(GBytes) ack = d279_24_build_ack (0x82);
            g_autoptr(GBytes) typed = d279_24_build_response (
              0x82, typed82_body, sizeof typed82_body);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, typed);
          }
          d279_24_complete_out (f->ctx, generation);
          {
            g_autoptr(GBytes) ack = d279_24_build_ack (0x20);
            goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
            goodix_post_tls_lifecycle_handle_plaintext (post_tls, baseline);
          }
        }
    }
  d279_24_complete_out (f->ctx, generation);
  {
    g_autoptr(GBytes) ack = d279_24_build_ack (0x32);
    goodix_post_tls_lifecycle_handle_a0 (post_tls, ack);
  }

  g_assert_cmpint (goodix_post_tls_lifecycle_get_phase (post_tls), ==, GOODIX_POST_TLS_PHASE_FIRST_IRQ2);
  for (guint attempt = 1; attempt <= target; attempt++)
    {
      g_autoptr(GCancellable) cancel = g_cancellable_new ();
      gboolean terminal = attempt == target;
      goodix_test_sigfm_match_set_score (terminal && outcome == 1 ? 100 : 0);
      /* Release arrives before matching on even attempts, after it on odd. */
      goodix_test_sigfm_extract_set_block (attempt % 2 == 0 && outcome != 4);
      f->done = FALSE;
      if (identify)
        fp_device_identify (FP_DEVICE (f->device), gallery, cancel, NULL, NULL, NULL,
                            (GAsyncReadyCallback) login_identify_done, f);
      else
        fp_device_verify (FP_DEVICE (f->device), template, cancel, NULL, NULL, NULL,
                          (GAsyncReadyCallback) login_verify_done, f);
      g_assert_false (f->done);
      if (attempt == 1)
        g_assert_true (goodix_device_context_arm_receive (f->ctx, &error));
      else
        d279_25_complete_and_ack (f->ctx, generation, 0x32);
      g_assert_cmpuint (goodix_device_context_get_generation (f->ctx), ==, generation);
      g_assert_cmpuint (audit.first_image_command_count, ==, attempt - 1);
      if (terminal && (outcome == 2 || outcome == 3))
        {
          if (outcome == 2) g_cancellable_cancel (cancel);
          else
            {
              g_autoptr(GBytes) bad = d279_24_build_event (0x32, 2, 0, 0x180);
              gsize n; const guint8 *bytes = g_bytes_get_data (bad, &n);
              goodix_device_context_complete_receive (f->ctx, generation, bytes, n, NULL);
            }
          if (goodix_fpi_usb_backend_get_outstanding (backend))
            {
              g_autoptr(GError) cancelled = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_CANCELLED, "cancelled RX");
              goodix_device_context_complete_receive (f->ctx, generation, NULL, 0, cancelled);
            }
          goodix_test_sigfm_extract_unblock ();
          test_wait (f); g_assert_false (f->success); g_clear_error (&f->error);
          break;
        }
      g_autoptr(GBytes) down = d279_24_build_event (0x32, 2, 0x3f, 0x180);
      d279_25_feed_context_frame (f->ctx, generation, down);
      d279_25_complete_and_ack (f->ctx, generation, 0x22);
      goodix_post_tls_lifecycle_handle_plaintext (post_tls, baseline);
      if (terminal && outcome == 4)
        while (goodix_test_sigfm_match_get_call_count () < attempt)
          g_main_context_iteration (NULL, TRUE);
      d279_25_complete_and_ack (f->ctx, generation, 0x34);
      g_assert_false (f->done); /* NO MATCH cannot complete before physical up. */
      g_autoptr(GBytes) up = d279_24_build_event (0x34, 0x200, 0, 0x120);
      d279_25_feed_context_frame (f->ctx, generation, up);
      d279_25_complete_and_ack (f->ctx, generation, 0x20);
      goodix_post_tls_lifecycle_handle_plaintext (post_tls, baseline);
      d279_25_complete_and_ack (f->ctx, generation, 0x50);
      g_autoptr(GBytes) nav = d279_24_build_nav ();
      /* Terminal completion fences after this receive; do not use the helper
       * that asserts every injection leaves the context unfenced. */
      gsize n; const guint8 *bytes = g_bytes_get_data (nav, &n);
      goodix_device_context_complete_receive (f->ctx, generation, bytes, n, NULL);
      goodix_test_sigfm_extract_unblock ();
      if (terminal && outcome == 4)
        {
          g_cancellable_cancel (cancel);
          test_wait (f); g_assert_false (f->success); g_clear_error (&f->error);
          break;
        }
      test_wait (f); g_assert_no_error (f->error); g_assert_true (f->success);
      g_assert_cmpint (login_test_match, ==, terminal && outcome == 1);
      g_assert_cmpuint (audit.first_image_command_count, ==, attempt);
      g_assert_true (goodix_fpi_usb_backend_is_drained (backend));
      if (!terminal) g_assert_false (goodix_device_context_get_terminal_fence (f->ctx));
    }
  if (target == 1 && outcome == 0)
    {
      fixture_close (f); g_assert_null (goodix_fpimage_device_get_context (f->device));
      test_fixture_free (f); goodix_test_sigfm_match_set_score (100); return;
    }
  guint images = audit.first_image_command_count;
  f->done = FALSE;
  fp_device_verify (FP_DEVICE (f->device), template, NULL, NULL, NULL, NULL,
                    (GAsyncReadyCallback) login_verify_done, f);
  test_wait (f); g_assert_false (f->success); g_clear_error (&f->error);
  g_assert_cmpuint (audit.first_image_command_count, ==, images);
  g_assert_cmpuint (audit.baseline_decode_count, ==, 1);
  g_assert_cmpuint (audit.fdt36_submit_count, ==, 3);
  g_assert_cmpuint (audit.d4_count, ==, 1);
  g_assert_cmpuint (audit.reopen_count, ==, 0);
  g_assert_cmpuint (goodix_fpi_usb_backend_get_real_submit_count (backend), ==, 0);
  fixture_close (f); g_assert_null (goodix_fpimage_device_get_context (f->device));
  test_fixture_free (f);
  goodix_test_sigfm_match_set_score (100);
}

int
main (int argc, char **argv)
{
  g_test_init (&argc, &argv, NULL);
  const guint contact_cases[] = { 102, 104, 119, 120, 202, 302, 402, 502, 602, 702, 802, 902, 1002 };
  const gchar *contact_names[] = { "stage2", "intermediate", "near-terminal", "terminal",
    "cancel-after-zero", "cancel-before-zero", "malformed", "wrong-irq", "reserved", "wrong-control", "late-before-host-result", "late-pending-out32", "out32-error" };
  for (guint i = 0; i < G_N_ELEMENTS (contact_cases); i++)
    {
      g_autofree gchar *path = g_strdup_printf ("/zero-recovery/%s", contact_names[i]);
      g_test_add_data_func (path, GUINT_TO_POINTER (contact_cases[i]),
                           test_d279_24_context_first_arm_enrollment_handoff);
    }


  g_test_add_data_func ("/login/identify-second-match", GUINT_TO_POINTER (121), test_login_series);
  g_test_add_data_func ("/login/identify-third-match", GUINT_TO_POINTER (131), test_login_series);
  g_test_add_data_func ("/login/cancel-after-release-before-completion", GUINT_TO_POINTER (14), test_login_series);
  g_test_add_data_func ("/login/close-between-attempts", GUINT_TO_POINTER (10), test_login_series);
  g_test_add_data_func ("/login/no-match-then-match", GUINT_TO_POINTER (21), test_login_series);
  g_test_add_data_func ("/login/two-no-match-then-match", GUINT_TO_POINTER (31), test_login_series);
  g_test_add_data_func ("/login/three-no-match-no-fourth", GUINT_TO_POINTER (30), test_login_series);
  g_test_add_data_func ("/login/cancel-first", GUINT_TO_POINTER (12), test_login_series);
  g_test_add_data_func ("/login/cancel-second", GUINT_TO_POINTER (22), test_login_series);
  g_test_add_data_func ("/login/protocol-error-first", GUINT_TO_POINTER (13), test_login_series);
  g_test_add_data_func ("/login/protocol-error-second", GUINT_TO_POINTER (23), test_login_series);
  g_test_add_func ("/login/prepare-close-drains-rx", test_login_prepare_close_pending_rx);
  g_test_add_func ("/login/preparation-deadline", test_login_prepare_deadline);

  g_test_add_func ("/p5-coordinator/migration-selection",
                   test_p5_coordinator_migration_selection);
  g_test_add_func ("/p5-coordinator/active-state",
                   test_p5_coordinator_active_state);
  g_test_add_func ("/p6/e4-contract-diagnostics",
                   test_p6_e4_contract_diagnostics);
  g_test_add_func ("/p6/pairing-activation-production-graph",
                   test_p6_pairing_activation_production_graph);
  g_test_add_func ("/p6/pairing-activation-fail-closed-after-reservation",
                   test_p6_pairing_activation_fail_closed_after_reservation);

  g_test_add_func ("/goodix-fpimage-device/lifecycle-base-capture",
                   test_lifecycle_base_capture);
  g_test_add_func ("/goodix-fpimage-device/non-enroll-finger-off-sync-deactivate",
                   test_non_enroll_finger_off_synchronous_deactivate);
  g_test_add_func ("/goodix-fpimage-device/enroll-minutiae-done-before-finger-off",
                   test_enroll_minutiae_done_before_finger_off);
  g_test_add_func ("/goodix-fpimage-device/enroll-finger-off-before-minutiae-done",
                   test_enroll_finger_off_before_minutiae_done);
  g_test_add_func ("/goodix-fpimage-device/d279-57-terminal-release-before-sigfm",
                   test_terminal_hold_release_before_sigfm_completion);
  g_test_add_func ("/goodix-fpimage-device/d279-57-terminal-release-before-sigfm-failure-fail-closed",
                   test_terminal_release_before_sigfm_failure_is_fail_closed);
  g_test_add_func ("/goodix-fpimage-device/enrollment-fixed-21-stage-policy",
                   test_enrollment_fixed_21_stage_policy);
  g_test_add_func ("/goodix-fpimage-device/no-rearm-before-both-gates",
                   test_no_rearm_before_both_gates);
  g_test_add_func ("/goodix-fpimage-device/no-command-after-deactivate-fence",
                   test_no_command_after_deactivate_fence);
  g_test_add_func ("/goodix-fpimage-device/cancellation-opening",
                   test_cancellation_opening);
  g_test_add_func ("/goodix-fpimage-device/cancellation-activating",
                   test_cancellation_activating);
  g_test_add_func ("/goodix-fpimage-device/cancellation-await-finger-on",
                   test_cancellation_await_finger_on);
  g_test_add_func ("/goodix-fpimage-device/cancellation-capture",
                   test_cancellation_capture);
  g_test_add_func ("/goodix-fpimage-device/cancellation-await-finger-off",
                   test_cancellation_await_finger_off);
  g_test_add_func ("/goodix-fpimage-device/cancellation-deactivating",
                   test_cancellation_deactivating);
  g_test_add_func ("/goodix-fpimage-device/stale-callback-generation-guard",
                   test_stale_callback_generation_guard);
  g_test_add_func ("/goodix-fpimage-device/terminal-error-path",
                   test_terminal_error_path);
  g_test_add_func ("/goodix-fpimage-device/poison-is-sticky-until-close",
                   test_poison_is_sticky_until_close);
  g_test_add_func ("/goodix-fpimage-device/d276-04-context-ownership",
                   test_d276_04_context_ownership);
  g_test_add_func ("/goodix-fpimage-device/d278-12-post-tls-context-ownership",
                   test_d278_12_post_tls_context_ownership);
  g_test_add_func ("/goodix-fpimage-device/d278-14-non-null-usb-binding",
                   test_d278_14_non_null_usb_binding);
  g_test_add_func ("/goodix-fpimage-device/d282-direct-enroll-feature-profile",
                   test_d282_direct_enroll_feature_profile);
  g_test_add_func ("/goodix-fpimage-device/d279-08-production-open-close-ownership",
                   test_d279_08_production_open_close_ownership);
  g_test_add_func ("/goodix-fpimage-device/d279-08-production-open-failures",
                   test_d279_08_production_open_failures);
  g_test_add_func ("/goodix-fpimage-device/d279-08-production-release-failure",
                   test_d279_08_production_release_failure);
  g_test_add_func ("/goodix-fpimage-device/d279-09-production-activation-binding",
                   test_d279_09_production_activation_binding);
  g_test_add_func ("/goodix-fpimage-device/d279-09-production-activation-sync-failure",
                   test_d279_09_production_activation_sync_failure);
  g_test_add_func ("/goodix-fpimage-device/d279-28-production-enrollment-graph",
                   test_d279_28_production_enrollment_starts_reviewed_graph);
  g_test_add_func ("/goodix-fpimage-device/d279-28-production-action-allowlist",
                   test_d279_28_production_non_enrollment_rejected);
  g_test_add_func ("/goodix-fpimage-device/d279-55-production-identify-single-acquisition",
                   test_d279_55_production_identify_single_acquisition);
  g_test_add_func ("/goodix-fpimage-device/d279-20-dormant-enrollment-context-ownership",
                   test_d279_20_dormant_enrollment_context_ownership);
  g_test_add_data_func ("/goodix-fpimage-device/d279-24-context-first-arm-enrollment-handoff",
                        NULL, test_d279_24_context_first_arm_enrollment_handoff);

  return g_test_run ();
}
