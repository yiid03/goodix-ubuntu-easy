#!/bin/sh
# SPDX-License-Identifier: LGPL-2.1-or-later
set -eu

if [ "$#" -lt 2 ]; then
  echo "usage: $0 <git-root> <build-dir> [test-args...]" >&2
  exit 2
fi

git_root=$1
build_dir=$2
shift 2
local_fp_dir="$git_root/reference/libfprint-fedora44-1.94.100/source/libfprint"
test_dir="$git_root/libfprint-driver/tests"
test_source="$test_dir/test_goodix_fpimage_device.c"
test_warnings=""
test_timeout=90

glib_cflags=$(pkg-config --cflags glib-2.0 gio-2.0 gobject-2.0 openssl)
glib_libs=$(pkg-config --libs glib-2.0 gio-2.0 gobject-2.0 openssl)
includes="-I$test_dir/support/post_tls -I$test_dir/support -I$git_root/libfprint-driver -I$git_root/reference/libfprint-fedora44-1.94.100/source -I$git_root/Rockytkg/libfprint/libfprint -I$local_fp_dir -I$git_root/Rockytkg/libfprint/libfprint/sigfm -I$local_fp_dir/nbis/include -I$local_fp_dir/nbis/libfprint-include -I$build_dir"
strict_flags="-std=gnu11 -O2 -g -DGOODIX_ENABLE_TEST_SEAMS -Wall -Wextra -Werror -Wformat=2 -Wshadow -Wstrict-prototypes -Wmissing-prototypes -Wconversion -ffunction-sections -fdata-sections"
local_flags="-DGOODIX_LIBFPRINT_SIGFM -std=gnu11 -O2 -g -Wall -Wextra -Werror -Wno-unused-parameter -Wno-missing-prototypes -Wno-discarded-qualifiers -Wno-sign-compare -Wno-cast-function-type -Wno-enum-conversion -Wno-maybe-uninitialized -ffunction-sections -fdata-sections"

chicago_link=""
algorithm_objects="$build_dir/r2.o $build_dir/preprocess.o $build_dir/metrics.o -lstdc++"
if [ "${GOODIX_CHICAGO_TEST:-0}" = 1 ]; then
  test_source="${GOODIX_CHICAGO_TEST_SOURCE:-$test_dir/test_goodix_chicago.c}"
  strict_flags="$strict_flags -DGOODIX_LIBFPRINT_CHICAGO"
  local_flags=$(printf '%s' "$local_flags" | sed 's/GOODIX_LIBFPRINT_SIGFM/GOODIX_LIBFPRINT_CHICAGO/g')
  includes="$includes -I$git_root/production/chicago-native/chicago"
  chicago_link="$GOODIX_CHICAGO_NATIVE_ARCHIVE"
  algorithm_objects="$build_dir/goodix_chicago.o"
fi

if [ -n "${GOODIX_CHICAGO_STORAGE_SOURCE:-}" ]; then
  strict_flags="$strict_flags -DGOODIX_CHICAGO_STORAGE_TEST"
  includes="$includes -I$GOODIX_CHICAGO_STORAGE_SOURCE/src"
  chicago_link="$build_dir/file_storage.o $chicago_link"
fi

if [ "${GOODIX_PRODUCTION_FPRINTD_ACTION_PROFILE_TEST:-0}" = 1 ]; then
  strict_flags="$strict_flags -DGOODIX_PRODUCTION_FPRINTD_ACTION_PROFILE"
fi


adoption_mentions=$(find "$git_root/libfprint-driver" \
  -path "$git_root/libfprint-driver/tests" -prune -o \
  \( -name '*.c' -o -name '*.h' \) -type f -exec \
  grep -H 'goodix_device_context_adopt_dormant_enrollment_binding' {} + | \
  wc -l)
if [ "$adoption_mentions" -ne 2 ]; then
  echo "dormant enrollment adoption acquired a production caller" >&2
  exit 1
fi
echo D279_20_NO_PRODUCTION_ADOPTION_CALLER_SOURCE_AUDIT=PASS
configuration_mentions=$(find "$git_root/libfprint-driver" \
  -path "$git_root/libfprint-driver/tests" -prune -o \
  \( -name '*.c' -o -name '*.h' \) -type f -exec \
  grep -H 'goodix_device_context_configure_enrollment_graph' {} + | \
  wc -l)
if [ "$configuration_mentions" -ne 3 ] ||
   ! grep -A80 '^production_activation_start_secure_graph' \
      "$git_root/libfprint-driver/goodix_fpimage_device.c" | \
      grep -F 'goodix_device_context_configure_enrollment_graph (' >/dev/null; then
  echo "production enrollment graph caller set is not the reviewed singleton" >&2
  exit 1
fi
echo D279_28_SINGLE_PRODUCTION_CONFIGURATION_CALLER_SOURCE_AUDIT=PASS

pairing_writer_callers=$(find "$git_root/libfprint-driver" \
  -path "$git_root/libfprint-driver/tests" -prune -o \
  \( -name '*.c' -o -name '*.h' \) -type f \
  ! -name 'goodix_pairing_provision.c' \
  ! -name 'goodix_pairing_provision.h' -exec \
  grep -l 'goodix_pairing_provision_begin_e0' {} + | wc -l)
if [ "$pairing_writer_callers" -ne 1 ] ||
   ! grep -F 'goodix_pairing_provision_begin_e0' \
      "$git_root/libfprint-driver/goodix_pairing_activation.c" >/dev/null; then
  echo "pairing E0 writer caller set differs from the reviewed singleton" >&2
  exit 1
fi
echo P6_PRODUCTION_E0_WRITER_HAS_ONE_REVIEWED_RUNTIME_CALLER=PASS

# ---- Generated enum registrations (host-only Python shim) ----
python3 "$test_dir/support/generate_libfprint_enums.py" \
  --identifier-prefix Fpi --symbol-prefix fpi \
  --header-guard FPI_ENUMS_H --header-name fpi-enums.h \
  --output-header "$build_dir/fpi-enums.h" \
  --output-source "$build_dir/fpi-enums.c" \
  "$local_fp_dir/fpi-device.h" \
  "$local_fp_dir/fpi-image-device.h" \
  "$local_fp_dir/fpi-print.h"

python3 "$test_dir/support/generate_libfprint_enums.py" \
  --identifier-prefix Fp --symbol-prefix fp \
  --header-guard FP_ENUMS_H --header-name fp-enums.h \
  --output-header "$build_dir/fp-enums.h" \
  --output-source "$build_dir/fp-enums.c" \
  "$local_fp_dir/fp-device.h" \
  "$local_fp_dir/fp-print.h"



if [ -n "${GOODIX_CHICAGO_STORAGE_SOURCE:-}" ]; then
  gcc $local_flags $glib_cflags $includes -c "$GOODIX_CHICAGO_STORAGE_SOURCE/src/file_storage.c" -o "$build_dir/file_storage.o"
fi

# ---- libfprint core subset needed for real FpImageDevice actions ----
compile_libfprint() {
  gcc $local_flags $glib_cflags $includes -c "$1" -o "$2"
}

compile_libfprint "$local_fp_dir/fp-device.c"        "$build_dir/fp-device.o"
compile_libfprint "$local_fp_dir/fpi-device.c"       "$build_dir/fpi-device.o"
compile_libfprint "$local_fp_dir/fp-image-device.c"  "$build_dir/fp-image-device.o"
compile_libfprint "$local_fp_dir/fpi-image-device.c" "$build_dir/fpi-image-device.o"
compile_libfprint "$local_fp_dir/fpi-image.c" "$build_dir/fpi-image.o"
compile_libfprint "$local_fp_dir/fp-image.c"         "$build_dir/fp-image.o"
compile_libfprint "$local_fp_dir/fp-print.c"         "$build_dir/fp-print.o"
compile_libfprint "$local_fp_dir/fpi-print.c"        "$build_dir/fpi-print.o"
compile_libfprint "$build_dir/fpi-enums.c"           "$build_dir/fpi-enums.o"
compile_libfprint "$build_dir/fp-enums.c"            "$build_dir/fp-enums.o"

# ---- Project code ----
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_u16_to_fpimage.c" \
  -o "$build_dir/goodix_u16_to_fpimage.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_fpimage_pipeline.c" \
  -o "$build_dir/goodix_fpimage_pipeline.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_usb_router.c" \
  -o "$build_dir/goodix_usb_router.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_a0_protocol.c" \
  -o "$build_dir/goodix_a0_protocol.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_action_binding.c" \
  -o "$build_dir/goodix_action_binding.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_target_material.c" \
  -o "$build_dir/goodix_target_material.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_runtime_inputs.c" \
  -o "$build_dir/goodix_runtime_inputs.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_runtime_material.c" \
  -o "$build_dir/goodix_runtime_material.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_config90.c" \
  -o "$build_dir/goodix_config90.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_self_state.c" \
  -o "$build_dir/goodix_self_state.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_runtime_coordinator.c" \
  -o "$build_dir/goodix_runtime_coordinator.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_bb010002.c" \
  -o "$build_dir/goodix_bb010002.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_live_preflight.c" \
  -o "$build_dir/goodix_live_preflight.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_pairing_crypto.c" \
  -o "$build_dir/goodix_pairing_crypto.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_pairing_provision.c" \
  -o "$build_dir/goodix_pairing_provision.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_pairing_activation.c" \
  -o "$build_dir/goodix_pairing_activation.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_secure_session.c" \
  -o "$build_dir/goodix_secure_session.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_image_decoder.c" \
  -o "$build_dir/goodix_image_decoder.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_post_tls_lifecycle.c" \
  -o "$build_dir/goodix_post_tls_lifecycle.o"
gcc $strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_fpimage_device.c" \
  -o "$build_dir/goodix_fpimage_device.o"
gcc $strict_flags $glib_cflags $includes -c "$git_root/libfprint-driver/goodix_tls_server.c" -o "$build_dir/goodix_tls_server.o"
gcc $strict_flags $glib_cflags $includes -c "$git_root/libfprint-driver/goodix_fpi_usb_backend.c" -o "$build_dir/goodix_fpi_usb_backend.o"
for source in \
  goodix_enrollment_model.c \
  goodix_enrollment_diversity.c \
  goodix_enrollment_pipeline.c \
    goodix_enrollment_command_plan.c \
    goodix_enrollment_command_body.c \
    goodix_fdt_irq_policy.c \
    goodix_enrollment_fdt_state.c \
  goodix_enrollment_lifecycle_adapter.c \
  goodix_enrollment_post_tls_events.c \
  goodix_enrollment_outbound_frame.c \
  goodix_enrollment_outbound_transaction.c \
  goodix_enrollment_fpi_usb_binding.c; do
  # shellcheck disable=SC2086
  gcc $strict_flags $glib_cflags $includes -c \
    "$git_root/libfprint-driver/$source" \
    -o "$build_dir/${source%.c}.o"
done
gcc $local_flags $glib_cflags $includes -c "$test_dir/support/fpi_usb_transfer_compile_stub.c" -o "$build_dir/fpi_usb_transfer_compile_stub.o"
gcc $strict_flags $test_warnings $glib_cflags $includes -c \
  "$test_source" \
  -o "$build_dir/test_goodix_fpimage_device.o"

# ---- Host-only test seams ----
gcc $local_flags $glib_cflags $includes -c \
  "$test_dir/support/gusb_stub.c" \
  -o "$build_dir/gusb_stub.o"
gcc $local_flags $glib_cflags $includes -c \
  "$test_dir/support/fpimage_link_stubs.c" \
  -o "$build_dir/fpimage_link_stubs.o"

# ---- Forbidden-symbol audit on the fake backend / shell ----
if nm -u "$build_dir/goodix_fpimage_device.o" | \
     grep -E "(^|[[:space:]])(libusb_|usb_|fopen|open|read|write|socket|SSL_|mbedtls_|gnutls_)"; then
  echo "forbidden I/O, USB, or TLS symbol in Goodix FpImageDevice shell" >&2
  exit 1
fi
echo "goodix_fpimage_device forbidden-symbol audit: PASS"

# ---- Link ----
if [ "${GOODIX_CHICAGO_TEST:-0}" = 1 ]; then
  gcc $strict_flags $glib_cflags $includes -c "$git_root/libfprint-driver/goodix_chicago.c" -o "$build_dir/goodix_chicago.o"
else
  gcc $local_flags $glib_cflags $includes -c "$git_root/libfprint-driver/rockytkg-imgproc/goodix_imgproc.c" -o "$build_dir/r2.o"
  gcc $strict_flags $glib_cflags $includes -c "$git_root/libfprint-driver/goodix_sigfm_preprocess.c" -o "$build_dir/preprocess.o"
  g++ -std=c++17 -O2 -g $includes -c "$git_root/libfprint-driver/goodix_sigfm_metrics.cpp" -o "$build_dir/metrics.o"
fi
gcc -Wl,--gc-sections $algorithm_objects \
  "$build_dir/fp-device.o" \
  "$build_dir/fpi-device.o" \
  "$build_dir/fp-image-device.o" \
  "$build_dir/fpi-image-device.o" \
  "$build_dir/fpi-image.o" \
  "$build_dir/fp-image.o" \
  "$build_dir/fp-print.o" \
  "$build_dir/fpi-print.o" \
  "$build_dir/fpi-enums.o" \
  "$build_dir/fp-enums.o" \
  "$build_dir/goodix_u16_to_fpimage.o" \
  "$build_dir/goodix_fpimage_pipeline.o" \
  "$build_dir/goodix_usb_router.o" \
  "$build_dir/goodix_a0_protocol.o" \
  "$build_dir/goodix_action_binding.o" \
  "$build_dir/goodix_target_material.o" \
  "$build_dir/goodix_runtime_inputs.o" \
  "$build_dir/goodix_runtime_material.o" \
  "$build_dir/goodix_config90.o" \
  "$build_dir/goodix_self_state.o" \
  "$build_dir/goodix_runtime_coordinator.o" \
  "$build_dir/goodix_bb010002.o" \
  "$build_dir/goodix_live_preflight.o" \
  "$build_dir/goodix_pairing_crypto.o" \
  "$build_dir/goodix_pairing_provision.o" \
  "$build_dir/goodix_pairing_activation.o" \
  "$build_dir/goodix_secure_session.o" \
  "$build_dir/goodix_image_decoder.o" \
  "$build_dir/goodix_post_tls_lifecycle.o" \
  "$build_dir/goodix_fpimage_device.o" \
  "$build_dir/goodix_tls_server.o" \
  "$build_dir/goodix_fpi_usb_backend.o" \
  "$build_dir/goodix_enrollment_model.o" \
  "$build_dir/goodix_enrollment_diversity.o" \
  "$build_dir/goodix_enrollment_pipeline.o" \
  "$build_dir/goodix_enrollment_command_plan.o" \
  "$build_dir/goodix_enrollment_command_body.o" \
  "$build_dir/goodix_fdt_irq_policy.o" \
  "$build_dir/goodix_enrollment_fdt_state.o" \
  "$build_dir/goodix_enrollment_lifecycle_adapter.o" \
  "$build_dir/goodix_enrollment_post_tls_events.o" \
  "$build_dir/goodix_enrollment_outbound_frame.o" \
  "$build_dir/goodix_enrollment_outbound_transaction.o" \
  "$build_dir/goodix_enrollment_fpi_usb_binding.o" \
  "$build_dir/fpi_usb_transfer_compile_stub.o" \
  "$build_dir/test_goodix_fpimage_device.o" \
  "$build_dir/gusb_stub.o" \
  "$build_dir/fpimage_link_stubs.o" \
  $chicago_link $glib_libs -lm -o "$build_dir/test_goodix_fpimage_device"

set +e
timeout --signal=TERM "$test_timeout" "$build_dir/test_goodix_fpimage_device" "$@"
normal_rc=$?
case $normal_rc in
  0) echo "Normal test run: PASS" ;;
  124) echo "Normal test run: TIMEOUT" >&2 ;;
  134) echo "Normal test run: ABORT/assertion failure" >&2 ;;
  *) echo "Normal test run: FAIL/crash (exit $normal_rc)" >&2 ;;
esac
set -e

if [ "${GOODIX_CHICAGO_TEST:-0}" = 1 ]; then
  echo "Chicago host fixture uses the pinned unsanitized native archive; no sanitizer PASS claimed"
  exit "$normal_rc"
fi

echo "Running address/undefined-behavior sanitized build..."
san_common="-O1 -fno-omit-frame-pointer -fsanitize=address,undefined"
san_strict_flags="$strict_flags $san_common"
san_local_flags="$local_flags $san_common"

compile_libfprint_san() {
  gcc $san_local_flags $glib_cflags $includes -c "$1" -o "$2"
}

compile_libfprint_san "$local_fp_dir/fp-device.c"        "$build_dir/fp-device_san.o"
compile_libfprint_san "$local_fp_dir/fpi-device.c"       "$build_dir/fpi-device_san.o"
compile_libfprint_san "$local_fp_dir/fp-image-device.c"  "$build_dir/fp-image-device_san.o"
compile_libfprint_san "$local_fp_dir/fpi-image-device.c" "$build_dir/fpi-image-device_san.o"
compile_libfprint_san "$local_fp_dir/fpi-image.c" "$build_dir/fpi-image_san.o"
compile_libfprint_san "$local_fp_dir/fp-image.c"         "$build_dir/fp-image_san.o"
compile_libfprint_san "$local_fp_dir/fp-print.c"         "$build_dir/fp-print_san.o"
compile_libfprint_san "$local_fp_dir/fpi-print.c"        "$build_dir/fpi-print_san.o"
compile_libfprint_san "$build_dir/fpi-enums.c"           "$build_dir/fpi-enums_san.o"
compile_libfprint_san "$build_dir/fp-enums.c"            "$build_dir/fp-enums_san.o"

gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_u16_to_fpimage.c" \
  -o "$build_dir/goodix_u16_to_fpimage_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_fpimage_pipeline.c" \
  -o "$build_dir/goodix_fpimage_pipeline_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_usb_router.c" \
  -o "$build_dir/goodix_usb_router_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_a0_protocol.c" \
  -o "$build_dir/goodix_a0_protocol_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_action_binding.c" \
  -o "$build_dir/goodix_action_binding_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_target_material.c" \
  -o "$build_dir/goodix_target_material_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_runtime_inputs.c" \
  -o "$build_dir/goodix_runtime_inputs_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_runtime_material.c" \
  -o "$build_dir/goodix_runtime_material_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_config90.c" \
  -o "$build_dir/goodix_config90_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_self_state.c" \
  -o "$build_dir/goodix_self_state_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_runtime_coordinator.c" \
  -o "$build_dir/goodix_runtime_coordinator_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_bb010002.c" \
  -o "$build_dir/goodix_bb010002_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_live_preflight.c" \
  -o "$build_dir/goodix_live_preflight_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_pairing_crypto.c" \
  -o "$build_dir/goodix_pairing_crypto_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_pairing_provision.c" \
  -o "$build_dir/goodix_pairing_provision_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_pairing_activation.c" \
  -o "$build_dir/goodix_pairing_activation_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_secure_session.c" \
  -o "$build_dir/goodix_secure_session_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_image_decoder.c" \
  -o "$build_dir/goodix_image_decoder_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_post_tls_lifecycle.c" \
  -o "$build_dir/goodix_post_tls_lifecycle_san.o"
gcc $san_strict_flags $glib_cflags $includes -c \
  "$git_root/libfprint-driver/goodix_fpimage_device.c" \
  -o "$build_dir/goodix_fpimage_device_san.o"
gcc $san_strict_flags $glib_cflags $includes -c "$git_root/libfprint-driver/goodix_tls_server.c" -o "$build_dir/goodix_tls_server_san.o"
gcc $san_strict_flags $glib_cflags $includes -c "$git_root/libfprint-driver/goodix_fpi_usb_backend.c" -o "$build_dir/goodix_fpi_usb_backend_san.o"
for source in \
  goodix_enrollment_model.c \
  goodix_enrollment_diversity.c \
  goodix_enrollment_pipeline.c \
    goodix_enrollment_command_plan.c \
    goodix_enrollment_command_body.c \
    goodix_fdt_irq_policy.c \
    goodix_enrollment_fdt_state.c \
  goodix_enrollment_lifecycle_adapter.c \
  goodix_enrollment_post_tls_events.c \
  goodix_enrollment_outbound_frame.c \
  goodix_enrollment_outbound_transaction.c \
  goodix_enrollment_fpi_usb_binding.c; do
  # shellcheck disable=SC2086
  gcc $san_strict_flags $glib_cflags $includes -c \
    "$git_root/libfprint-driver/$source" \
    -o "$build_dir/${source%.c}_san.o"
done
gcc $san_local_flags $glib_cflags $includes -c "$test_dir/support/fpi_usb_transfer_compile_stub.c" -o "$build_dir/fpi_usb_transfer_compile_stub_san.o"
gcc $san_strict_flags $test_warnings $glib_cflags $includes -c \
  "$test_source" \
  -o "$build_dir/test_goodix_fpimage_device_san.o"
gcc $san_local_flags $glib_cflags $includes -c \
  "$test_dir/support/gusb_stub.c" \
  -o "$build_dir/gusb_stub_san.o"
gcc $san_local_flags $glib_cflags $includes -c \
  "$test_dir/support/fpimage_link_stubs.c" \
  -o "$build_dir/fpimage_link_stubs_san.o"

gcc $san_local_flags $glib_cflags $includes -c "$git_root/libfprint-driver/rockytkg-imgproc/goodix_imgproc.c" -o "$build_dir/r2_san.o"
gcc $san_strict_flags $glib_cflags $includes -c "$git_root/libfprint-driver/goodix_sigfm_preprocess.c" -o "$build_dir/preprocess_san.o"
g++ -std=c++17 $san_common $includes -c "$git_root/libfprint-driver/goodix_sigfm_metrics.cpp" -o "$build_dir/metrics_san.o"
gcc $san_common -Wl,--gc-sections "$build_dir/metrics_san.o" -lstdc++ \
  "$build_dir/fp-device_san.o" \
  "$build_dir/fpi-device_san.o" \
  "$build_dir/fp-image-device_san.o" \
  "$build_dir/fpi-image-device_san.o" \
  "$build_dir/fpi-image_san.o" "$build_dir/r2_san.o" "$build_dir/preprocess_san.o" \
  "$build_dir/fp-image_san.o" \
  "$build_dir/fp-print_san.o" \
  "$build_dir/fpi-print_san.o" \
  "$build_dir/fpi-enums_san.o" \
  "$build_dir/fp-enums_san.o" \
  "$build_dir/goodix_u16_to_fpimage_san.o" \
  "$build_dir/goodix_fpimage_pipeline_san.o" \
  "$build_dir/goodix_usb_router_san.o" \
  "$build_dir/goodix_a0_protocol_san.o" \
  "$build_dir/goodix_action_binding_san.o" \
  "$build_dir/goodix_target_material_san.o" \
  "$build_dir/goodix_runtime_inputs_san.o" \
  "$build_dir/goodix_runtime_material_san.o" \
  "$build_dir/goodix_config90_san.o" \
  "$build_dir/goodix_self_state_san.o" \
  "$build_dir/goodix_runtime_coordinator_san.o" \
  "$build_dir/goodix_bb010002_san.o" \
  "$build_dir/goodix_live_preflight_san.o" \
  "$build_dir/goodix_pairing_crypto_san.o" \
  "$build_dir/goodix_pairing_provision_san.o" \
  "$build_dir/goodix_pairing_activation_san.o" \
  "$build_dir/goodix_secure_session_san.o" \
  "$build_dir/goodix_image_decoder_san.o" \
  "$build_dir/goodix_post_tls_lifecycle_san.o" \
  "$build_dir/goodix_fpimage_device_san.o" \
  "$build_dir/goodix_tls_server_san.o" \
  "$build_dir/goodix_fpi_usb_backend_san.o" \
  "$build_dir/goodix_enrollment_model_san.o" \
  "$build_dir/goodix_enrollment_diversity_san.o" \
  "$build_dir/goodix_enrollment_pipeline_san.o" \
  "$build_dir/goodix_enrollment_command_plan_san.o" \
  "$build_dir/goodix_enrollment_command_body_san.o" \
  "$build_dir/goodix_fdt_irq_policy_san.o" \
  "$build_dir/goodix_enrollment_fdt_state_san.o" \
  "$build_dir/goodix_enrollment_lifecycle_adapter_san.o" \
  "$build_dir/goodix_enrollment_post_tls_events_san.o" \
  "$build_dir/goodix_enrollment_outbound_frame_san.o" \
  "$build_dir/goodix_enrollment_outbound_transaction_san.o" \
  "$build_dir/goodix_enrollment_fpi_usb_binding_san.o" \
  "$build_dir/fpi_usb_transfer_compile_stub_san.o" \
  "$build_dir/test_goodix_fpimage_device_san.o" \
  "$build_dir/gusb_stub_san.o" \
  "$build_dir/fpimage_link_stubs_san.o" \
  $glib_libs -lm -o "$build_dir/test_goodix_fpimage_device_sanitized"

set +e
ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1 \
  timeout --signal=TERM "$test_timeout" "$build_dir/test_goodix_fpimage_device_sanitized" "$@"
san_rc=$?
case $san_rc in
  0) echo "Sanitizer test run: PASS" ;;
  124) echo "Sanitizer test run: TIMEOUT" >&2 ;;
  134) echo "Sanitizer test run: ABORT/assertion failure" >&2 ;;
  *) echo "Sanitizer test run: FAIL/crash/sanitizer finding (exit $san_rc)" >&2 ;;
esac
set -e

if [ "$normal_rc" -ne 0 ] || [ "$san_rc" -ne 0 ]; then
  exit 1
fi
echo D279_20_DORMANT_CONTEXT_OWNERSHIP_AND_DRAIN=PASS
echo D279_24_CONTEXT_FIRST_ARM_ENROLLMENT_HANDOFF=PASS
echo ENROLLMENT_FIXED_21_CONTEXT_TRANSCRIPT=PASS
echo D279_28_PRODUCTION_ENROLLMENT_GRAPH_BOUND=PASS
echo D279_28_PRODUCTION_OPEN_EPOCH_ACTION_MAX=1
echo D279_20_REAL_USB_SUBMIT=0
