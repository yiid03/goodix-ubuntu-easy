/* SPDX-License-Identifier: LGPL-2.1-or-later */
/*
 * FpImageDevice glue for the Goodix 27c6:5125 boundary.
 *
 * This file implements the first production-shaped slice of the libfprint
 * device glue with an in-memory fake backend and the production USB router,
 * TLS server, USB backend, secure-session and one-shot enrollment integration.
 * It contains no fprintd or persistent-write path.
 *
 * Architecture: see TECHNICAL_MANUAL.md.
 * API source: the repository-local Fedora libfprint 1.94.100 tree (LGPL).
 */
#include "goodix_fpimage_device.h"

#include "goodix_fpimage_pipeline.h"
#include "goodix_u16_to_fpimage.h"
#include "goodix_usb_router.h"
#include "goodix_tls_server.h"
#include "goodix_fpi_usb_backend.h"
#include "goodix_secure_session.h"
#include "goodix_post_tls_lifecycle.h"
#include "goodix_runtime_coordinator.h"
#include "goodix_live_preflight.h"
#include "goodix_pairing_activation.h"
#include "goodix_enrollment_fpi_usb_binding.h"
#include "goodix_enrollment_diversity.h"
#include "goodix_sigfm_metrics.h"
#ifdef GOODIX_LIBFPRINT_CHICAGO
#include "goodix_chicago.h"
#endif

#include "fpi-device.h"
#include "fpi-image-device.h"
#include "fp-device.h"
#include "fp-image-device-private.h"
#include <gusb.h>
#include <openssl/crypto.h>

#include <string.h>

struct _GoodixInMemoryBackend
{
  guint   arm_count;
  guint   disarm_count;
  guint   rearm_count;
  guint   total_command_count;
  gchar  *last_command;
};

struct _GoodixDeviceContext
{
  GoodixFpImageDevice     *device;
  GoodixDeviceContextState state;

  guint64                  generation_seq;
  guint64                  generation;

  gboolean                 terminal_fence;
  gboolean                 poisoned;
  GCancellable            *activation_cancellable;
  GCancellable            *usb_cancellable;
  gulong                   cancel_handler_id;
  gboolean                 activation_completed;

  gboolean                 release_tail_complete;
  gboolean                 fresh_down_table;
  guint64                  rearm_issued_generation;
  gboolean                 deactivation_held;
  gboolean                 deactivation_pending;
  gboolean                 deactivation_nonquiescent;
  gboolean                 deactivation_completion_scheduled;

  const GoodixBackendVTable *backend_vtable;
  gpointer                   backend_user_data;
  GoodixInMemoryBackend      backend;
  GoodixUsbRouter           *usb_router;
  GoodixTlsServer           *tls_server;
  GoodixFpiUsbBackend       *fpi_usb_backend;
  GoodixSecureSession       *secure_session;
  GoodixPostTlsLifecycle    *post_tls_lifecycle;
  GoodixEnrollmentFpiUsbBinding *enrollment_binding;
  GoodixEnrollmentDiversity *enrollment_diversity;
  GoodixEnrollmentPostTlsEvents *pending_enrollment_events;
  GoodixEnrollmentAuxiliaryB0Func enrollment_auxiliary;
  gpointer                   enrollment_auxiliary_data;
  GoodixEnrollmentFpiUsbBindingAudit *enrollment_binding_audit;
  GoodixTlsPlaintextFunc     tls_plaintext;
  gpointer                   tls_user_data;
  guint                      a0_delivery_count;
  gboolean                   login_preparing;
  gboolean                   login_series;
  gboolean                   login_reusable;
  guint                      login_attempts;
  gboolean                   login_ready;
  gboolean                   login_close_pending;
  guint                      login_deadline;
  gboolean                   operator_epoch;
  GoodixPreSessionRxSyncAudit pre_session_rx_sync_audit;
  gint64                      pre_session_rx_sync_started_us;
  guint64                     pre_session_rx_sync_out_count_at_pass;
  GoodixPreSessionRxSyncClockFunc pre_session_rx_sync_clock;
  gpointer                    pre_session_rx_sync_clock_data;
  GoodixDeviceContextSecurePhaseObserver phase_observer;
  gpointer                   phase_observer_data;

  GoodixRuntimeCoordinator  *runtime_material;
  GoodixLivePreflight       *live_preflight;
  GoodixPairingActivation   *pairing_activation;
  GoodixSecureSessionMaterial runtime_secure_view;
  guint8                     runtime_fdt_seed[GOODIX_RUNTIME_FDT_SEED_LENGTH];
  GoodixRuntimeCoordinatorAudit runtime_coordinator_audit;
  GoodixLivePreflightAudit    live_preflight_audit;
  GoodixPairingActivationAudit pairing_activation_audit;
  GoodixRuntimeMaterialAudit runtime_material_audit;
  GoodixSecureSessionAudit    runtime_secure_audit;
  GoodixTlsAudit              runtime_tls_audit;
  GoodixPostTlsAudit          runtime_post_tls_audit;
  GoodixEnrollmentPostTlsEventsAudit runtime_enrollment_events_audit;
  GoodixEnrollmentFpiUsbBindingAudit runtime_enrollment_binding_audit;
  guint                      runtime_enrollment_auxiliary_count;
  guint                      terminal_enroll_completion_hold_count;
  guint                      terminal_enroll_completion_release_count;
  guint                      terminal_enroll_completion_abort_count;
  gboolean                   terminal_enroll_completion_held;
  gboolean                   terminal_delivery_at_release_ready;
  gboolean                   handling_enrollment_a0;
  gboolean                   production_action_consumed;
  FpiDeviceAction            production_action;
  guint                      production_action_attempt_count;
  guint                      production_rejected_action_count;
  guint                      production_explicit_verify_reopen_count;
  guint                      production_explicit_identify_reopen_count;
  gboolean                   production_verify_epoch_closed;
  gboolean                   production_verify_result_known;
  gboolean                   production_verify_result_success;
  gboolean                   production_verify_result_match;
  gboolean                   production_identify_epoch_closed;
  gboolean                   production_identify_result_known;
  gboolean                   production_identify_result_success;
  gboolean                   production_identify_result_match;
  gboolean                   production_identify_enroll_handoff_armed;
  guint                      production_identify_enroll_handoff_count;
  guint                      production_logical_action_attempt_count;
  guint                      production_transport_epoch_count;
  /* Telemetry only; Fedora consumers choose the number of explicit attempts. */
  guint                      production_capture_attempt_count;
  gboolean                   production_capture_terminal;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  GoodixRuntimeCoordinatorReleaseSeam runtime_material_release;
  gpointer                   runtime_material_release_data;
  gboolean                   bypass_live_preflight_for_material_seam;
#endif
  gboolean                   runtime_handoff_views_cleared;
  gboolean                   usb_interface_claimed;
#ifdef GOODIX_LIBFPRINT_SIGFM
  /* The no-finger normalization baseline belongs to the logical libfprint
   * open, not to one explicit VERIFY epoch.  D291 may recreate the transport
   * graph for a later VerifyStart, but every probe in that bounded series must
   * remain in the same R2/SIGFM image space. */
  uint16_t                   sigfm_baseline[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
  gboolean                   sigfm_baseline_valid;
  gboolean                   sigfm_baseline_pinned_this_epoch;
  gboolean                   sigfm_baseline_reused_this_epoch;
#endif

#ifdef GOODIX_LIBFPRINT_CHICAGO
  GoodixChicago *chicago;
#endif
  FpiImageDeviceState        last_framework_state;

  GError                  *terminal_error;
};

typedef struct
{
  GoodixDeviceContext *ctx;
  GoodixProductionEnrollmentAudit last_production_audit;
  gboolean last_production_audit_valid;
  gboolean last_production_audit_logged;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  GoodixRuntimeCoordinatorAcquireSeam acquire_material;
  GoodixRuntimeCoordinatorReleaseSeam release_material;
  GoodixUsbInterfaceSeam claim_interface;
  GoodixUsbInterfaceSeam release_interface;
  gpointer production_seam_data;
#endif
} GoodixFpImageDevicePrivate;

typedef struct _GoodixUsbFpImageDevice
{
  GoodixFpImageDevice parent_instance;
} GoodixUsbFpImageDevice;

typedef struct _GoodixUsbFpImageDeviceClass
{
  GoodixFpImageDeviceClass parent_class;
} GoodixUsbFpImageDeviceClass;

#define GOODIX_TYPE_USB_FPIMAGE_DEVICE (goodix_usb_fpimage_device_get_type ())
GType goodix_usb_fpimage_device_get_type (void) G_GNUC_CONST;

G_DEFINE_TYPE_WITH_PRIVATE (GoodixFpImageDevice, goodix_fpimage_device,
                            FP_TYPE_IMAGE_DEVICE)
G_DEFINE_TYPE (GoodixUsbFpImageDevice, goodix_usb_fpimage_device,
               GOODIX_TYPE_FPIMAGE_DEVICE)


static const FpIdEntry goodix_usb_id_table[] = {
  { .vid = 0x27c6, .pid = 0x5125 },
  { .vid = 0, .pid = 0, .driver_data = 0 },
};

static GoodixDeviceContext *
goodix_fpimage_device_peek_context (GoodixFpImageDevice *self)
{
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);

  return priv->ctx;
}

static void
goodix_fpimage_device_set_context (GoodixFpImageDevice *self,
                                   GoodixDeviceContext *ctx)
{
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);

  priv->ctx = ctx;
}

static void goodix_device_context_set_terminal_fence (GoodixDeviceContext *ctx);
static void goodix_device_context_maybe_rearm (GoodixDeviceContext *ctx);
static void goodix_device_context_set_poisoned (GoodixDeviceContext *ctx,
                                                const GError        *error);
static void emit_terminal (GoodixDeviceContext *ctx, GError *error);
static void goodix_device_context_set_state (GoodixDeviceContext *ctx, GoodixDeviceContextState state);
static void login_ready (GoodixPostTlsLifecycle *lifecycle, gpointer data);
static gboolean login_close_idle (gpointer data);
static gboolean login_deadline (gpointer data);
static void login_maybe_report_release (GoodixDeviceContext *ctx);

static gboolean
goodix_fpimage_device_is_production_usb (GoodixFpImageDevice *self);
static void default_release_runtime_material (GoodixRuntimeCoordinator *owner,
                                              gpointer user_data);
static gboolean goodix_fpimage_device_release_claim (
  GoodixFpImageDevice *self,
  GError             **error);
static void goodix_device_context_release_epoch_objects (
  GoodixDeviceContext *ctx);
static void production_live_preflight_progress (GoodixDeviceContext *ctx);
static void production_pairing_activation_progress (GoodixDeviceContext *ctx);
static void production_activation_start_live_preflight (
  GoodixDeviceContext *ctx);
static gboolean default_acquire_runtime_material_with_live (
  const GoodixRuntimeCoordinatorLiveEvidence *live,
  GoodixRuntimeCoordinator                  **owner,
  GoodixSecureSessionMaterial                *secure_view,
  guint8                                      fdt_seed[GOODIX_RUNTIME_FDT_SEED_LENGTH],
  GoodixRuntimeCoordinatorAudit              *coordinator_audit,
  GoodixRuntimeMaterialAudit                 *audit,
  GError                                    **error);

static gboolean
production_action_requires_live_preflight (FpiDeviceAction action)
{
  /* State-v2 is target-bound by evidence that can only be reconstructed by
   * the read-only preflight.  Every biometric capture action therefore needs
   * that evidence before selecting legacy or state-v2 material.  Stock
   * fprintd starts enrollment with an IDENTIFY duplicate check. */
  return action == FPI_DEVICE_ACTION_ENROLL ||
         action == FPI_DEVICE_ACTION_IDENTIFY ||
#ifdef GOODIX_LIBFPRINT_CHICAGO
         action == FPI_DEVICE_ACTION_CAPTURE ||
#endif
         action == FPI_DEVICE_ACTION_VERIFY;
}

static gboolean
production_action_may_start_without_material (
  FpiDeviceAction                  action,
  GoodixRuntimeCoordinatorDecision decision)
{
  return production_action_requires_live_preflight (action) &&
         (decision ==
            GOODIX_RUNTIME_COORDINATOR_DECISION_NEEDS_LIVE_PREFLIGHT ||
          decision ==
            GOODIX_RUNTIME_COORDINATOR_DECISION_NEEDS_INITIALIZATION);
}

static void
context_protocol_failure (GoodixDeviceContext *ctx,
                          const GError        *error)
{
  g_autoptr(GError) local_error = NULL;
#ifdef GOODIX_LIBFPRINT_CHICAGO
  goodix_chicago_clear_binding (ctx->chicago);
#endif

  if (ctx->terminal_fence)
    {
      goodix_device_context_set_poisoned (ctx, error);
      return;
    }
  local_error = error != NULL ? g_error_copy (error) :
    g_error_new_literal (FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
                         "Goodix production protocol failed closed");
  goodix_device_context_set_terminal_fence (ctx);
  goodix_device_context_set_poisoned (ctx, local_error);
  if (ctx->login_preparing || ctx->login_reusable)
    {
      ctx->login_ready = FALSE;
      g_clear_handle_id (&ctx->login_deadline, g_source_remove);
      goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_POISONED);
      g_signal_emit_by_name (ctx->device, "goodix-login-prepared", FALSE,
                             local_error->message);
      return;
    }
  if (!ctx->operator_epoch &&
      (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING ||
       ctx->state == GOODIX_DEVICE_CONTEXT_STATE_ACTIVE))
    emit_terminal (ctx, g_steal_pointer (&local_error));
}

static gint64
pre_session_rx_sync_now (GoodixDeviceContext *ctx)
{
  if (ctx->pre_session_rx_sync_clock != NULL)
    return ctx->pre_session_rx_sync_clock (
      ctx->pre_session_rx_sync_clock_data);
  return g_get_monotonic_time ();
}

static void
pre_session_rx_sync_update_elapsed (GoodixDeviceContext *ctx)
{
  gint64 elapsed = pre_session_rx_sync_now (ctx) -
                   ctx->pre_session_rx_sync_started_us;

  if (elapsed < 0)
    elapsed = 0;
  ctx->pre_session_rx_sync_audit.pre_session_rx_elapsed_ms =
    (guint64) elapsed / 1000u;
}

static void
pre_session_rx_sync_fail (GoodixDeviceContext *ctx,
                          const GError        *error)
{
  g_autoptr(GError) end_error = NULL;

  pre_session_rx_sync_update_elapsed (ctx);
  ctx->pre_session_rx_sync_audit.pre_session_rx_sync_completed = TRUE;
  ctx->pre_session_rx_sync_audit.pre_session_rx_result =
    GOODIX_PRE_SESSION_RX_SYNC_FAIL_CLOSED;
  if (goodix_fpi_usb_backend_pre_session_sync_is_active (
        ctx->fpi_usb_backend) &&
      goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
    (void) goodix_fpi_usb_backend_end_pre_session_sync (
      ctx->fpi_usb_backend, ctx->generation, &end_error);
  context_protocol_failure (ctx, error != NULL ? error : end_error);
}
static void
context_usb_drained (GoodixFpiUsbBackend *backend,
                     gpointer             user_data)
{
  GoodixDeviceContext *ctx = user_data;
  (void) backend;
  if (ctx->login_close_pending)
    {
      ctx->login_close_pending = FALSE;
      g_idle_add_full (G_PRIORITY_DEFAULT, login_close_idle,
                       g_object_ref (ctx->device), g_object_unref);
      return;
    }
  if (ctx->deactivation_pending && !ctx->deactivation_held)
    goodix_device_context_complete_deactivation (ctx);
}

/* Production real-USB IN completions call goodix_fpi_usb_backend_complete_receive()
 * only; this callback ensures the same receive re-arm logic that the synthetic
 * test seam used is also reached on the real backend path. */
static void
context_usb_in_completed (GoodixFpiUsbBackend *backend,
                          guint64              submit_generation,
                          const GError        *error,
                          gpointer             user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) backend;
  (void) submit_generation;
  (void) error;

  if (ctx->terminal_fence)
    return;

  if (((ctx->post_tls_lifecycle != NULL &&
        goodix_post_tls_lifecycle_needs_receive (ctx->post_tls_lifecycle)) ||
       (ctx->secure_session != NULL &&
        goodix_secure_session_needs_receive (ctx->secure_session)) ||
       (ctx->live_preflight != NULL &&
        goodix_live_preflight_needs_receive (ctx->live_preflight)) ||
       (ctx->pairing_activation != NULL &&
        goodix_pairing_activation_needs_receive (ctx->pairing_activation)) ||
       (ctx->enrollment_binding != NULL &&
        goodix_enrollment_fpi_usb_binding_needs_receive (
          ctx->enrollment_binding))) &&
      goodix_fpi_usb_backend_get_outstanding (ctx->fpi_usb_backend) == 0)
    {
      g_autoptr(GError) arm_error = NULL;
      if (!goodix_device_context_arm_receive (ctx, &arm_error))
        context_protocol_failure (ctx, arm_error);
    }
}

static guint16
production_timestamp (void)
{
  return (guint16) ((guint64) (g_get_monotonic_time () / 1000) & 0xffffu);
}

static gboolean
production_enrollment_auxiliary (GBytes   *plaintext,
                                 gpointer  user_data,
                                 GError  **error)
{
  GoodixDeviceContext *ctx = user_data;

  if (ctx == NULL || ctx->terminal_fence || plaintext == NULL)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "production auxiliary enrollment B0 is fenced");
      return FALSE;
    }

  /* This target-observed message advances the graph, but its biometric and
   * application semantics remain unknown.  Keep it opaque in production. */
  ctx->runtime_enrollment_auxiliary_count++;
  return TRUE;
}

static void
production_activation_start_secure_graph (GoodixDeviceContext *ctx)
{
  GoodixPostTlsMaterial post_material = { .next_timestamp = production_timestamp };
  GoodixEnrollmentModelConfig enrollment_config = {
    .required_stage_count = GOODIX_BIOMETRIC_ENROLL_STAGES,
#if defined(GOODIX_LIBFPRINT_SIGFM) || defined(GOODIX_LIBFPRINT_CHICAGO)
    /* Biometric accepted-stage policy: the accepted-sample count alone completes enrollment,
     * so the structural physical-contact counter must never bound retries. */
    .max_physical_stage_count =
      GOODIX_SIGFM_ENROLL_PHYSICAL_CONTACTS_UNBOUNDED,
#endif
    .defer_terminal_stage_delivery_until_release_ready = TRUE,
    .defer_intermediate_stage_delivery_until_release_ready = TRUE,
  };
  g_autoptr(GError) error = NULL;
  FpiDeviceAction action;
  gboolean enrollment_action;

  if (ctx->state != GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING ||
      ctx->terminal_fence || ctx->operator_epoch ||
      (ctx->runtime_material == NULL && ctx->pairing_activation == NULL) ||
      !ctx->usb_interface_claimed)
    return;

  action = fpi_device_get_current_action (FP_DEVICE (ctx->device));
  enrollment_action = action == FPI_DEVICE_ACTION_ENROLL;

#ifdef GOODIX_LIBFPRINT_SIGFM
  if (enrollment_action)
    {
      goodix_enrollment_diversity_free (ctx->enrollment_diversity);
      ctx->enrollment_diversity = goodix_enrollment_diversity_new (
        GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);
      if (ctx->enrollment_diversity == NULL)
        {
          context_protocol_failure (
            ctx, g_error_new_literal (G_IO_ERROR, G_IO_ERROR_NO_SPACE,
                                      "SIGFM enrollment diversity allocation failed"));
          return;
        }
    }
#endif

  memcpy (post_material.initial_fdt_table, ctx->runtime_fdt_seed,
          sizeof post_material.initial_fdt_table);
  post_material.fdt_seed_mode =
    ctx->runtime_coordinator_audit.zero_fdt_seed ?
      GOODIX_POST_TLS_FDT_SEED_ABSENT_ZERO :
      GOODIX_POST_TLS_FDT_SEED_PROVIDED;
  post_material.af_timestamp = production_timestamp ();
  post_material.first_arm_timestamp = production_timestamp ();
  post_material.second_arm_timestamp = production_timestamp ();
  post_material.capture_profile =
    (ctx->login_preparing || action == FPI_DEVICE_ACTION_IDENTIFY ||
     action == FPI_DEVICE_ACTION_VERIFY) ?
      GOODIX_POST_TLS_CAPTURE_PROFILE_SINGLE_ACQUISITION :
      GOODIX_POST_TLS_CAPTURE_PROFILE_TWO_ACQUISITION;
  if (!goodix_device_context_configure_post_tls_lifecycle (
        ctx, &post_material, &ctx->runtime_post_tls_audit, &error) ||
      (enrollment_action &&
       !goodix_device_context_configure_enrollment_graph (
         ctx, &enrollment_config, production_enrollment_auxiliary, ctx,
         &ctx->runtime_enrollment_events_audit,
         &ctx->runtime_enrollment_binding_audit, &error)) ||
      !goodix_device_context_start_secure_session (
        ctx, &ctx->runtime_secure_view, NULL, NULL,
        &ctx->runtime_secure_audit, &ctx->runtime_tls_audit, &error))
    {
      OPENSSL_cleanse (&ctx->runtime_secure_view,
                       sizeof ctx->runtime_secure_view);
      OPENSSL_cleanse (ctx->runtime_fdt_seed,
                       sizeof ctx->runtime_fdt_seed);
      ctx->runtime_handoff_views_cleared = TRUE;
      context_protocol_failure (ctx, error);
      return;
    }

  /* Both consumers now own the data they need.  The runtime-material owner
   * remains alive until img_close, but no borrowed secret/FDT view is kept in
   * the glue after the handoff. */
  OPENSSL_cleanse (&ctx->runtime_secure_view,
                   sizeof ctx->runtime_secure_view);
  OPENSSL_cleanse (ctx->runtime_fdt_seed, sizeof ctx->runtime_fdt_seed);
  ctx->runtime_handoff_views_cleared = TRUE;
  if (!ctx->login_preparing)
    goodix_device_context_emit_arm_complete (ctx, NULL);
}

static gboolean
production_digest_matches (const guint8 *data,
                           gsize         length,
                           const guint8  expected[32])
{
  g_autoptr(GChecksum) checksum = g_checksum_new (G_CHECKSUM_SHA256);
  guint8 actual[32];
  gsize actual_length = sizeof actual;

  g_checksum_update (checksum, data, (gssize) length);
  g_checksum_get_digest (checksum, actual, &actual_length);
  return actual_length == sizeof actual &&
         CRYPTO_memcmp (actual, expected, sizeof actual) == 0;
}

static gboolean
production_live_preflight_validate_legacy_target (
  GoodixDeviceContext              *ctx,
  const GoodixLivePreflightEvidence *evidence,
  GError                          **error)
{
  if (ctx->runtime_material == NULL ||
      goodix_runtime_coordinator_get_source (ctx->runtime_material) !=
        GOODIX_RUNTIME_COORDINATOR_SOURCE_LEGACY)
    {
      g_set_error_literal (
        error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
        "read-only live preflight has no qualified legacy owner");
      return FALSE;
    }
  if (ctx->runtime_secure_view.config90 == NULL ||
      ctx->runtime_secure_view.config90_length != sizeof evidence->config90 ||
      CRYPTO_memcmp (ctx->runtime_secure_view.config90, evidence->config90,
                     sizeof evidence->config90) != 0)
    {
      g_set_error_literal (
        error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
        "generated CONFIG90 differs from the qualified legacy boundary");
      return FALSE;
    }
  if (!production_digest_matches (
        evidence->a2_response, sizeof evidence->a2_response,
        ctx->runtime_secure_view.a2_response_sha256) ||
      !production_digest_matches (
        evidence->chip_response, sizeof evidence->chip_response,
        ctx->runtime_secure_view.chip82_response_sha256) ||
      !production_digest_matches (
        evidence->otp, sizeof evidence->otp,
        ctx->runtime_secure_view.otp_a6_response_sha256))
    {
      g_set_error_literal (
        error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
        "read-only target evidence differs from the qualified legacy boundary");
      return FALSE;
    }
  return TRUE;
}

static gboolean
production_live_preflight_legacy_validator_matches (
  GoodixDeviceContext               *ctx,
  const GoodixLivePreflightEvidence *evidence)
{
  return ctx->runtime_secure_view.e4_validator != NULL &&
         ctx->runtime_secure_view.e4_validator_length ==
           sizeof evidence->validator &&
         CRYPTO_memcmp (ctx->runtime_secure_view.e4_validator,
                        evidence->validator,
                        sizeof evidence->validator) == 0;
}

static gboolean
production_live_preflight_acquire_state (
  GoodixDeviceContext               *ctx,
  const GoodixLivePreflightEvidence *evidence,
  GError                           **error)
{
  GoodixRuntimeCoordinatorLiveEvidence live = {
    .vid = 0x27c6u,
    .pid = 0x5125u,
    .chip_id = evidence->chip_id,
    .app = evidence->app,
    .a2_response = evidence->a2_response,
    .a2_response_length = sizeof evidence->a2_response,
    .chip_response = evidence->chip_response,
    .chip_response_length = sizeof evidence->chip_response,
    .otp = evidence->otp,
    .otp_length = sizeof evidence->otp,
    .live_validator = evidence->validator,
    .live_validator_length = sizeof evidence->validator,
    .bb010002 = evidence->bb010002,
    .bb010002_length = sizeof evidence->bb010002,
    .tls_proven = FALSE,
  };

  gboolean ready = default_acquire_runtime_material_with_live (
    &live, &ctx->runtime_material, &ctx->runtime_secure_view,
    ctx->runtime_fdt_seed, &ctx->runtime_coordinator_audit,
    &ctx->runtime_material_audit, error);
  return ready;
}

static void
production_release_runtime_material (GoodixDeviceContext *ctx)
{
  if (ctx->runtime_material == NULL)
    return;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  g_assert (ctx->runtime_material_release != NULL);
  ctx->runtime_material_release (ctx->runtime_material,
                                 ctx->runtime_material_release_data);
#else
  default_release_runtime_material (ctx->runtime_material, NULL);
#endif
  ctx->runtime_material = NULL;
  OPENSSL_cleanse (&ctx->runtime_secure_view,
                   sizeof ctx->runtime_secure_view);
  OPENSSL_cleanse (ctx->runtime_fdt_seed, sizeof ctx->runtime_fdt_seed);
}

static void
production_pairing_activation_ready_tls (GoodixDeviceContext *ctx)
{
  g_autoptr(GError) error = NULL;

  goodix_fpi_usb_backend_set_out_completed_callback (ctx->fpi_usb_backend,
                                                      NULL, NULL);
  if (!goodix_pairing_activation_get_secure_view (
        ctx->pairing_activation, &ctx->runtime_secure_view, &error))
    {
      context_protocol_failure (ctx, error);
      return;
    }
  OPENSSL_cleanse (ctx->runtime_fdt_seed, sizeof ctx->runtime_fdt_seed);
  ctx->runtime_coordinator_audit.source =
    GOODIX_RUNTIME_COORDINATOR_SOURCE_STATE_V2;
  ctx->runtime_coordinator_audit.decision =
    GOODIX_RUNTIME_COORDINATOR_DECISION_STATE_V2_PAIRING_ACTIVATION;
  ctx->runtime_coordinator_audit.writer_enabled = TRUE;
  ctx->runtime_coordinator_audit.pairing_write_count =
    ctx->pairing_activation_audit.persistent_write_count;
  ctx->runtime_coordinator_audit.zero_fdt_seed = TRUE;
  production_activation_start_secure_graph (ctx);
}

static void
production_pairing_activation_progress (GoodixDeviceContext *ctx)
{
  GoodixPairingActivationPhase phase;
  g_autoptr(GBytes) request = NULL;
  g_autoptr(GError) error = NULL;

  if (ctx == NULL || ctx->pairing_activation == NULL || ctx->terminal_fence)
    return;
  phase = goodix_pairing_activation_get_phase (ctx->pairing_activation);
  if (phase == GOODIX_PAIRING_ACTIVATION_TERMINAL)
    {
      context_protocol_failure (
        ctx, goodix_pairing_activation_get_error (ctx->pairing_activation));
      return;
    }
  if (phase == GOODIX_PAIRING_ACTIVATION_TLS)
    {
      production_pairing_activation_ready_tls (ctx);
      return;
    }
  request = goodix_pairing_activation_next_request (ctx->pairing_activation,
                                                     &error);
  if (error != NULL)
    {
      context_protocol_failure (ctx, error);
      return;
    }
  if (request != NULL &&
      !goodix_fpi_usb_backend_submit_out (ctx->fpi_usb_backend,
                                          ctx->generation, request, &error))
    {
      goodix_pairing_activation_out_complete (ctx->pairing_activation, error);
      context_protocol_failure (ctx, error);
      return;
    }
  ctx->runtime_coordinator_audit.pairing_write_count =
    ctx->pairing_activation_audit.persistent_write_count;
  if (goodix_pairing_activation_needs_receive (ctx->pairing_activation) &&
      goodix_fpi_usb_backend_get_outstanding (ctx->fpi_usb_backend) == 0u &&
      !goodix_device_context_arm_receive (ctx, &error))
    context_protocol_failure (ctx, error);
}

static void
production_pairing_activation_out_complete (GoodixFpiUsbBackend *backend,
                                            guint64 submit_generation,
                                            const GError *error,
                                            gpointer user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) backend;
  if (ctx->pairing_activation == NULL ||
      submit_generation != ctx->generation || ctx->terminal_fence)
    return;
  goodix_pairing_activation_out_complete (ctx->pairing_activation, error);
  production_pairing_activation_progress (ctx);
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
/* Offline integration seam.  It redirects the production state-v2/legacy
 * directories to test-owned paths and pins the pairing PSK so the fake-USB
 * graph can derive the expected validator.  Absent from production builds. */
static gchar *goodix_test_production_state_directory;
static gchar *goodix_test_production_legacy_directory;
static guint goodix_test_production_state_uid;
static guint goodix_test_production_state_gid;
static guint8 goodix_test_production_pairing_psk[GOODIX_SELF_STATE_PSK_LENGTH];
static gboolean goodix_test_production_pairing_psk_set;

static gboolean
goodix_test_production_state_override_active (void)
{
  return goodix_test_production_state_directory != NULL;
}
#endif

static gboolean
production_start_pairing_activation (
  GoodixDeviceContext               *ctx,
  const GoodixLivePreflightEvidence *evidence,
  GError                           **error)
{
  GoodixPairingActivationPaths paths;
  GoodixPairingActivationPolicy policy;



  /* Pairing activation is the only writer of persistent sensor pairing state.
   * An operator epoch is a host-tool session that must never be able to reach
   * it, whatever the live reconciliation decides; it fails closed instead.
   * begin_operator_epoch() is compiled only under GOODIX_ENABLE_TEST_SEAMS, so
   * no production action can observe this refusal. */
  if (ctx->operator_epoch)
    {
      g_set_error_literal (error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
                           "pairing activation is unavailable in an operator epoch");
      return FALSE;
    }
  if (ctx->runtime_material != NULL || ctx->pairing_activation != NULL)
    {
      g_set_error_literal (error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
                           "pairing activation ownership is not clean");
      return FALSE;
    }
  goodix_pairing_activation_paths_production (&paths);
  goodix_pairing_activation_policy_production (&policy);
#ifdef GOODIX_ENABLE_TEST_SEAMS
  if (goodix_test_production_state_override_active ())
    {
      paths.state_directory = goodix_test_production_state_directory;
      goodix_self_state_policy_for_owner (&policy.state,
                                          goodix_test_production_state_uid,
                                          goodix_test_production_state_gid);
      ctx->pairing_activation = goodix_test_production_pairing_psk_set ?
        goodix_pairing_activation_new_for_test (
          &paths, &policy, evidence, goodix_test_production_pairing_psk,
          &ctx->pairing_activation_audit, error) :
        goodix_pairing_activation_new (
          &paths, &policy, evidence, &ctx->pairing_activation_audit, error);
    }
  else
#endif
  ctx->pairing_activation = goodix_pairing_activation_new (
    &paths, &policy, evidence, &ctx->pairing_activation_audit, error);
  if (ctx->pairing_activation == NULL)
    return FALSE;
  ctx->runtime_coordinator_audit.writer_enabled = TRUE;
  ctx->runtime_coordinator_audit.source =
    GOODIX_RUNTIME_COORDINATOR_SOURCE_STATE_V2;
  ctx->runtime_coordinator_audit.decision =
    GOODIX_RUNTIME_COORDINATOR_DECISION_STATE_V2_PAIRING_ACTIVATION;
  goodix_fpi_usb_backend_set_out_completed_callback (
    ctx->fpi_usb_backend, production_pairing_activation_out_complete, ctx);
  production_pairing_activation_progress (ctx);
  return !ctx->terminal_fence;
}

#if defined(GOODIX_LIBFPRINT_CHICAGO) && defined(GOODIX_ENABLE_TEST_SEAMS)
gboolean
goodix_device_context_test_chicago_pairing_activation (GoodixDeviceContext *ctx, GError **error)
{
  GoodixLivePreflightEvidence evidence = { 0 };
  return production_start_pairing_activation (ctx, &evidence, error);
}
#endif

#ifdef GOODIX_LIBFPRINT_CHICAGO
static gboolean
context_chicago_bind (GoodixDeviceContext *ctx, const guint8 *otp, gsize size)
{
  g_autoptr(GError) error = NULL;
  gboolean bound = !ctx->chicago || goodix_chicago_bind_preflight (ctx->chicago, otp, size, ctx->generation, &error);
  if (ctx->chicago && bound)
    {
      FpiDeviceAction action = fpi_device_get_current_action (FP_DEVICE (ctx->device));
      if (action == FPI_DEVICE_ACTION_VERIFY)
        {
          FpPrint *print;
          fpi_device_get_verify_data (FP_DEVICE (ctx->device), &print);
          bound = goodix_chicago_validate_bound_print (ctx->chicago, print, &error);
        }
      else if (action == FPI_DEVICE_ACTION_IDENTIFY)
        {
          GPtrArray *gallery;
          fpi_device_get_identify_data (FP_DEVICE (ctx->device), &gallery);
          for (guint i = 0; bound && i < gallery->len; i++)
            bound = goodix_chicago_validate_bound_print (ctx->chicago, g_ptr_array_index (gallery, i), &error);
        }
    }
  if (ctx->chicago && !bound)
    {
      goodix_live_preflight_free (ctx->live_preflight);
      ctx->live_preflight = NULL;
      context_protocol_failure (ctx, g_error_new_literal (
        FP_DEVICE_ERROR, FP_DEVICE_ERROR_DATA_INVALID,
        "Chicago calibration is not bound to this reader's OTP"));
      return FALSE;
    }
  return TRUE;
}
#endif

static void
production_live_preflight_finish (GoodixDeviceContext *ctx)
{
  GoodixLivePreflightEvidence evidence = { 0 };
  g_autoptr(GError) error = NULL;
  gboolean ready = FALSE;
  gboolean start_pairing = FALSE;

  if (!goodix_live_preflight_copy_evidence (ctx->live_preflight, &evidence))
    {
      context_protocol_failure (
        ctx, g_error_new_literal (FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
                                  "live preflight completed without evidence"));
      return;
    }
  goodix_fpi_usb_backend_set_out_completed_callback (ctx->fpi_usb_backend,
                                                      NULL, NULL);
#ifdef GOODIX_LIBFPRINT_CHICAGO
  /* Existing A6 evidence only; bind before material acquisition, TLS or E0. */
  if (!context_chicago_bind (ctx, evidence.otp, sizeof evidence.otp))
    { OPENSSL_cleanse (&evidence, sizeof evidence); return; }
#endif
  if (ctx->runtime_material != NULL)
    {
      ready = production_live_preflight_validate_legacy_target (
        ctx, &evidence, &error);
      if (ready && production_live_preflight_legacy_validator_matches (
                     ctx, &evidence))
        {
          OPENSSL_cleanse (ctx->runtime_fdt_seed,
                           sizeof ctx->runtime_fdt_seed);
          ctx->runtime_coordinator_audit.zero_fdt_seed = TRUE;
        }
      else if (ready)
        {
          production_release_runtime_material (ctx);
          start_pairing = TRUE;
          ready = FALSE;
        }
    }
  else
    {
      ready = production_live_preflight_acquire_state (ctx, &evidence, &error);
      if (!ready &&
          (ctx->runtime_coordinator_audit.state_load_result ==
             GOODIX_SELF_STATE_LOAD_ABSENT ||
           ctx->runtime_coordinator_audit.decision ==
             GOODIX_RUNTIME_COORDINATOR_DECISION_EXTERNAL_REPLACEMENT))
        {
          g_clear_error (&error);
          start_pairing = TRUE;
        }
    }
  goodix_live_preflight_free (ctx->live_preflight);
  ctx->live_preflight = NULL;
  if (start_pairing)
    {
      if (!production_start_pairing_activation (ctx, &evidence, &error))
        context_protocol_failure (ctx, error);
      OPENSSL_cleanse (&evidence, sizeof evidence);
      return;
    }
  OPENSSL_cleanse (&evidence, sizeof evidence);
  if (!ready)
    {
      context_protocol_failure (ctx, error);
      return;
    }
  production_activation_start_secure_graph (ctx);
}

static void
production_live_preflight_progress (GoodixDeviceContext *ctx)
{
  g_autoptr(GBytes) request = NULL;
  g_autoptr(GError) error = NULL;
  GoodixLivePreflightPhase phase;

  if (ctx == NULL || ctx->live_preflight == NULL || ctx->terminal_fence)
    return;
  phase = goodix_live_preflight_get_phase (ctx->live_preflight);
  if (phase == GOODIX_LIVE_PREFLIGHT_TERMINAL)
    {
      context_protocol_failure (ctx,
        goodix_live_preflight_get_error (ctx->live_preflight));
      return;
    }
  if (phase == GOODIX_LIVE_PREFLIGHT_STOP)
    {
      production_live_preflight_finish (ctx);
      return;
    }
  request = goodix_live_preflight_next_request (ctx->live_preflight, &error);
  if (error != NULL)
    {
      context_protocol_failure (ctx, error);
      return;
    }
  if (request != NULL &&
      !goodix_fpi_usb_backend_submit_out (ctx->fpi_usb_backend,
                                          ctx->generation, request, &error))
    {
      goodix_live_preflight_out_complete (ctx->live_preflight, error);
      context_protocol_failure (ctx, error);
      return;
    }
  if (ctx->live_preflight != NULL &&
      goodix_live_preflight_needs_receive (ctx->live_preflight) &&
      goodix_fpi_usb_backend_get_outstanding (ctx->fpi_usb_backend) == 0u &&
      !goodix_device_context_arm_receive (ctx, &error))
    context_protocol_failure (ctx, error);
}

static void
production_live_preflight_out_complete (GoodixFpiUsbBackend *backend,
                                        guint64 submit_generation,
                                        const GError *error,
                                        gpointer user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) backend;
  if (ctx->live_preflight == NULL || submit_generation != ctx->generation ||
      ctx->terminal_fence)
    return;
  goodix_live_preflight_out_complete (ctx->live_preflight, error);
  production_live_preflight_progress (ctx);
}

static void
production_activation_start_live_preflight (GoodixDeviceContext *ctx)
{
  if (ctx == NULL || ctx->terminal_fence || ctx->operator_epoch ||
      ctx->live_preflight != NULL || !ctx->usb_interface_claimed ||
      !production_action_requires_live_preflight (
        fpi_device_get_current_action (FP_DEVICE (ctx->device))))
    return;
  ctx->live_preflight = goodix_live_preflight_new (
    &ctx->live_preflight_audit);
  goodix_fpi_usb_backend_set_out_completed_callback (
    ctx->fpi_usb_backend, production_live_preflight_out_complete, ctx);
  production_live_preflight_progress (ctx);
}

static void
context_pre_session_sync_completed (GoodixFpiUsbBackend *backend,
                                    guint64 submit_generation,
                                    const guint8 *data,
                                    gsize length,
                                    const GError *error,
                                    gpointer user_data)
{
  GoodixDeviceContext *ctx = user_data;
  GoodixPreSessionRxSyncAudit *audit = &ctx->pre_session_rx_sync_audit;
  g_autoptr(GError) local_error = NULL;

  (void) backend;
  pre_session_rx_sync_update_elapsed (ctx);
  audit->pre_session_rx_max_outstanding = MAX (
    audit->pre_session_rx_max_outstanding,
    goodix_fpi_usb_backend_get_max_outstanding (ctx->fpi_usb_backend));
  if (submit_generation != ctx->generation ||
      audit->pre_session_rx_result != GOODIX_PRE_SESSION_RX_SYNC_ACTIVE)
    return;

  if (audit->pre_session_rx_elapsed_ms >
      GOODIX_PRE_SESSION_RX_MAX_TOTAL_MS)
    {
      local_error = g_error_new_literal (
        G_IO_ERROR, G_IO_ERROR_TIMED_OUT,
        "pre-session RX sync total-time bound exceeded");
      pre_session_rx_sync_fail (ctx, local_error);
      return;
    }

  if (error != NULL)
    {
      if (g_error_matches (error, G_USB_DEVICE_ERROR,
                           G_USB_DEVICE_ERROR_TIMED_OUT) && length == 0 &&
          goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
        {
          audit->pre_session_rx_timeout_count++;
          audit->pre_session_rx_quiet_boundary = TRUE;
          if (!goodix_fpi_usb_backend_end_pre_session_sync (
                ctx->fpi_usb_backend, ctx->generation, &local_error))
            {
              pre_session_rx_sync_fail (ctx, local_error);
              return;
            }
          audit->pre_session_rx_sync_completed = TRUE;
          audit->pre_session_rx_result = GOODIX_PRE_SESSION_RX_SYNC_PASS;
          ctx->pre_session_rx_sync_out_count_at_pass =
            goodix_fpi_usb_backend_get_out_submit_count (
              ctx->fpi_usb_backend);
          if (!ctx->operator_epoch)
            {
              if (production_action_requires_live_preflight (
                    fpi_device_get_current_action (FP_DEVICE (ctx->device)))
#ifdef GOODIX_ENABLE_TEST_SEAMS
                  && !ctx->bypass_live_preflight_for_material_seam
#endif
                 )
                production_activation_start_live_preflight (ctx);
              else
                production_activation_start_secure_graph (ctx);
            }
          return;
        }
      audit->pre_session_rx_non_timeout_error_count++;
      pre_session_rx_sync_fail (ctx, error);
      return;
    }

  if (length == 0 || data == NULL)
    {
      local_error = g_error_new_literal (
        G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
        "pre-session RX sync completed without timeout or data");
      pre_session_rx_sync_fail (ctx, local_error);
      return;
    }

  audit->pre_session_rx_discarded_completion_count++;
  audit->pre_session_rx_discarded_byte_count += length;
  if (audit->pre_session_rx_discarded_completion_count >
        GOODIX_PRE_SESSION_RX_MAX_COMPLETIONS ||
      audit->pre_session_rx_discarded_byte_count >
        GOODIX_PRE_SESSION_RX_MAX_BYTES ||
      audit->pre_session_rx_elapsed_ms > GOODIX_PRE_SESSION_RX_MAX_TOTAL_MS ||
      audit->pre_session_rx_elapsed_ms +
        GOODIX_PRE_SESSION_RX_QUIET_TIMEOUT_MS >
        GOODIX_PRE_SESSION_RX_MAX_TOTAL_MS)
    {
      local_error = g_error_new_literal (
        G_IO_ERROR, G_IO_ERROR_NO_SPACE,
        "pre-session RX sync hard bound exceeded");
      pre_session_rx_sync_fail (ctx, local_error);
      return;
    }

  if (!goodix_fpi_usb_backend_arm_pre_session_sync_receive (
        ctx->fpi_usb_backend, ctx->generation,
        GOODIX_PRE_SESSION_RX_QUIET_TIMEOUT_MS, &local_error))
    pre_session_rx_sync_fail (ctx, local_error);
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
gboolean
goodix_fpimage_device_test_action_requires_live_preflight (
  FpiDeviceAction action)
{
  return production_action_requires_live_preflight (action);
}

gboolean
goodix_fpimage_device_test_action_may_start_without_material (
  FpiDeviceAction action, GoodixRuntimeCoordinatorDecision decision)
{
  return production_action_may_start_without_material (action, decision);
}

GoodixUsbRouter *
goodix_device_context_get_usb_router (GoodixDeviceContext *ctx)
{
  g_return_val_if_fail (ctx != NULL, NULL);
  return ctx->usb_router;
}

GoodixTlsServer *goodix_device_context_get_tls_server (GoodixDeviceContext *ctx)
{
  if (ctx == NULL)
    return NULL;
  return ctx->secure_session != NULL ?
    goodix_secure_session_get_tls_server (ctx->secure_session) : ctx->tls_server;
}
GoodixFpiUsbBackend *goodix_device_context_get_fpi_usb_backend (GoodixDeviceContext *ctx) { return ctx ? ctx->fpi_usb_backend : NULL; }

gboolean
goodix_device_context_adopt_dormant_enrollment_binding (
  GoodixDeviceContext           *ctx,
  GoodixEnrollmentFpiUsbBinding *binding,
  GError                       **error)
{
  if (ctx == NULL || binding == NULL || !ctx->operator_epoch ||
      ctx->terminal_fence || ctx->generation == 0u ||
      ctx->enrollment_binding != NULL || ctx->secure_session != NULL ||
      ctx->post_tls_lifecycle != NULL || ctx->tls_server != NULL ||
      goodix_enrollment_fpi_usb_binding_is_failed (binding) ||
      goodix_enrollment_fpi_usb_binding_get_backend (binding) !=
        ctx->fpi_usb_backend ||
      goodix_enrollment_fpi_usb_binding_get_generation (binding) !=
        ctx->generation)
    {
      g_set_error_literal (
        error, G_IO_ERROR, G_IO_ERROR_CLOSED,
        "dormant enrollment binding ownership preconditions failed");
      return FALSE;
    }
  ctx->enrollment_binding = binding;
  return TRUE;
}

gboolean
goodix_device_context_has_dormant_enrollment_binding (
  GoodixDeviceContext *ctx)
{
  return ctx != NULL && ctx->enrollment_binding != NULL;
}
#endif


static void context_a0_consumer (guint8 type, GBytes *frame, gpointer user_data)
{
  GoodixDeviceContext *ctx = user_data;
  if (type != 0xa0 || ctx->terminal_fence)
    return;
  ctx->a0_delivery_count++;
  if (ctx->live_preflight != NULL)
    {
      g_autoptr(GError) error = NULL;

      if (!goodix_live_preflight_handle_a0 (ctx->live_preflight, frame,
                                             &error))
        context_protocol_failure (ctx, error);
      else
        production_live_preflight_progress (ctx);
    }
  else if (ctx->pairing_activation != NULL &&
           goodix_pairing_activation_get_phase (ctx->pairing_activation) <
             GOODIX_PAIRING_ACTIVATION_TLS)
    {
      g_autoptr(GError) error = NULL;

      if (!goodix_pairing_activation_handle_a0 (ctx->pairing_activation,
                                                 frame, &error))
        context_protocol_failure (ctx, error);
      else
        production_pairing_activation_progress (ctx);
    }
  else if (ctx->enrollment_binding != NULL)
    {
      g_autoptr(GError) error = NULL;

      ctx->handling_enrollment_a0 = TRUE;
      if (!goodix_enrollment_fpi_usb_binding_handle_a0 (
            ctx->enrollment_binding, frame, &error))
        {
          if (fpi_device_get_current_action (FP_DEVICE (ctx->device)) ==
                FPI_DEVICE_ACTION_ENROLL &&
              goodix_enrollment_post_tls_events_error_is_unusable_contact (error))
            {
              g_autoptr(GError) contact_error = g_error_new_literal (
                FP_DEVICE_ERROR, FP_DEVICE_ERROR_GENERAL, error->message);
              /* A terminal RETRY is not a usable stock KDE outcome: that
               * consumer ignores done=true for retry statuses. Do not emit
               * progress/retry, release the primary, or rearm the graph. */
              context_protocol_failure (ctx, contact_error);
              g_message ("GOODIX_ENROLLMENT_CONTACT_UNUSABLE reason=zero-mask "
                         "outcome=action-aborted primary_delivered=0 retry=0 rearm=0");
            }
          else
            context_protocol_failure (ctx, error);
        }
      else if (ctx->terminal_enroll_completion_held &&
               ctx->runtime_enrollment_events_audit.lifecycle.plan.pipeline.protocol.complete)
        {
          /* The terminal contact callback has already reported finger-off.
           * Release only after the complete A0 transaction unwinds, so the
           * resulting framework deactivation cannot cancel its own event. */
          ctx->terminal_enroll_completion_held = FALSE;
          ctx->terminal_enroll_completion_release_count++;
          fpi_image_device_release_enroll_completion (
            FP_IMAGE_DEVICE (ctx->device));
        }
      ctx->handling_enrollment_a0 = FALSE;
      if (!ctx->terminal_fence)
        goodix_device_context_maybe_rearm (ctx);
    }
  else if (ctx->post_tls_lifecycle != NULL &&
      goodix_post_tls_lifecycle_get_phase (ctx->post_tls_lifecycle) !=
        GOODIX_POST_TLS_PHASE_NOT_STARTED)
    goodix_post_tls_lifecycle_handle_a0 (ctx->post_tls_lifecycle, frame);
  else if (ctx->secure_session != NULL)
    goodix_secure_session_handle_a0 (ctx->secure_session, frame);
}
static void context_b0_consumer (guint8 type, GBytes *frame, gpointer user_data)
{
  GoodixDeviceContext *ctx=user_data; gsize n; const guint8 *p; g_autoptr(GError) error=NULL;
  if(type!=0xb0||ctx->terminal_fence)return;
  if(ctx->secure_session!=NULL){goodix_secure_session_handle_b0(ctx->secure_session,frame);return;}
  /* Host-only decrypted-plaintext injection. Production always retains the
   * secure-session branch above, so TLS records cannot bypass authentication. */
  if((ctx->operator_epoch||
      !goodix_fpimage_device_is_production_usb(ctx->device))&&
     ctx->enrollment_binding!=NULL){
    g_autoptr(GBytes) plaintext=NULL;
    p=g_bytes_get_data(frame,&n);
    if(n<=4){context_protocol_failure(ctx,NULL);return;}
    plaintext=g_bytes_new_from_bytes(frame,4u,n-4u);
    if(!goodix_enrollment_fpi_usb_binding_handle_plaintext_chunk(
         ctx->enrollment_binding,plaintext,&error))
      context_protocol_failure(ctx,error);
    return;
  }
  if(!ctx->tls_server)return;
  p=g_bytes_get_data(frame,&n);
  if(n<=4||!goodix_tls_server_push(ctx->tls_server,p+4,n-4,&error))
    { goodix_device_context_set_terminal_fence(ctx); goodix_device_context_set_poisoned(ctx,error); }
}
#ifdef GOODIX_ENABLE_TEST_SEAMS
static void context_tls_output (GBytes *record, gpointer user_data)
{
  GoodixDeviceContext *ctx=user_data; gsize n; const guint8 *p=g_bytes_get_data(record,&n); g_autoptr(GByteArray) frame=NULL; g_autoptr(GBytes) bytes=NULL; g_autoptr(GError) error=NULL; guint8 h[4];
  if(ctx->terminal_fence||n>G_MAXUINT16)return;
  h[0]=0xb0;h[1]=(guint8)n;h[2]=(guint8)(n>>8);h[3]=(guint8)(h[0]+h[1]+h[2]);
  frame=g_byte_array_sized_new((guint)n+4);g_byte_array_append(frame,h,4);g_byte_array_append(frame,p,(guint)n);bytes=g_byte_array_free_to_bytes(g_steal_pointer(&frame));
  if(!goodix_fpi_usb_backend_submit_out(ctx->fpi_usb_backend,ctx->generation,bytes,&error)){goodix_device_context_set_terminal_fence(ctx);goodix_device_context_set_poisoned(ctx,error);}
}
static void context_tls_plaintext (GBytes *bytes, gpointer user_data)
{ GoodixDeviceContext *ctx=user_data; if(!ctx->terminal_fence&&ctx->tls_plaintext)ctx->tls_plaintext(bytes,ctx->tls_user_data); }
#endif

/* --- Backend command recording --- */

static void
backend_record_command (GoodixDeviceContext *ctx, const gchar *name)
{
  GoodixInMemoryBackend *backend = &ctx->backend;

  backend->total_command_count++;
  g_free (backend->last_command);
  backend->last_command = g_strdup (name);
}

static void
backend_arm (GoodixDeviceContext *ctx, gpointer user_data)
{
  (void) user_data;
  ctx->backend.arm_count++;
  backend_record_command (ctx, "arm");
}

static void
backend_disarm (GoodixDeviceContext *ctx, gpointer user_data)
{
  (void) user_data;
  ctx->backend.disarm_count++;
  backend_record_command (ctx, "disarm");
}

static void
backend_rearm (GoodixDeviceContext *ctx, gpointer user_data)
{
  (void) user_data;
  ctx->backend.rearm_count++;
  backend_record_command (ctx, "rearm");
}

static const GoodixBackendVTable goodix_in_memory_backend_vtable = {
  .arm    = backend_arm,
  .disarm = backend_disarm,
  .rearm  = backend_rearm,
};

/* --- Context lifecycle --- */

static GoodixDeviceContext *
goodix_device_context_new (GoodixFpImageDevice *device)
{
  GoodixDeviceContext *ctx;

  ctx = g_new0 (GoodixDeviceContext, 1);
  ctx->device = device;
  ctx->state = GOODIX_DEVICE_CONTEXT_STATE_CLOSED;
  ctx->backend_vtable = &goodix_in_memory_backend_vtable;
  ctx->backend_user_data = &ctx->backend;
  ctx->usb_router = goodix_usb_router_new (context_a0_consumer, context_b0_consumer, ctx);
  ctx->fpi_usb_backend = goodix_fpi_usb_backend_new (FP_DEVICE (device), ctx->usb_router, 0x81, 0x01, 32768);
  goodix_fpi_usb_backend_set_drained_callback (ctx->fpi_usb_backend,
                                               context_usb_drained, ctx);
  goodix_fpi_usb_backend_set_in_completed_callback (ctx->fpi_usb_backend,
                                                    context_usb_in_completed,
                                                    ctx);
  goodix_fpi_usb_backend_set_sync_completed_callback (
    ctx->fpi_usb_backend, context_pre_session_sync_completed, ctx);

  return ctx;
}

static void
goodix_device_context_collect_production_enrollment_audit (
  GoodixDeviceContext              *ctx,
  GoodixProductionEnrollmentAudit *audit,
  gboolean                         context_closed)
{
  g_return_if_fail (ctx != NULL);
  g_return_if_fail (audit != NULL);

  *audit = (GoodixProductionEnrollmentAudit) {
    .production_action = (guint) ctx->production_action,
    .production_action_attempt_count = ctx->production_action_attempt_count,
    .production_rejected_action_count = ctx->production_rejected_action_count,
    .production_action_consumed = ctx->production_action_consumed,
    .production_explicit_verify_reopen_count =
      ctx->production_explicit_verify_reopen_count,
    .production_explicit_identify_reopen_count =
      ctx->production_explicit_identify_reopen_count,
    .production_identify_enroll_handoff_count =
      ctx->production_identify_enroll_handoff_count,
    .production_logical_action_attempt_count =
      ctx->production_logical_action_attempt_count,
    .production_transport_epoch_count =
      ctx->production_transport_epoch_count,
    .production_capture_attempt_count = ctx->production_capture_attempt_count,
    .production_capture_terminal = ctx->production_capture_terminal,
    .production_identify_enroll_handoff_armed =
      ctx->production_identify_enroll_handoff_armed,
    .auxiliary_b0_observed_count = ctx->runtime_enrollment_auxiliary_count,
    .terminal_enroll_completion_hold_count =
      ctx->terminal_enroll_completion_hold_count,
    .terminal_enroll_completion_release_count =
      ctx->terminal_enroll_completion_release_count,
    .terminal_enroll_completion_abort_count =
      ctx->terminal_enroll_completion_abort_count,
    .terminal_enroll_completion_held =
      ctx->terminal_enroll_completion_held,
    .pre_session_rx_sync = ctx->pre_session_rx_sync_audit,
    .live_preflight = ctx->live_preflight_audit,
    .pairing_activation = ctx->pairing_activation_audit,
    .runtime_coordinator = ctx->runtime_coordinator_audit,
    .runtime_material = ctx->runtime_material_audit,
    .secure = ctx->runtime_secure_audit,
    .tls = ctx->runtime_tls_audit,
    .post_tls = ctx->runtime_post_tls_audit,
    .enrollment_events = ctx->runtime_enrollment_events_audit,
    .enrollment_binding = ctx->runtime_enrollment_binding_audit,
    .usb_real_submit_count = goodix_fpi_usb_backend_get_real_submit_count (
      ctx->fpi_usb_backend),
    .usb_out_submit_count = goodix_fpi_usb_backend_get_out_submit_count (
      ctx->fpi_usb_backend),
    .usb_in_completion_count = goodix_fpi_usb_backend_get_in_completion_count (
      ctx->fpi_usb_backend),
    .usb_out_completion_count = goodix_fpi_usb_backend_get_out_completion_count (
      ctx->fpi_usb_backend),
    .usb_outstanding_count = goodix_fpi_usb_backend_get_outstanding (
      ctx->fpi_usb_backend),
    .usb_out_outstanding_count = goodix_fpi_usb_backend_get_out_outstanding (
      ctx->fpi_usb_backend),
    .usb_max_in_outstanding_count = goodix_fpi_usb_backend_get_max_outstanding (
      ctx->fpi_usb_backend),
    .usb_max_out_outstanding_count =
      goodix_fpi_usb_backend_get_max_out_outstanding (ctx->fpi_usb_backend),
    .usb_interface_claimed = ctx->usb_interface_claimed,
    .usb_backend_drained = goodix_fpi_usb_backend_is_drained (
      ctx->fpi_usb_backend),
    .runtime_material_present = ctx->runtime_material != NULL,
    .runtime_handoff_views_cleared = ctx->runtime_handoff_views_cleared,
#ifdef GOODIX_LIBFPRINT_SIGFM
    .sigfm_normalization_baseline_pinned =
      ctx->sigfm_baseline_pinned_this_epoch,
    .sigfm_normalization_baseline_reused =
      ctx->sigfm_baseline_reused_this_epoch,
#endif
    .context_closed = context_closed,
  };
}

static void
goodix_fpimage_device_log_production_audit (
  const GoodixProductionEnrollmentAudit *audit)
{
  g_autofree gchar *action_name = NULL;
  guint reopen_count;

  g_return_if_fail (audit != NULL);
  action_name = g_enum_to_string (FPI_TYPE_DEVICE_ACTION,
                                  (gint) audit->production_action);
  reopen_count = audit->secure.transport_reopen_count +
                 audit->post_tls.reopen_count +
                 audit->production_explicit_verify_reopen_count +
                 audit->production_explicit_identify_reopen_count;
  g_message (
    "GOODIX_PRODUCTION_EPOCH_AUDIT action=%s attempts=%u rejected=%u "
    "logical_actions=%u transport_epochs=%u capture_attempts=%u capture_terminal=%u identify_enroll_handoffs=%u "
    "identify_enroll_armed=%u consumed=%u tls=%u "
    "first_image=%u release_tail=%u single_terminal=%u rearm32=%u "
    "fdt_samples=%u fdt_learned=%u "
    "fdt_learned_once=%u fdt_delta_within=%u fdt_delta_outside=%u "
    "fdt36_submits=%u fdt_baseline_b0=%u fdt_baseline_decode=%u "
    "enroll_stages=%u enroll_rearm32=%u enroll_terminal=%u "
    "enroll_contacts=%u enroll_retry_scans=%u "
    "secure_commands=%u secure_acks=%u secure_typed=%u "
    "secure_failure=%u secure_phase=%s secure_failure_kind=%s "
    "secure_control=%d secure_ack_echo=%d secure_ack_status=%d "
    "secure_body_length=%" G_GSSIZE_FORMAT " secure_e4_contract=%s "
    "secure_retry=%u post_retry=%u reopen=%u explicit_verify_reopen=%u "
    "explicit_identify_reopen=%u "
    "reset=%u clear_halt=%u persistent=%u coordinator_source=%u "
    "coordinator_decision=%u preflight_complete=%u preflight_commands=%u "
    "preflight_persistent=%u zero_seed=%u pairing_writer=%u pairing_writes=%u "
    "pairing_prepared=%u pairing_e0_reserved=%u pairing_readback=%u "
    "pairing_validator=%u pairing_tls=%u pairing_active=%u pairing_recovered=%u "
    "pairing_active_reused=%u pairing_disposition=%u "
    "sigfm_baseline_pinned=%u sigfm_baseline_reused=%u "
    "real_submit=%" G_GUINT64_FORMAT " "
    "outstanding=%u drained=%u context_closed=%u",
    action_name != NULL ? action_name : "UNKNOWN",
    audit->production_action_attempt_count,
    audit->production_rejected_action_count,
    audit->production_logical_action_attempt_count,
    audit->production_transport_epoch_count,
    audit->production_capture_attempt_count,
    audit->production_capture_terminal,
    audit->production_identify_enroll_handoff_count,
    audit->production_identify_enroll_handoff_armed,
    audit->production_action_consumed,
    audit->tls.handshake_count,
    audit->post_tls.first_image_pipeline_count,
    audit->post_tls.release_tail_complete_count,
    audit->post_tls.single_acquisition_terminal_count,
    audit->post_tls.rearm_0x32_count,
    audit->post_tls.fdt_irq100_count,
    audit->post_tls.learned_fdt_ready,
    audit->post_tls.fresh_fdt_count,
    audit->post_tls.fdt_delta_within_threshold_count,
    audit->post_tls.fdt_delta_outside_threshold_count,
    audit->post_tls.fdt36_submit_count,
    audit->post_tls.baseline_b0_count,
    audit->post_tls.baseline_decode_count,
    audit->enrollment_events.lifecycle.plan.pipeline.protocol.completed_stage_count,
    audit->enrollment_events.lifecycle.plan.inter_stage_rearm_count,
    audit->enrollment_events.lifecycle.plan.pipeline.protocol.terminal_transition_count,
    audit->enrollment_events.lifecycle.plan.pipeline.protocol.observed_primary_stage_count,
    audit->enrollment_events.lifecycle.plan.pipeline.protocol.retry_stage_count,
    audit->secure.command_count,
    audit->secure.ack_count,
    audit->secure.typed_response_count,
    audit->secure.protocol_failure_recorded,
    audit->secure.protocol_failure_recorded ?
      goodix_secure_phase_name (audit->secure.protocol_failure_phase) :
      "NONE",
    audit->secure.protocol_failure_recorded ?
      goodix_protocol_failure_kind_name (
        audit->secure.protocol_failure_kind) :
      "NONE",
    audit->secure.observed_a0_control,
    audit->secure.observed_ack_echo,
    audit->secure.observed_ack_status,
    audit->secure.observed_body_length,
    goodix_e4_contract_result_name (audit->secure.e4_contract_result),
    audit->secure.retry_count,
    audit->post_tls.retry_count,
    reopen_count,
    audit->production_explicit_verify_reopen_count,
    audit->production_explicit_identify_reopen_count,
    audit->secure.device_reset_count + audit->post_tls.device_reset_count,
    audit->secure.clear_halt_count + audit->post_tls.clear_halt_count,
    audit->secure.persistent_write_count +
      audit->post_tls.persistent_device_write_count +
      audit->enrollment_binding.transaction.frame.persistent_family_count +
      audit->pairing_activation.persistent_write_count,
    audit->runtime_coordinator.source,
    audit->runtime_coordinator.decision,
    audit->live_preflight.complete,
    audit->live_preflight.command_count,
    audit->live_preflight.persistent_write_count,
    audit->runtime_coordinator.zero_fdt_seed,
    audit->runtime_coordinator.writer_enabled,
    audit->runtime_coordinator.pairing_write_count,
    audit->pairing_activation.prepared_journaled,
    audit->pairing_activation.e0_reserved_before_submit,
    audit->pairing_activation.bb010002_readback_match,
    audit->pairing_activation.validator_readback_match,
    audit->pairing_activation.tls_proven,
    audit->pairing_activation.active_promoted,
    audit->pairing_activation.recovered_without_e0,
    audit->pairing_activation.active_reused_without_e0,
    audit->pairing_activation.disposition,
    audit->sigfm_normalization_baseline_pinned,
    audit->sigfm_normalization_baseline_reused,
    audit->usb_real_submit_count,
    audit->usb_outstanding_count,
    audit->usb_backend_drained,
    audit->context_closed);
}

static void
goodix_device_context_free (GoodixDeviceContext              *ctx,
                            GoodixProductionEnrollmentAudit *final_audit)
{
  if (ctx == NULL)
    return;

  g_return_if_fail (goodix_fpi_usb_backend_is_drained (
                      ctx->fpi_usb_backend));
  g_return_if_fail (ctx->enrollment_binding == NULL ||
                    goodix_enrollment_fpi_usb_binding_can_free (
                      ctx->enrollment_binding));

  g_clear_handle_id (&ctx->login_deadline, g_source_remove);
#ifdef GOODIX_LIBFPRINT_CHICAGO
  goodix_chicago_clear_binding (ctx->chicago);
#endif
  g_clear_object (&ctx->activation_cancellable);
  g_clear_object (&ctx->usb_cancellable);
  g_clear_error (&ctx->terminal_error);
  g_free (ctx->backend.last_command);
  goodix_post_tls_lifecycle_free (ctx->post_tls_lifecycle);
  goodix_live_preflight_free (ctx->live_preflight);
  goodix_pairing_activation_free (ctx->pairing_activation);
  goodix_secure_session_free (ctx->secure_session);
  goodix_tls_server_free (ctx->tls_server);
  goodix_enrollment_fpi_usb_binding_free (ctx->enrollment_binding);
  goodix_enrollment_post_tls_events_free (ctx->pending_enrollment_events);
#ifdef GOODIX_LIBFPRINT_CHICAGO
  goodix_chicago_free (ctx->chicago);
#endif
  goodix_enrollment_diversity_free (ctx->enrollment_diversity);
  OPENSSL_cleanse (&ctx->runtime_secure_view,
                   sizeof ctx->runtime_secure_view);
  OPENSSL_cleanse (ctx->runtime_fdt_seed, sizeof ctx->runtime_fdt_seed);
#ifdef GOODIX_LIBFPRINT_SIGFM
  OPENSSL_cleanse (ctx->sigfm_baseline, sizeof ctx->sigfm_baseline);
  ctx->sigfm_baseline_valid = FALSE;
#endif
  if (ctx->runtime_material != NULL)
    {
#ifdef GOODIX_ENABLE_TEST_SEAMS
      g_assert (ctx->runtime_material_release != NULL);
      ctx->runtime_material_release (ctx->runtime_material,
                                     ctx->runtime_material_release_data);
#else
      default_release_runtime_material (ctx->runtime_material, NULL);
#endif
      ctx->runtime_material = NULL;
    }
  if (final_audit != NULL)
    goodix_device_context_collect_production_enrollment_audit (
      ctx, final_audit, TRUE);
  goodix_fpi_usb_backend_free (ctx->fpi_usb_backend);
  goodix_usb_router_free (ctx->usb_router);
  g_free (ctx);
}

static gboolean
default_acquire_legacy_material (
  GoodixRuntimeMaterial       **owner,
  GoodixSecureSessionMaterial  *secure_view,
  guint8                        fdt_seed[GOODIX_RUNTIME_FDT_SEED_LENGTH],
  GoodixRuntimeMaterialAudit   *audit,
  gpointer                      user_data,
  GError                      **error)
{
  GoodixRuntimeMaterialPaths paths;
  GoodixRuntimeMaterialPolicy policy;

  (void) user_data;
  goodix_runtime_material_paths_production (&paths);
  goodix_runtime_material_policy_production (&policy);
  *owner = goodix_runtime_material_load (&paths, &policy, audit, error);
  if (*owner == NULL)
    return FALSE;
  if (!goodix_runtime_material_get_secure_view (*owner, secure_view, error) ||
      !goodix_runtime_material_get_fdt_seed (*owner, fdt_seed, error))
    {
      goodix_runtime_material_free (*owner);
      *owner = NULL;
      OPENSSL_cleanse (secure_view, sizeof *secure_view);
      OPENSSL_cleanse (fdt_seed, GOODIX_RUNTIME_FDT_SEED_LENGTH);
      return FALSE;
    }
  return TRUE;
}

static void
default_release_legacy_material (GoodixRuntimeMaterial *owner,
                                 gpointer               user_data)
{
  (void) user_data;
  goodix_runtime_material_free (owner);
}

static gboolean
default_acquire_runtime_material_with_live (
  const GoodixRuntimeCoordinatorLiveEvidence *live,
  GoodixRuntimeCoordinator                  **owner,
  GoodixSecureSessionMaterial                *secure_view,
  guint8                                      fdt_seed[GOODIX_RUNTIME_FDT_SEED_LENGTH],
  GoodixRuntimeCoordinatorAudit *coordinator_audit,
  GoodixRuntimeMaterialAudit                  *audit,
  GError                                    **error)
{
  GoodixRuntimeCoordinatorPaths paths;
  GoodixRuntimeCoordinatorPolicy policy;

  goodix_runtime_coordinator_paths_production (&paths);
  goodix_runtime_coordinator_policy_production (&policy);
#ifdef GOODIX_ENABLE_TEST_SEAMS
  if (goodix_test_production_state_override_active ())
    {
      paths.state_directory = goodix_test_production_state_directory;
      paths.legacy.directory_path = goodix_test_production_legacy_directory;
      goodix_self_state_policy_for_owner (&policy.state,
                                          goodix_test_production_state_uid,
                                          goodix_test_production_state_gid);
    }
#endif
  *owner = goodix_runtime_coordinator_acquire (
    &paths, &policy, live, default_acquire_legacy_material,
    default_release_legacy_material, NULL, audit, coordinator_audit, error);
  if (*owner == NULL)
    return FALSE;
  if (!goodix_runtime_coordinator_get_secure_view (*owner, secure_view,
                                                   error) ||
      !goodix_runtime_coordinator_get_fdt_seed (*owner, fdt_seed, error))
    {
      goodix_runtime_coordinator_free (*owner);
      *owner = NULL;
      OPENSSL_cleanse (secure_view, sizeof *secure_view);
      OPENSSL_cleanse (fdt_seed, GOODIX_RUNTIME_FDT_SEED_LENGTH);
      return FALSE;
    }
  return TRUE;
}

static gboolean
default_acquire_runtime_material (
  GoodixRuntimeCoordinator     **owner,
  GoodixSecureSessionMaterial  *secure_view,
  guint8                        fdt_seed[GOODIX_RUNTIME_FDT_SEED_LENGTH],
  GoodixRuntimeCoordinatorAudit *coordinator_audit,
  GoodixRuntimeMaterialAudit   *audit,
  gpointer                      user_data,
  GError                      **error)
{
  (void) user_data;
  return default_acquire_runtime_material_with_live (
    NULL, owner, secure_view, fdt_seed, coordinator_audit, audit, error);
}

static void
default_release_runtime_material (GoodixRuntimeCoordinator *owner,
                                  gpointer                  user_data)
{
  (void) user_data;
  goodix_runtime_coordinator_free (owner);
}

static gboolean
default_claim_interface (GUsbDevice *usb_device,
                         guint8      interface_number,
                         gpointer    user_data,
                         GError    **error)
{
  (void) user_data;
  return g_usb_device_claim_interface (
    usb_device, interface_number, G_USB_DEVICE_CLAIM_INTERFACE_NONE, error);
}

static gboolean
default_release_interface (GUsbDevice *usb_device,
                           guint8      interface_number,
                           gpointer    user_data,
                           GError    **error)
{
  (void) user_data;
  return g_usb_device_release_interface (
    usb_device, interface_number, G_USB_DEVICE_CLAIM_INTERFACE_NONE, error);
}

static gboolean
goodix_fpimage_device_is_production_usb (GoodixFpImageDevice *self)
{
  return FP_DEVICE_GET_CLASS (self)->type == FP_DEVICE_TYPE_USB;
}

static gboolean
goodix_fpimage_device_acquire_action_resources (GoodixFpImageDevice *self,
                                                GError             **error)
{
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);
  GoodixDeviceContext *ctx = priv->ctx;
  GCancellable *cancellable;
  gboolean material_ready;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  GoodixRuntimeCoordinatorAcquireSeam acquire_material;
  GoodixUsbInterfaceSeam claim_interface;
#endif

  if (ctx == NULL || ctx->runtime_material != NULL ||
      ctx->pairing_activation != NULL ||
      ctx->usb_interface_claimed)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "Goodix action resources are not clean");
      return FALSE;
    }
  cancellable = fpi_device_get_cancellable (FP_DEVICE (self));
  if (g_cancellable_set_error_if_cancelled (cancellable, error))
    return FALSE;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  acquire_material = priv->acquire_material != NULL ?
    priv->acquire_material : default_acquire_runtime_material;
  ctx->bypass_live_preflight_for_material_seam =
    priv->acquire_material != NULL;
  ctx->runtime_material_release = priv->release_material != NULL ?
    priv->release_material : default_release_runtime_material;
  ctx->runtime_material_release_data = priv->production_seam_data;
  material_ready = acquire_material (&ctx->runtime_material,
                                     &ctx->runtime_secure_view,
                                     ctx->runtime_fdt_seed,
                                     &ctx->runtime_coordinator_audit,
                                     &ctx->runtime_material_audit,
                                     priv->production_seam_data, error) &&
                   ctx->runtime_material != NULL;
#else
  material_ready = default_acquire_runtime_material (
                     &ctx->runtime_material, &ctx->runtime_secure_view,
                     ctx->runtime_fdt_seed, &ctx->runtime_coordinator_audit,
                     &ctx->runtime_material_audit, NULL, error) &&
                   ctx->runtime_material != NULL;
#endif
  if (!material_ready)
    {
      FpiDeviceAction action = fpi_device_get_current_action (FP_DEVICE (self));
      GoodixRuntimeCoordinatorDecision decision =
        ctx->runtime_coordinator_audit.decision;

      if (!production_action_may_start_without_material (action, decision))
        goto fail;
      if (error != NULL)
        g_clear_error (error);
      OPENSSL_cleanse (&ctx->runtime_secure_view,
                       sizeof ctx->runtime_secure_view);
      OPENSSL_cleanse (ctx->runtime_fdt_seed, sizeof ctx->runtime_fdt_seed);
    }
  if (g_cancellable_set_error_if_cancelled (cancellable, error))
    goto fail;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  claim_interface = priv->claim_interface != NULL ?
    priv->claim_interface : default_claim_interface;
  if (!claim_interface (fpi_device_get_usb_device (FP_DEVICE (self)), 0,
                        priv->production_seam_data, error))
    goto fail;
#else
  if (!default_claim_interface (
        fpi_device_get_usb_device (FP_DEVICE (self)), 0, NULL, error))
    goto fail;
#endif
  ctx->usb_interface_claimed = TRUE;
  ctx->production_transport_epoch_count++;
  if (g_cancellable_set_error_if_cancelled (cancellable, error))
    {
      g_autoptr(GError) release_error = NULL;

      (void) goodix_fpimage_device_release_claim (self, &release_error);
      goto fail;
    }
  return TRUE;

fail:
  if (ctx->usb_interface_claimed)
    {
      g_autoptr(GError) release_error = NULL;

      if (!goodix_fpimage_device_release_claim (self, &release_error) &&
          error != NULL && *error == NULL)
        *error = g_steal_pointer (&release_error);
    }
  goodix_device_context_release_epoch_objects (ctx);
  if (error != NULL && *error == NULL)
    g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                         "Goodix action resource acquisition failed closed");
  return FALSE;
}

static gboolean
goodix_fpimage_device_release_claim (GoodixFpImageDevice *self,
                                     GError             **error)
{
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);
  GoodixDeviceContext *ctx = priv->ctx;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  GoodixUsbInterfaceSeam release_interface;
#endif

  if (ctx == NULL || !ctx->usb_interface_claimed)
    return TRUE;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  release_interface = priv->release_interface != NULL ?
    priv->release_interface : default_release_interface;
  if (!release_interface (fpi_device_get_usb_device (FP_DEVICE (self)), 0,
                          priv->production_seam_data, error))
    return FALSE;
#else
  if (!default_release_interface (
        fpi_device_get_usb_device (FP_DEVICE (self)), 0, NULL, error))
    return FALSE;
#endif
  ctx->usb_interface_claimed = FALSE;
  return TRUE;
}

static void
goodix_device_context_release_epoch_objects (GoodixDeviceContext *ctx)
{
  g_clear_object (&ctx->activation_cancellable);
  g_clear_object (&ctx->usb_cancellable);
  g_clear_error (&ctx->terminal_error);
  goodix_post_tls_lifecycle_free (ctx->post_tls_lifecycle);
  ctx->post_tls_lifecycle = NULL;
  goodix_live_preflight_free (ctx->live_preflight);
  ctx->live_preflight = NULL;
  goodix_pairing_activation_free (ctx->pairing_activation);
  ctx->pairing_activation = NULL;
  goodix_secure_session_free (ctx->secure_session);
  ctx->secure_session = NULL;
  goodix_tls_server_free (ctx->tls_server);
  ctx->tls_server = NULL;
  goodix_enrollment_fpi_usb_binding_free (ctx->enrollment_binding);
  ctx->enrollment_binding = NULL;
  goodix_enrollment_post_tls_events_free (ctx->pending_enrollment_events);
  ctx->pending_enrollment_events = NULL;
  goodix_enrollment_diversity_free (ctx->enrollment_diversity);
  ctx->enrollment_diversity = NULL;
  ctx->tls_plaintext = NULL;
  ctx->tls_user_data = NULL;
  ctx->enrollment_auxiliary = NULL;
  ctx->enrollment_auxiliary_data = NULL;
  ctx->enrollment_binding_audit = NULL;
  OPENSSL_cleanse (&ctx->runtime_secure_view,
                   sizeof ctx->runtime_secure_view);
  OPENSSL_cleanse (ctx->runtime_fdt_seed, sizeof ctx->runtime_fdt_seed);
  /* Keep the normalization baseline pinned across clean explicit capture
   * rollovers (VERIFY or IDENTIFY).  goodix_device_context_free() performs
   * the final cleanse at img_close. */
  if (ctx->runtime_material != NULL)
    {
#ifdef GOODIX_ENABLE_TEST_SEAMS
      g_assert (ctx->runtime_material_release != NULL);
      ctx->runtime_material_release (ctx->runtime_material,
                                     ctx->runtime_material_release_data);
#else
      default_release_runtime_material (ctx->runtime_material, NULL);
#endif
      ctx->runtime_material = NULL;
    }
}

static gboolean
goodix_fpimage_device_close_completed_capture_epoch (
  GoodixFpImageDevice *self,
  FpiDeviceAction      action,
  GError             **error)
{
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);
  GoodixDeviceContext *ctx = priv->ctx;

  if (ctx == NULL || ctx->production_action != action ||
      (action != FPI_DEVICE_ACTION_VERIFY &&
       action != FPI_DEVICE_ACTION_IDENTIFY) ||
      !ctx->production_action_consumed || ctx->poisoned ||
      !goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend) ||
      ctx->post_tls_lifecycle == NULL ||
      goodix_post_tls_lifecycle_get_phase (ctx->post_tls_lifecycle) !=
        GOODIX_POST_TLS_PHASE_STOP ||
      ctx->enrollment_binding != NULL ||
      ctx->pending_enrollment_events != NULL)
    {
      g_set_error_literal (
        error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
        "Goodix capture epoch did not reach a clean terminal drain");
      return FALSE;
    }
  if (!goodix_fpimage_device_release_claim (self, error))
    return FALSE;

  goodix_device_context_release_epoch_objects (ctx);
  ctx->generation = 0;
  ctx->production_verify_epoch_closed =
    action == FPI_DEVICE_ACTION_VERIFY;
  ctx->production_identify_epoch_closed =
    action == FPI_DEVICE_ACTION_IDENTIFY;
  ctx->production_identify_enroll_handoff_armed =
    action == FPI_DEVICE_ACTION_IDENTIFY &&
    ctx->production_identify_result_known &&
    ctx->production_identify_result_success &&
    !ctx->production_identify_result_match &&
    !ctx->production_capture_terminal;
  goodix_device_context_collect_production_enrollment_audit (
    ctx, &priv->last_production_audit, TRUE);
  priv->last_production_audit_valid = TRUE;
  priv->last_production_audit_logged = FALSE;
  return TRUE;
}

static void
goodix_device_context_reset_for_capture_reopen (GoodixDeviceContext *ctx,
                                                FpiDeviceAction      action)
{
  ctx->production_action_consumed = FALSE;
  ctx->production_action = FPI_DEVICE_ACTION_NONE;
  ctx->production_action_attempt_count = 0;
  ctx->production_rejected_action_count = 0;
  ctx->production_explicit_verify_reopen_count =
    action == FPI_DEVICE_ACTION_VERIFY ? 1u : 0u;
  ctx->production_explicit_identify_reopen_count =
    action == FPI_DEVICE_ACTION_IDENTIFY ? 1u : 0u;
  ctx->production_verify_epoch_closed = FALSE;
  ctx->production_verify_result_known = FALSE;
  ctx->production_verify_result_success = FALSE;
  ctx->production_verify_result_match = FALSE;
  ctx->production_identify_epoch_closed = FALSE;
  ctx->production_identify_result_known = FALSE;
  ctx->production_identify_result_success = FALSE;
  ctx->production_identify_result_match = FALSE;
  ctx->production_identify_enroll_handoff_armed = FALSE;
  ctx->release_tail_complete = FALSE;
  ctx->fresh_down_table = FALSE;
  ctx->rearm_issued_generation = 0;
  ctx->terminal_fence = TRUE;
  ctx->poisoned = FALSE;
  ctx->activation_completed = FALSE;
  ctx->deactivation_held = FALSE;
  ctx->deactivation_pending = FALSE;
  ctx->deactivation_nonquiescent = FALSE;
  ctx->runtime_handoff_views_cleared = FALSE;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  ctx->bypass_live_preflight_for_material_seam = FALSE;
#endif
#ifdef GOODIX_LIBFPRINT_SIGFM
  ctx->sigfm_baseline_pinned_this_epoch = FALSE;
  ctx->sigfm_baseline_reused_this_epoch = FALSE;
#endif
  ctx->runtime_enrollment_auxiliary_count = 0;
  ctx->terminal_enroll_completion_hold_count = 0;
  ctx->terminal_enroll_completion_release_count = 0;
  ctx->terminal_enroll_completion_abort_count = 0;
  ctx->terminal_enroll_completion_held = FALSE;
  ctx->terminal_delivery_at_release_ready = FALSE;
  memset (&ctx->pre_session_rx_sync_audit, 0,
          sizeof ctx->pre_session_rx_sync_audit);
  ctx->pre_session_rx_sync_started_us = 0;
  ctx->pre_session_rx_sync_out_count_at_pass = 0;
  memset (&ctx->runtime_material_audit, 0,
          sizeof ctx->runtime_material_audit);
  memset (&ctx->runtime_coordinator_audit, 0,
          sizeof ctx->runtime_coordinator_audit);
  memset (&ctx->live_preflight_audit, 0,
          sizeof ctx->live_preflight_audit);
  memset (&ctx->pairing_activation_audit, 0,
          sizeof ctx->pairing_activation_audit);
  memset (&ctx->runtime_secure_audit, 0,
          sizeof ctx->runtime_secure_audit);
  memset (&ctx->runtime_tls_audit, 0,
          sizeof ctx->runtime_tls_audit);
  memset (&ctx->runtime_post_tls_audit, 0,
          sizeof ctx->runtime_post_tls_audit);
  memset (&ctx->runtime_enrollment_events_audit, 0,
          sizeof ctx->runtime_enrollment_events_audit);
  memset (&ctx->runtime_enrollment_binding_audit, 0,
          sizeof ctx->runtime_enrollment_binding_audit);
}

static gboolean
goodix_fpimage_device_reopen_for_capture_action (
  GoodixFpImageDevice *self,
  FpiDeviceAction      action,
  GError             **error)
{
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);
  GoodixDeviceContext *ctx = priv->ctx;
  gboolean material_ready;
#ifdef GOODIX_ENABLE_TEST_SEAMS
  GoodixRuntimeCoordinatorAcquireSeam acquire_material;
  GoodixUsbInterfaceSeam claim_interface;
#endif

  if (ctx == NULL || ctx->poisoned ||
      ((action == FPI_DEVICE_ACTION_VERIFY &&
        !ctx->production_verify_epoch_closed) ||
       (action == FPI_DEVICE_ACTION_IDENTIFY &&
        !ctx->production_identify_epoch_closed) ||
       (action == FPI_DEVICE_ACTION_ENROLL &&
        (!ctx->production_identify_epoch_closed ||
         !ctx->production_identify_enroll_handoff_armed)) ||
       (action != FPI_DEVICE_ACTION_VERIFY &&
        action != FPI_DEVICE_ACTION_IDENTIFY &&
        action != FPI_DEVICE_ACTION_ENROLL)) ||
      ctx->state != GOODIX_DEVICE_CONTEXT_STATE_INACTIVE ||
      ctx->runtime_material != NULL || ctx->pairing_activation != NULL ||
      ctx->usb_interface_claimed ||
      ctx->secure_session != NULL || ctx->post_tls_lifecycle != NULL ||
      !goodix_fpi_usb_backend_reset_epoch_audit (ctx->fpi_usb_backend, error))
    return FALSE;

  if (priv->last_production_audit_valid &&
      !priv->last_production_audit_logged)
    {
      goodix_fpimage_device_log_production_audit (
        &priv->last_production_audit);
      priv->last_production_audit_logged = TRUE;
    }

  goodix_device_context_reset_for_capture_reopen (ctx, action);
#ifdef GOODIX_ENABLE_TEST_SEAMS
  acquire_material = priv->acquire_material != NULL ?
    priv->acquire_material : default_acquire_runtime_material;
  ctx->bypass_live_preflight_for_material_seam =
    priv->acquire_material != NULL;
  ctx->runtime_material_release = priv->release_material != NULL ?
    priv->release_material : default_release_runtime_material;
  ctx->runtime_material_release_data = priv->production_seam_data;
  material_ready = acquire_material (&ctx->runtime_material,
                                     &ctx->runtime_secure_view,
                                     ctx->runtime_fdt_seed,
                                     &ctx->runtime_coordinator_audit,
                                     &ctx->runtime_material_audit,
                                     priv->production_seam_data, error) &&
                   ctx->runtime_material != NULL;
#else
  material_ready = default_acquire_runtime_material (
                     &ctx->runtime_material, &ctx->runtime_secure_view,
                     ctx->runtime_fdt_seed, &ctx->runtime_coordinator_audit,
                     &ctx->runtime_material_audit, NULL, error) &&
                   ctx->runtime_material != NULL;
#endif
  if (!material_ready)
    {
      GoodixRuntimeCoordinatorDecision decision =
        ctx->runtime_coordinator_audit.decision;

      if (!production_action_may_start_without_material (action, decision))
        goto fail;
      if (error != NULL)
        g_clear_error (error);
      OPENSSL_cleanse (&ctx->runtime_secure_view,
                       sizeof ctx->runtime_secure_view);
      OPENSSL_cleanse (ctx->runtime_fdt_seed, sizeof ctx->runtime_fdt_seed);
    }

#ifdef GOODIX_ENABLE_TEST_SEAMS
  claim_interface = priv->claim_interface != NULL ?
    priv->claim_interface : default_claim_interface;
  if (!claim_interface (fpi_device_get_usb_device (FP_DEVICE (self)), 0,
                        priv->production_seam_data, error))
    goto fail;
#else
  if (!default_claim_interface (
        fpi_device_get_usb_device (FP_DEVICE (self)), 0, NULL, error))
    goto fail;
#endif
  ctx->usb_interface_claimed = TRUE;
  ctx->production_transport_epoch_count++;
  if (action == FPI_DEVICE_ACTION_ENROLL)
    {
      ctx->production_identify_enroll_handoff_count++;
      ctx->production_identify_enroll_handoff_armed = FALSE;
    }
  return TRUE;

fail:
  if (error != NULL && *error == NULL)
    g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                         "Goodix capture epoch reopen failed");
  goodix_device_context_release_epoch_objects (ctx);
  ctx->production_verify_epoch_closed = FALSE;
  ctx->production_identify_epoch_closed = FALSE;
  ctx->production_identify_enroll_handoff_armed = FALSE;
  ctx->poisoned = TRUE;
  return FALSE;
}

static void
goodix_fpimage_device_discard_context (GoodixFpImageDevice *self)
{
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);

  if (ctx != NULL)
    {
      goodix_device_context_free (ctx, &priv->last_production_audit);
      priv->last_production_audit_valid = TRUE;
      priv->last_production_audit_logged = FALSE;
    }
  goodix_fpimage_device_set_context (self, NULL);
}

static void
goodix_device_context_set_state (GoodixDeviceContext      *ctx,
                                 GoodixDeviceContextState  state)
{
  ctx->state = state;
}

static void
goodix_device_context_set_poisoned (GoodixDeviceContext *ctx,
                                    const GError        *error)
{
  ctx->poisoned = TRUE;
  if (error != NULL && ctx->terminal_error == NULL)
    ctx->terminal_error = g_error_copy (error);
}

static void
goodix_device_context_set_terminal_fence (GoodixDeviceContext *ctx)
{
  ctx->terminal_fence = TRUE;
  goodix_enrollment_fpi_usb_binding_cancel (
    ctx->enrollment_binding, "GoodixDeviceContext terminal fence");
  if (ctx->secure_session != NULL &&
      goodix_secure_session_get_phase (ctx->secure_session) !=
        GOODIX_SECURE_PHASE_STOP &&
      goodix_secure_session_get_phase (ctx->secure_session) !=
        GOODIX_SECURE_PHASE_TERMINAL)
    goodix_secure_session_cancel (ctx->secure_session,
                                  "GoodixDeviceContext terminal fence");
  if (ctx->post_tls_lifecycle != NULL &&
      goodix_post_tls_lifecycle_get_phase (ctx->post_tls_lifecycle) !=
        GOODIX_POST_TLS_PHASE_STOP &&
      goodix_post_tls_lifecycle_get_phase (ctx->post_tls_lifecycle) !=
        GOODIX_POST_TLS_PHASE_TERMINAL)
    goodix_post_tls_lifecycle_cancel (ctx->post_tls_lifecycle,
                                      "GoodixDeviceContext terminal fence");
  goodix_tls_server_cancel (ctx->tls_server);
  goodix_fpi_usb_backend_cancel (ctx->fpi_usb_backend);
}

static void
goodix_device_context_disconnect_cancel_handler (GoodixDeviceContext *ctx)
{
  if (ctx->cancel_handler_id != 0 && ctx->activation_cancellable != NULL)
    {
      g_cancellable_disconnect (ctx->activation_cancellable,
                                ctx->cancel_handler_id);
      ctx->cancel_handler_id = 0;
    }
}

static void on_activation_cancellable_cancelled (GCancellable *cancellable,
                                                 gpointer      user_data);

static gboolean
goodix_device_context_is_stale_or_fenced (GoodixDeviceContext *ctx)
{
  return ctx->terminal_fence || ctx->generation == 0;
}

static void
goodix_device_context_maybe_rearm (GoodixDeviceContext *ctx)
{
  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;

  if (!ctx->release_tail_complete || !ctx->fresh_down_table)
    return;

  if (ctx->last_framework_state != FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON)
    return;

  if (ctx->enrollment_binding != NULL)
    {
      const GoodixZeroMaskRecoveryAudit *zero =
        goodix_enrollment_fpi_usb_binding_zero_audit (ctx->enrollment_binding);
      if (!ctx->handling_enrollment_a0 && zero->awaiting_sample_request &&
          !g_cancellable_is_cancelled (ctx->activation_cancellable) &&
          fpi_device_get_current_action (FP_DEVICE (ctx->device)) == FPI_DEVICE_ACTION_ENROLL)
        {
          g_autoptr(GError) error = NULL;
          if (!goodix_enrollment_fpi_usb_binding_request_zero_sample (
                ctx->enrollment_binding, &error))
            context_protocol_failure (ctx, error);
        }
      return;
    }

  if (ctx->post_tls_lifecycle != NULL &&
      goodix_post_tls_lifecycle_get_phase (ctx->post_tls_lifecycle) !=
        GOODIX_POST_TLS_PHASE_NOT_STARTED)
    {
      goodix_post_tls_lifecycle_set_framework_await_finger_on (
        ctx->post_tls_lifecycle, ctx->generation, TRUE);
      return;
    }

  if (ctx->rearm_issued_generation == ctx->generation)
    return;

  ctx->rearm_issued_generation = ctx->generation;
  ctx->backend_vtable->rearm (ctx, ctx->backend_user_data);
}

/* --- libfprint vfunc implementations --- */

static gboolean
complete_activation_cancel_idle (gpointer user_data)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (user_data);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);
  g_autoptr(GError) error = NULL;

  if (ctx == NULL ||
      ctx->state != GOODIX_DEVICE_CONTEXT_STATE_INACTIVE ||
      !ctx->activation_completed ||
      ctx->activation_cancellable == NULL)
    return G_SOURCE_REMOVE;

  if (g_cancellable_set_error_if_cancelled (ctx->activation_cancellable,
                                             &error))
    fpi_image_device_activate_complete (FP_IMAGE_DEVICE (self),
                                        g_steal_pointer (&error));

  return G_SOURCE_REMOVE;
}

static void
on_activation_cancellable_cancelled (GCancellable *cancellable,
                                     gpointer      user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) cancellable;

  if (ctx->state != GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING ||
      ctx->activation_completed)
    return;

  /* Do not complete the libfprint action from inside the cancellable
   * dispatch.  clear_device_cancel_action() disconnects both the internal
   * and external cancellables; doing that synchronously here can deadlock
   * against the still-running external cancellation callback. */
  ctx->cancel_handler_id = 0;
  goodix_device_context_set_terminal_fence (ctx);
  ctx->generation = 0;
  /* The backend arm and USB begin_generation have already been reached; the
   * device-side quiescence is unproven, so the remaining open epoch must stay
   * poisoned.  The state is still INACTIVE here so that the activate completion
   * idle can deliver G_IO_ERROR_CANCELLED exactly once. */
  goodix_device_context_set_poisoned (ctx, NULL);
  goodix_device_context_set_state (ctx,
                                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
  ctx->activation_completed = TRUE;

  g_idle_add_full (G_PRIORITY_DEFAULT,
                   complete_activation_cancel_idle,
                   g_object_ref (ctx->device),
                   g_object_unref);
}

static gboolean
open_complete_idle (gpointer user_data)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (user_data);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);
  g_autoptr(GError) error = NULL;
  GCancellable *cancellable;

  cancellable = fpi_device_get_cancellable (FP_DEVICE (self));
  if (g_cancellable_set_error_if_cancelled (cancellable, &error))
    {
      goodix_fpimage_device_discard_context (self);
      fpi_image_device_open_complete (FP_IMAGE_DEVICE (self),
                                      g_steal_pointer (&error));
    }
  else
    {
      goodix_device_context_set_state (ctx,
                                       GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
      fpi_image_device_open_complete (FP_IMAGE_DEVICE (self), NULL);
    }

  g_object_unref (self);
  return G_SOURCE_REMOVE;
}

static void
goodix_fpimage_device_img_open (FpImageDevice *dev)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (dev);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);
  GCancellable *cancellable;
  g_autoptr(GError) error = NULL;

  if (ctx == NULL)
    {
      ctx = goodix_device_context_new (self);
      goodix_fpimage_device_set_context (self, ctx);
      goodix_device_context_set_state (ctx,
                                       GOODIX_DEVICE_CONTEXT_STATE_OPENING);
    }

  g_assert (ctx != NULL);
  g_assert (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_OPENING);

  goodix_device_context_set_state (ctx,
                                   GOODIX_DEVICE_CONTEXT_STATE_OPENING);
  if (!goodix_fpimage_device_is_production_usb (self))
    {
      g_object_ref (self);
      g_idle_add (open_complete_idle, self);
      return;
    }

  cancellable = fpi_device_get_cancellable (FP_DEVICE (self));
  if (g_cancellable_set_error_if_cancelled (cancellable, &error))
    goto fail;

  /* Discovery/open is intentionally inert.  Protected state and USB are
   * acquired only by an allowlisted, explicit libfprint action. */
  goodix_device_context_set_state (ctx,
                                   GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
  fpi_image_device_open_complete (dev, NULL);
  return;

fail:
  goodix_fpimage_device_discard_context (self);
  fpi_image_device_open_complete (dev, g_steal_pointer (&error));
}

static void
goodix_fpimage_device_img_close (FpImageDevice *dev)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (dev);
  GoodixFpImageDevicePrivate *priv =
    goodix_fpimage_device_get_instance_private (self);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);
  g_autoptr(GError) error = NULL;

  g_assert (ctx != NULL);
  if (ctx->login_preparing || ctx->login_series)
    {
      g_clear_handle_id (&ctx->login_deadline, g_source_remove);
      goodix_device_context_set_terminal_fence (ctx);
      if (!goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
        {
          ctx->login_close_pending = TRUE;
          return;
        }
    }

  g_assert (ctx->state != GOODIX_DEVICE_CONTEXT_STATE_CLOSING);

  goodix_device_context_set_terminal_fence (ctx);
  goodix_device_context_set_state (ctx,
                                   GOODIX_DEVICE_CONTEXT_STATE_CLOSING);

  if (ctx->usb_interface_claimed)
    (void) goodix_fpimage_device_release_claim (self, &error);
  goodix_fpimage_device_discard_context (self);

  if (goodix_fpimage_device_is_production_usb (self) &&
      priv->last_production_audit_valid &&
      !priv->last_production_audit_logged)
    {
      goodix_fpimage_device_log_production_audit (
        &priv->last_production_audit);
      priv->last_production_audit_logged = TRUE;
    }

  fpi_image_device_close_complete (dev, g_steal_pointer (&error));
}

static void
goodix_fpimage_device_activate (FpImageDevice *dev)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (dev);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);
  FpiDeviceAction action = fpi_device_get_current_action (FP_DEVICE (self));

  g_assert (ctx != NULL);
  g_assert (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_INACTIVE ||
            ctx->state == GOODIX_DEVICE_CONTEXT_STATE_ACTIVE ||
            ctx->state == GOODIX_DEVICE_CONTEXT_STATE_POISONED);

  g_autoptr(GError) error = NULL;
#ifdef GOODIX_LIBFPRINT_CHICAGO
  if (!ctx->chicago)
    ctx->chicago = goodix_chicago_new ();
  if (!ctx->chicago || error)
    {
      if (!error) error = fpi_device_error_new_msg (FP_DEVICE_ERROR_DATA_INVALID, "Chicago calibration missing");
      fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
      return;
    }
  if (action == FPI_DEVICE_ACTION_ENROLL && !goodix_chicago_enroll_start (ctx->chicago, &error))
    goto chicago_activation_failed;
  if (action == FPI_DEVICE_ACTION_VERIFY)
    {
      FpPrint *print;
      fpi_device_get_verify_data (FP_DEVICE (self), &print);
      if (!goodix_chicago_validate_print (print, &error)) goto chicago_activation_failed;
    }
  if (action == FPI_DEVICE_ACTION_IDENTIFY)
    {
      GPtrArray *gallery;
      fpi_device_get_identify_data (FP_DEVICE (self), &gallery);
      for (guint i = 0; i < gallery->len; i++)
        if (!goodix_chicago_validate_print (g_ptr_array_index (gallery, i), &error)) goto chicago_activation_failed;
    }
  goto chicago_activation_ready;
chicago_activation_failed:
  goodix_chicago_enroll_clear (ctx->chicago);
  fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
  return;
chicago_activation_ready:
#endif

  if (ctx->login_preparing || ctx->login_series)
    {
      gboolean first = ctx->login_preparing;
      if (ctx->terminal_fence || ctx->poisoned || ctx->login_attempts >= 3 ||
          (first ? !ctx->login_ready : !ctx->login_reusable) ||
          (action != FPI_DEVICE_ACTION_VERIFY && action != FPI_DEVICE_ACTION_IDENTIFY) ||
          (first && !goodix_post_tls_lifecycle_authorize_login (ctx->post_tls_lifecycle)))
        {
          fpi_image_device_activate_complete (dev, g_error_new_literal (
            FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_SUPPORTED,
            "Goodix login session unavailable; use password"));
          return;
        }
      g_clear_handle_id (&ctx->login_deadline, g_source_remove);
      ctx->login_preparing = FALSE;
      ctx->login_ready = FALSE;
      ctx->login_series = TRUE;
      ctx->login_reusable = FALSE;
      ctx->login_attempts++;
      ctx->release_tail_complete = FALSE;
      ctx->fresh_down_table = FALSE;
      ctx->production_verify_result_known = FALSE;
      ctx->production_identify_result_known = FALSE;
      ctx->production_logical_action_attempt_count++;
      ctx->production_action_attempt_count++;
      ctx->production_action_consumed = TRUE;
      ctx->production_action = action;
      ctx->activation_completed = TRUE;
      goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_ACTIVE);
      g_message ("GOODIX_LOGIN_ATTACH generation=%" G_GUINT64_FORMAT
                 " attempt=%u limit=3 bootstrap=0 reopen=0 calibration=0",
                 ctx->generation, ctx->login_attempts);
      fpi_image_device_activate_complete (dev, NULL);
      if (!first &&
          (!goodix_post_tls_lifecycle_next_login (ctx->post_tls_lifecycle,
                                                   production_timestamp (), &error) ||
           !goodix_device_context_arm_receive (ctx, &error)))
        context_protocol_failure (ctx, error);
      return;
    }

  /* A non-quiescent terminal poisons the complete open epoch.  Re-entry is
   * forbidden until img_close destroys the context; activation must not clear
   * the fence, allocate a generation or reach either backend while poisoned. */
  if (ctx->poisoned)
    {
      if (ctx->terminal_error != NULL &&
          ctx->terminal_error->domain != FP_DEVICE_RETRY)
        error = g_error_copy (ctx->terminal_error);
      else
        error = g_error_new_literal (
          FP_DEVICE_ERROR, FP_DEVICE_ERROR_PROTO,
          "Goodix protocol session is poisoned until device close");
      fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
      return;
    }

  /* MATCH or processing failure ends this stock Claim before any rollover
   * can acquire material/claim/USB. Clean NO_MATCH allows another explicit
   * request, with no cumulative driver limit. Full close/open resets state. */
  if (goodix_fpimage_device_is_production_usb (self) &&
      ctx->production_capture_terminal)
    {
      ctx->production_rejected_action_count++;
      g_message ("GOODIX_STOCK_CAPTURE_REJECT attempts=%u terminal=1 new_transport=0",
                 ctx->production_capture_attempt_count);
      fpi_image_device_activate_complete (dev, g_error_new_literal (
        FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_SUPPORTED,
        "Goodix capture outcome is terminal; release the device before a new attempt"));
      return;
    }

  if (goodix_fpimage_device_is_production_usb (self) &&
      action != FPI_DEVICE_ACTION_ENROLL &&
      action != FPI_DEVICE_ACTION_VERIFY &&
      action != FPI_DEVICE_ACTION_IDENTIFY)
    {
      error = g_error_new_literal (
        FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_SUPPORTED,
        "Goodix production boundary permits enrollment, verify and identify only");
      fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
      return;
    }

  if (goodix_fpimage_device_is_production_usb (self))
    ctx->production_logical_action_attempt_count++;

  /* A completed IDENTIFY may be followed by a distinct client IDENTIFY in
   * the same logical fprintd claim.  A clean no-match may instead hand off to
   * one ENROLL.  Both paths recreate every transport resource; neither path
   * schedules an action or retry by itself. */
  if (goodix_fpimage_device_is_production_usb (self) &&
      ctx->production_identify_epoch_closed)
    {
      if (action != FPI_DEVICE_ACTION_IDENTIFY &&
          (action != FPI_DEVICE_ACTION_ENROLL ||
           !ctx->production_identify_enroll_handoff_armed))
        {
          ctx->production_action_attempt_count++;
          ctx->production_rejected_action_count++;
          ctx->production_identify_enroll_handoff_armed = FALSE;
          ctx->poisoned = TRUE;
          error = g_error_new_literal (
            FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_SUPPORTED,
            "Goodix completed IDENTIFY epoch accepts only a new IDENTIFY or one clean no-match ENROLL handoff");
          fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
          return;
        }
      if (!goodix_fpimage_device_reopen_for_capture_action (
            self, action, &error))
        {
          if (error == NULL)
            error = g_error_new_literal (
              FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_OPEN,
              "Goodix completed IDENTIFY epoch reopen failed");
          fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
          return;
        }
    }

  /* A completed VERIFY closes its internal production epoch while the
   * libfprint device remains logically open.  Only a later, explicit
   * VerifyStart may reopen it; no acquisition or retry is initiated here. */
  if (goodix_fpimage_device_is_production_usb (self) &&
      ctx->production_verify_epoch_closed)
    {
      if (action != FPI_DEVICE_ACTION_VERIFY)
        {
          error = g_error_new_literal (
            FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_SUPPORTED,
            "Goodix completed VERIFY epoch accepts only a new explicit VerifyStart");
          fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
          return;
        }
      if (!goodix_fpimage_device_reopen_for_capture_action (
            self, FPI_DEVICE_ACTION_VERIFY, &error))
        {
          if (error == NULL)
            error = g_error_new_literal (
              FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_OPEN,
              "Goodix explicit VERIFY epoch reopen failed");
          fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
          return;
        }
    }

  /* The first production action consumes this complete open epoch, including
   * an activation that later fails.  No retry or second action can reuse
   * potentially ambiguous device-side state: img_close/img_open is required. */
  if (goodix_fpimage_device_is_production_usb (self) &&
      ctx->production_action_consumed)
    {
      ctx->production_action_attempt_count++;
      ctx->production_rejected_action_count++;
      error = g_error_new_literal (
        FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_SUPPORTED,
        "Goodix production open epoch already consumed; close/reopen required");
      fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
      return;
    }
  if (goodix_fpimage_device_is_production_usb (self))
    {
      ctx->production_action_attempt_count++;
      ctx->production_action_consumed = TRUE;
      ctx->production_action = action;
      if (action == FPI_DEVICE_ACTION_VERIFY || action == FPI_DEVICE_ACTION_IDENTIFY)
        {
          ctx->production_capture_attempt_count++;
          g_message ("GOODIX_STOCK_CAPTURE_BEGIN attempt=%u action=%s",
                     ctx->production_capture_attempt_count,
                     action == FPI_DEVICE_ACTION_VERIFY ? "VERIFY" : "IDENTIFY");
        }
      if (!ctx->usb_interface_claimed &&
          !goodix_fpimage_device_acquire_action_resources (self, &error))
        {
          ctx->poisoned = TRUE;
          fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
          return;
        }
    }

  /* New activation -> new generation, reset per-activation gates. */
  ctx->generation_seq++;
  ctx->generation = ctx->generation_seq;
  ctx->release_tail_complete = FALSE;
  ctx->fresh_down_table = FALSE;
  ctx->rearm_issued_generation = 0;
  ctx->terminal_fence = FALSE;
  ctx->activation_completed = FALSE;
  g_clear_object (&ctx->activation_cancellable);
  ctx->activation_cancellable = g_object_ref (
    fpi_device_get_cancellable (FP_DEVICE (self)));
  g_clear_object (&ctx->usb_cancellable);
  ctx->usb_cancellable = g_cancellable_new ();
  if (!goodix_fpi_usb_backend_begin_generation (ctx->fpi_usb_backend,
                                                ctx->generation,
                                                ctx->usb_cancellable, &error))
    {
      ctx->terminal_fence = TRUE;
      ctx->poisoned = TRUE;
      ctx->generation = 0;
      goodix_device_context_set_state (ctx,
                                       GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
      fpi_image_device_activate_complete (dev, g_steal_pointer (&error));
      return;
    }
  goodix_usb_router_begin_generation (ctx->usb_router, ctx->generation);
  ctx->cancel_handler_id =
    g_cancellable_connect (ctx->activation_cancellable,
                           G_CALLBACK (on_activation_cancellable_cancelled),
                           ctx, NULL);

  goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING);
  if (goodix_fpimage_device_is_production_usb (self))
    {
      if ((!ctx->usb_interface_claimed) ||
          (ctx->runtime_material == NULL &&
           !production_action_requires_live_preflight (action)))
        {
          error = g_error_new_literal (
            FP_DEVICE_ERROR, FP_DEVICE_ERROR_NOT_OPEN,
            "Goodix production activation lacks its open-epoch resources");
          context_protocol_failure (ctx, error);
          return;
        }
      if (!goodix_device_context_begin_pre_session_rx_sync (ctx, &error) &&
          ctx->state == GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING)
        context_protocol_failure (ctx, error);
      return;
    }
  ctx->backend_vtable->arm (ctx, ctx->backend_user_data);
}

static void
goodix_fpimage_device_change_state (FpImageDevice      *dev,
                                    FpiImageDeviceState  state)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (dev);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);

  if (ctx == NULL)
    return;

  ctx->last_framework_state = state;

  if (state == FPI_IMAGE_DEVICE_STATE_AWAIT_FINGER_ON)
    goodix_device_context_maybe_rearm (ctx);
}

static void
goodix_device_context_record_capture_result (GoodixDeviceContext *ctx,
                                             gboolean             success,
                                             gboolean             match)
{
  if (!goodix_fpimage_device_is_production_usb (ctx->device) || ctx->login_series)
    return;

  ctx->production_capture_terminal |= !success || match;
  g_message ("GOODIX_STOCK_CAPTURE_RESULT attempt=%u outcome=%s terminal=%u",
             ctx->production_capture_attempt_count,
             !success ? "ERROR" : match ? "MATCH" : "NO_MATCH",
             ctx->production_capture_terminal);
}

static void
goodix_fpimage_device_identify_result (FpImageDevice *dev,
                                       gboolean       success,
                                       gboolean       match)
{
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (
    GOODIX_FPIMAGE_DEVICE (dev));

  if (ctx == NULL || ctx->production_action != FPI_DEVICE_ACTION_IDENTIFY)
    return;
  /* STOP/finger-off may drain before asynchronous host gallery matching
   * completes.  Keep identify_result: the adapter cannot safely decide
   * reopen versus poison/handoff from device-side drain ordering alone. */
  ctx->production_identify_result_known = TRUE;
  ctx->production_identify_result_success = success;
  ctx->production_identify_result_match = match;
  goodix_device_context_record_capture_result (ctx, success, match);
  login_maybe_report_release (ctx);
  if (ctx->deactivation_pending && !ctx->deactivation_held &&
      goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
    goodix_device_context_complete_deactivation (ctx);
}

static void
goodix_fpimage_device_verify_result (FpImageDevice *dev,
                                     gboolean       success,
                                     gboolean       match)
{
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (
    GOODIX_FPIMAGE_DEVICE (dev));

  if (ctx == NULL || ctx->production_action != FPI_DEVICE_ACTION_VERIFY)
    return;
  /* STOP/finger-off may drain before asynchronous host matching completes.
   * Keep the transport closed but not reusable until that outcome is known:
   * only a clean match/no-match may enable a later explicit client action. */
  ctx->production_verify_result_known = TRUE;
  ctx->production_verify_result_success = success;
  ctx->production_verify_result_match = match;
  goodix_device_context_record_capture_result (ctx, success, match);
  login_maybe_report_release (ctx);
  if (ctx->deactivation_pending && !ctx->deactivation_held &&
      goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
    goodix_device_context_complete_deactivation (ctx);
}

static void
goodix_fpimage_device_deactivate (FpImageDevice *dev)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (dev);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);

  g_assert (ctx != NULL);
#ifdef GOODIX_LIBFPRINT_CHICAGO
  goodix_chicago_enroll_clear (ctx->chicago);
#endif


  if (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING)
    return;

  if (ctx->terminal_enroll_completion_held)
    {
      ctx->terminal_enroll_completion_held = FALSE;
      ctx->terminal_enroll_completion_abort_count++;
    }

  goodix_device_context_set_state (ctx,
                                   GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING);
  ctx->deactivation_pending = TRUE;
  goodix_device_context_disconnect_cancel_handler (ctx);
  ctx->login_reusable = ctx->login_series && ctx->login_attempts < 3 &&
    !ctx->poisoned && !ctx->terminal_fence && ctx->release_tail_complete &&
    goodix_post_tls_lifecycle_get_phase (ctx->post_tls_lifecycle) == GOODIX_POST_TLS_PHASE_STOP &&
    !fpi_device_action_is_cancelled (FP_DEVICE (self)) &&
    ((ctx->production_action == FPI_DEVICE_ACTION_VERIFY &&
      ctx->production_verify_result_known && ctx->production_verify_result_success &&
      !ctx->production_verify_result_match) ||
     (ctx->production_action == FPI_DEVICE_ACTION_IDENTIFY &&
      ctx->production_identify_result_known && ctx->production_identify_result_success &&
      !ctx->production_identify_result_match));
  if (ctx->login_reusable)
    {
      /* The physical release and host NO MATCH are both complete. Keep the
       * drained TLS/session context; only another explicit action may arm. */
      if (goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
        goodix_device_context_complete_deactivation (ctx);
      return;
    }
  goodix_device_context_set_terminal_fence (ctx);
  ctx->backend_vtable->disarm (ctx, ctx->backend_user_data);

  /* Host callbacks are fenced, but arbitrary device-side quiescence remains
   * unproven.  Never advertise this cancellation path as safely inactive. */
  ctx->generation = 0;
  ctx->deactivation_nonquiescent =
    fpi_device_action_is_cancelled (FP_DEVICE (ctx->device));

  if (ctx->deactivation_pending && !ctx->deactivation_held &&
      goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
    goodix_device_context_complete_deactivation (ctx);
}

static void
goodix_fpimage_device_finalize (GObject *object)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (object);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);
  g_autoptr(GError) error = NULL;

  if (ctx != NULL && ctx->usb_interface_claimed)
    (void) goodix_fpimage_device_release_claim (self, &error);
  goodix_fpimage_device_discard_context (self);

  G_OBJECT_CLASS (goodix_fpimage_device_parent_class)->finalize (object);
}

/* Private paired-driver/fprintd interface. Not an FpDevice authentication
 * action: no framework activation or biometric callback before Verify. */
static gboolean
login_close_idle (gpointer data)
{
  goodix_fpimage_device_img_close (FP_IMAGE_DEVICE (data));
  return G_SOURCE_REMOVE;
}

static gboolean
login_deadline (gpointer data)
{
  GoodixDeviceContext *ctx = data;
  g_autoptr(GError) error = g_error_new_literal (
    G_IO_ERROR, G_IO_ERROR_TIMED_OUT, "Goodix login preparation expired; use password");
  ctx->login_deadline = 0;
  context_protocol_failure (ctx, error);
  return G_SOURCE_REMOVE;
}

static void
login_ready (GoodixPostTlsLifecycle *lifecycle, gpointer data)
{
  GoodixDeviceContext *ctx = data;
  (void) lifecycle;
  if (!ctx->login_preparing || ctx->terminal_fence)
    return;
  g_clear_handle_id (&ctx->login_deadline, g_source_remove);
  ctx->login_deadline = g_timeout_add_seconds (120, login_deadline, ctx);
  ctx->login_ready = TRUE;
  goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_ACTIVE);
  g_message ("GOODIX_LOGIN_READY generation=%" G_GUINT64_FORMAT
             " baseline20=1 first32_ack=1 capture22=0 lifetime_s=120", ctx->generation);
  g_signal_emit_by_name (ctx->device, "goodix-login-prepared", TRUE, "READY");
}

static gboolean
login_prepare (GoodixFpImageDevice *self)
{
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);
  g_autoptr(GError) error = NULL;
#ifdef GOODIX_LIBFPRINT_CHICAGO
  if (ctx && !ctx->chicago) ctx->chicago = goodix_chicago_new ();
#endif

  if (!goodix_fpimage_device_is_production_usb (self) || ctx == NULL ||
      fpi_device_get_current_action (FP_DEVICE (self)) != FPI_DEVICE_ACTION_NONE ||
      ctx->state != GOODIX_DEVICE_CONTEXT_STATE_INACTIVE || ctx->login_preparing ||
      ctx->production_action_consumed || ctx->poisoned ||
      !ctx->usb_interface_claimed || ctx->runtime_material == NULL)
    return FALSE;
  ctx->login_preparing = TRUE;
  ctx->generation = ++ctx->generation_seq;
  ctx->terminal_fence = FALSE;
  g_clear_object (&ctx->usb_cancellable);
  ctx->usb_cancellable = g_cancellable_new ();
  goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING);
  ctx->login_deadline = g_timeout_add_seconds (10, login_deadline, ctx);
  if (!goodix_fpi_usb_backend_begin_generation (
        ctx->fpi_usb_backend, ctx->generation, ctx->usb_cancellable, &error))
    {
      context_protocol_failure (ctx, error);
      return TRUE;
    }
  goodix_usb_router_begin_generation (ctx->usb_router, ctx->generation);
  if (!goodix_device_context_begin_pre_session_rx_sync (ctx, &error))
    context_protocol_failure (ctx, error);
  return TRUE;
}

#ifdef GOODIX_LIBFPRINT_CHICAGO
static FpiMatchResult
chicago_raw_match (FpImageDevice *dev, FpPrint *reference, FpPrint *probe, GError **error)
{
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (GOODIX_FPIMAGE_DEVICE (dev));
  return goodix_chicago_match (ctx ? ctx->chicago : NULL, reference, probe, error);
}
#endif

static void
goodix_fpimage_device_class_init (GoodixFpImageDeviceClass *klass)
{
  GObjectClass      *object_class = G_OBJECT_CLASS (klass);
  FpDeviceClass     *device_class = FP_DEVICE_CLASS (klass);
  FpImageDeviceClass *img_class   = FP_IMAGE_DEVICE_CLASS (klass);

  g_signal_new_class_handler ("goodix-login-prepare", G_TYPE_FROM_CLASS (klass),
                              G_SIGNAL_RUN_LAST, G_CALLBACK (login_prepare),
                              NULL, NULL, NULL, G_TYPE_BOOLEAN, 0);
  g_signal_new ("goodix-login-prepared", G_TYPE_FROM_CLASS (klass),
                G_SIGNAL_RUN_LAST, 0, NULL, NULL, NULL, G_TYPE_NONE, 2,
                G_TYPE_BOOLEAN, G_TYPE_STRING);


  object_class->finalize = goodix_fpimage_device_finalize;

#ifdef GOODIX_LIBFPRINT_CHICAGO
  device_class->id        = "goodix_27c6_5125_chicago_host_only";
#else
  device_class->id        = "goodix_27c6_5125_host_only";
#endif
  device_class->full_name = "Goodix 27c6:5125 host-only shell";
  device_class->type      = FP_DEVICE_TYPE_VIRTUAL;
  device_class->scan_type = FP_SCAN_TYPE_PRESS;
  device_class->nr_enroll_stages = GOODIX_BIOMETRIC_ENROLL_STAGES;

  img_class->img_open     = goodix_fpimage_device_img_open;
  img_class->img_close    = goodix_fpimage_device_img_close;
  img_class->activate     = goodix_fpimage_device_activate;
  img_class->change_state = goodix_fpimage_device_change_state;
  img_class->identify_result = goodix_fpimage_device_identify_result;
  img_class->verify_result = goodix_fpimage_device_verify_result;
  img_class->deactivate   = goodix_fpimage_device_deactivate;
  img_class->img_width    = (gint) GOODIX_CANONICAL_IMAGE_WIDTH;
  img_class->img_height   = (gint) GOODIX_CANONICAL_IMAGE_HEIGHT;
#ifdef GOODIX_LIBFPRINT_CHICAGO
  img_class->algorithm = FPI_DEVICE_ALGO_RAW;
  img_class->raw_match = chicago_raw_match;
#elif defined(GOODIX_LIBFPRINT_SIGFM) || \
    !defined(GOODIX_LIBFPRINT_1_94_100_NBIS)
  img_class->algorithm    = FPI_DEVICE_ALGO_SIGFM;
#endif

  fpi_device_class_auto_initialize_features (device_class);
#ifdef GOODIX_LIBFPRINT_CHICAGO
  /* No native learning or enrollment update in the Chicago RC. */
  device_class->features &= ~(guint) FP_DEVICE_FEATURE_UPDATE_PRINT;
#endif
}

static void
goodix_fpimage_device_init (GoodixFpImageDevice *self)
{
  GoodixDeviceContext *ctx = goodix_device_context_new (self);

  goodix_fpimage_device_set_context (self, ctx);
  goodix_device_context_set_state (ctx,
                                   GOODIX_DEVICE_CONTEXT_STATE_OPENING);
}

static void
goodix_usb_fpimage_device_class_init (GoodixUsbFpImageDeviceClass *klass)
{
  FpDeviceClass      *device_class = FP_DEVICE_CLASS (klass);
  FpImageDeviceClass *img_class   = FP_IMAGE_DEVICE_CLASS (klass);

  /* fp_device_set_property() consults the final instance class before
   * constructed() copies the transport type into private state. */
#ifdef GOODIX_LIBFPRINT_CHICAGO
  /* fprintd storage and fp_print_compatible() use this driver identity. Keep
   * historical SIGFM prints outside the Chicago gallery, without deleting or
   * converting them. A new Chicago enrollment is required for every finger. */
  device_class->id        = "goodix_27c6_5125_chicago";
#else
  device_class->id        = "goodix_27c6_5125";
#endif
  device_class->full_name = "Goodix 27c6:5125 Fingerprint Sensor";
  device_class->type      = FP_DEVICE_TYPE_USB;
  device_class->scan_type = FP_SCAN_TYPE_PRESS;
  device_class->id_table  = goodix_usb_id_table;

#ifdef GOODIX_PRODUCTION_FPRINTD_ACTION_PROFILE
  /* fprintd uses IDENTIFY with the complete gallery for multi-finger
   * VerifyStart("any") and as its duplicate pre-check before enrollment.
   * The driver advertises it only with the bounded lifecycle policy that
   * permits a clean no-match IDENTIFY -> fresh-resource ENROLL handoff. */
  device_class->features |= FP_DEVICE_FEATURE_IDENTIFY;
#endif

  /* Once an accepted image has been delivered, host-side processing failure
   * is terminal and must not become an implicit extra physical contact. */
  img_class->enroll_processing_fail_closed = TRUE;
}

static void
goodix_usb_fpimage_device_init (GoodixUsbFpImageDevice *self)
{
  (void) self;
}

/* Standard libfprint registry entry point.  The registered production type is
 * the USB-typed subclass; both it and the host-only constructor below reuse
 * the exact same GoodixDeviceContext implementation. */
GType
fpi_device_goodix_27c6_5125_get_type (void)
{
  return goodix_usb_fpimage_device_get_type ();
}

/* --- Host/test constructors and context access --- */

#ifdef GOODIX_ENABLE_TEST_SEAMS
GoodixFpImageDevice *
goodix_fpimage_device_new (void)
{
  return g_object_new (GOODIX_TYPE_FPIMAGE_DEVICE, NULL);
}

GoodixFpImageDevice *
goodix_fpimage_device_new_for_usb (GUsbDevice *usb_device)
{
  g_return_val_if_fail (usb_device != NULL, NULL);
  return g_object_new (GOODIX_TYPE_USB_FPIMAGE_DEVICE,
                       "fpi-usb-device", usb_device,
                       "fpi-driver-data", (guint64) 0,
                       NULL);
}

GoodixDeviceContext *
goodix_fpimage_device_get_context (GoodixFpImageDevice *dev)
{
  g_return_val_if_fail (GOODIX_IS_FPIMAGE_DEVICE (dev), NULL);
  return goodix_fpimage_device_peek_context (dev);
}

void
goodix_fpimage_device_set_production_open_seams (
  GoodixFpImageDevice               *dev,
  GoodixRuntimeCoordinatorAcquireSeam acquire_material,
  GoodixRuntimeCoordinatorReleaseSeam release_material,
  GoodixUsbInterfaceSeam             claim_interface,
  GoodixUsbInterfaceSeam             release_interface,
  gpointer                           user_data)
{
  GoodixFpImageDevicePrivate *priv;

  g_return_if_fail (GOODIX_IS_FPIMAGE_DEVICE (dev));
  g_return_if_fail (goodix_fpimage_device_is_production_usb (dev));
  g_return_if_fail ((acquire_material == NULL) ==
                    (release_material == NULL));
  g_return_if_fail ((claim_interface == NULL) ==
                    (release_interface == NULL));
  priv = goodix_fpimage_device_get_instance_private (dev);
  g_return_if_fail (priv->ctx == NULL ||
                    (priv->ctx->state == GOODIX_DEVICE_CONTEXT_STATE_OPENING &&
                     priv->ctx->runtime_material == NULL &&
                     !priv->ctx->usb_interface_claimed));
  priv->acquire_material = acquire_material;
  priv->release_material = release_material;
  priv->claim_interface = claim_interface;
  priv->release_interface = release_interface;
  priv->production_seam_data = user_data;
}

void
goodix_fpimage_device_test_set_production_state_override (
  const gchar *state_directory,
  const gchar *legacy_directory,
  guint uid,
  guint gid,
  const guint8 *pairing_psk)
{
  g_return_if_fail (state_directory != NULL && legacy_directory != NULL);
  g_free (goodix_test_production_state_directory);
  g_free (goodix_test_production_legacy_directory);
  goodix_test_production_state_directory = g_strdup (state_directory);
  goodix_test_production_legacy_directory = g_strdup (legacy_directory);
  goodix_test_production_state_uid = uid;
  goodix_test_production_state_gid = gid;
  goodix_test_production_pairing_psk_set = pairing_psk != NULL;
  if (pairing_psk != NULL)
    memcpy (goodix_test_production_pairing_psk, pairing_psk,
            sizeof goodix_test_production_pairing_psk);
  else
    memset (goodix_test_production_pairing_psk, 0,
            sizeof goodix_test_production_pairing_psk);
}

void
goodix_fpimage_device_test_clear_production_state_override (void)
{
  g_clear_pointer (&goodix_test_production_state_directory, g_free);
  g_clear_pointer (&goodix_test_production_legacy_directory, g_free);
  OPENSSL_cleanse (goodix_test_production_pairing_psk,
                   sizeof goodix_test_production_pairing_psk);
  goodix_test_production_pairing_psk_set = FALSE;
}

gboolean
goodix_device_context_has_runtime_material (GoodixDeviceContext *ctx)
{
  return ctx != NULL && ctx->runtime_material != NULL;
}

gboolean
goodix_device_context_has_usb_claim (GoodixDeviceContext *ctx)
{
  return ctx != NULL && ctx->usb_interface_claimed;
}

gboolean
goodix_device_context_runtime_handoff_views_cleared (GoodixDeviceContext *ctx)
{
  return ctx != NULL && ctx->runtime_handoff_views_cleared;
}

void
goodix_device_context_get_production_enrollment_audit (
  GoodixDeviceContext              *ctx,
  GoodixProductionEnrollmentAudit *audit)
{
  g_return_if_fail (ctx != NULL);
  g_return_if_fail (audit != NULL);

  goodix_device_context_collect_production_enrollment_audit (
    ctx, audit, ctx->production_verify_epoch_closed ||
                ctx->production_identify_epoch_closed);
}

void
goodix_fpimage_device_get_production_enrollment_audit (
  GoodixFpImageDevice             *dev,
  GoodixProductionEnrollmentAudit *audit)
{
  GoodixFpImageDevicePrivate *priv;

  g_return_if_fail (GOODIX_IS_FPIMAGE_DEVICE (dev));
  g_return_if_fail (audit != NULL);

  priv = goodix_fpimage_device_get_instance_private (dev);
  if (priv->ctx != NULL)
    {
      goodix_device_context_collect_production_enrollment_audit (
        priv->ctx, audit, priv->ctx->production_verify_epoch_closed ||
                          priv->ctx->production_identify_epoch_closed);
      return;
    }
  if (priv->last_production_audit_valid)
    {
      *audit = priv->last_production_audit;
      return;
    }
  *audit = (GoodixProductionEnrollmentAudit) { 0 };
}

gboolean
goodix_device_context_configure_tls (GoodixDeviceContext *ctx,
                                               const guint8 *psk,
                                               gsize psk_length,
                                               GoodixTlsPlaintextFunc plaintext,
                                               gpointer user_data,
                                               GoodixTlsAudit *audit,
                                               GError **error)
{
  g_return_val_if_fail (ctx != NULL && ctx->tls_server == NULL &&
                        ctx->secure_session == NULL, FALSE);
  ctx->tls_plaintext = plaintext;
  ctx->tls_user_data = user_data;
  ctx->tls_server = goodix_tls_server_new (psk, psk_length, context_tls_output,
                                           context_tls_plaintext, ctx, audit,
                                           error);
  return ctx->tls_server != NULL;
}
#endif

static void
context_secure_terminal (GoodixSecureSession *session,
                         const GError        *error,
                         gpointer             user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) session;
  context_protocol_failure (ctx, error);
}

#ifdef GOODIX_LIBFPRINT_CHICAGO


static gboolean
context_chicago_image (GoodixDeviceContext *ctx, GoodixEnrollmentPipeline *pipeline,
                     const uint16_t *samples, gsize count, GError **error)
{
  GoodixChicagoSample sample;
  g_autoptr(GoodixChicagoBytes) bytes = NULL;
  FpPrint *print = NULL;
  guint progress = 0;
  FpiDeviceAction action = fpi_device_get_current_action (FP_DEVICE (ctx->device));
  if (goodix_device_context_is_stale_or_fenced (ctx) ||
      fpi_device_action_is_cancelled (FP_DEVICE (ctx->device)))
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CANCELLED, "Chicago callback fenced or cancelled");
      return FALSE;
    }
  gboolean preprocessed = goodix_chicago_native_preprocess (ctx->chicago, samples, count, ctx->generation, &sample, error);
  if (!preprocessed)
    {
      if (!error || !*error || (*error)->domain != FP_DEVICE_RETRY) return FALSE;
      if (action == FPI_DEVICE_ACTION_ENROLL)
        {
          g_clear_error (error);
          if (pipeline && !goodix_enrollment_pipeline_retry_current_stage (pipeline, error)) return FALSE;
          fpi_image_device_retry_scan (FP_IMAGE_DEVICE (ctx->device), FP_DEVICE_RETRY_GENERAL);
        }
      else
        fpi_image_device_raw_image_captured (FP_IMAGE_DEVICE (ctx->device), NULL, NULL, 0, g_steal_pointer (error));
      return TRUE;
    }
  if (action == FPI_DEVICE_ACTION_ENROLL)
    {
      GoodixChicagoAdmission result = goodix_chicago_enroll (ctx->chicago, &sample, &bytes, error);
      if (result == GOODIX_CHICAGO_ERROR) { goodix_chicago_sample_clear (&sample); return FALSE; }
      if (result == GOODIX_CHICAGO_RETRY)
        {
          if (pipeline && !goodix_enrollment_pipeline_retry_current_stage (pipeline, error))
            { goodix_chicago_sample_clear (&sample); return FALSE; }
          fpi_image_device_retry_scan (FP_IMAGE_DEVICE (ctx->device),
              FP_DEVICE_RETRY_GENERAL);
          goodix_chicago_sample_clear (&sample);
          return TRUE;
        }
      progress = goodix_chicago_enroll_progress (ctx->chicago);
      if (result == GOODIX_CHICAGO_COMPLETE)
        {
          if (pipeline && !goodix_enrollment_pipeline_finish_current_stage (pipeline, error))
            { goodix_chicago_sample_clear (&sample); return FALSE; }
          print = goodix_chicago_template_print (ctx->chicago, FP_DEVICE (ctx->device), bytes);
          if (ctx->terminal_delivery_at_release_ready)
            {
              fpi_image_device_hold_enroll_completion (FP_IMAGE_DEVICE (ctx->device));
              ctx->terminal_enroll_completion_held = TRUE;
              ctx->terminal_enroll_completion_hold_count++;
            }
        }
    }
  else if (action != FPI_DEVICE_ACTION_CAPTURE)
    print = goodix_chicago_probe_print (FP_DEVICE (ctx->device), &sample);
  fpi_image_device_raw_image_captured (FP_IMAGE_DEVICE (ctx->device),
      goodix_chicago_sample_image (&sample), print, (gint) progress, NULL);
  goodix_chicago_sample_clear (&sample);
  /* Native completion can synchronously begin normal/cancel deactivation. */
  return !ctx->poisoned;
}
#endif

#ifdef GOODIX_LIBFPRINT_CHICAGO
static gboolean
context_chicago_session_background (GoodixDeviceContext *ctx, GoodixPostTlsLifecycle *lifecycle,
                                   guint64 generation, GError **error)
{
  guint16 background[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT] = { 0 };
  gboolean ok;
  if (!ctx->chicago) return FALSE;
  /* copy_baseline becomes valid only from a successfully decoded FDT_B0 after
   * the existing no-finger command 0x20, before first finger acquisition. */
  if (ctx->terminal_fence || !lifecycle || lifecycle != ctx->post_tls_lifecycle ||
      !generation || generation != ctx->generation ||
      ctx->runtime_post_tls_audit.baseline_b0_count != 1 ||
      ctx->runtime_post_tls_audit.baseline_decode_count != 1 ||
      !goodix_post_tls_lifecycle_copy_baseline (lifecycle, background))
    {
      goodix_chicago_clear_binding (ctx->chicago);
      OPENSSL_cleanse (background, sizeof background);
      g_set_error_literal (error, FP_DEVICE_ERROR, FP_DEVICE_ERROR_DATA_INVALID,
                           "Chicago no current decoded no-finger background provenance");
      return FALSE;
    }
  ok = goodix_chicago_native_background (ctx->chicago, background, G_N_ELEMENTS (background), 80, 64, generation, error);
  OPENSSL_cleanse (background, sizeof background);
  return ok;
}
#ifdef GOODIX_ENABLE_TEST_SEAMS
gboolean
goodix_device_context_test_chicago_prepare (GoodixDeviceContext *ctx, const guint8 otp[64],
                                           const guint16 background[5120], GError **error)
{
  if (!ctx || goodix_fpimage_device_is_production_usb (ctx->device) || !ctx->chicago)
    return FALSE;
  return goodix_chicago_bind_preflight (ctx->chicago, otp, 64, ctx->generation, error) &&
    goodix_chicago_native_background (ctx->chicago, background, 5120, 80, 64, ctx->generation, error);
}
gboolean
goodix_device_context_test_chicago_native_source_guard (GoodixDeviceContext *ctx, GError **error)
{ return context_chicago_session_background (ctx, NULL, ctx->generation, error); }
#endif
#endif

static gboolean
context_post_tls_image (GoodixPostTlsLifecycle *lifecycle,
                        guint                   acquisition_index,
                        const uint16_t          samples[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT],
                        gpointer                user_data,
                        GError                **error)
{
  GoodixDeviceContext *ctx = user_data;

  (void) lifecycle;
  (void) acquisition_index;
  if (ctx->operator_epoch)
    {
      GoodixFpImagePipeline *pipeline = NULL;
      GoodixFpImagePipelineResult result;

      result = goodix_fpimage_pipeline_new (
        samples, GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT, &pipeline);
      if (result != GOODIX_FPIMAGE_PIPELINE_OK)
        {
          g_set_error (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                       "FpImage pipeline failed with result %u", result);
          return FALSE;
        }
      goodix_fpimage_pipeline_free (pipeline);
      return TRUE;
    }
#ifdef GOODIX_LIBFPRINT_CHICAGO
  if (!context_chicago_session_background (ctx, lifecycle, ctx->generation, error)) return FALSE;
  return context_chicago_image (ctx, NULL, samples, GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT, error);
#elif defined(GOODIX_LIBFPRINT_SIGFM)
  {
    uint16_t session_baseline[GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT];
    GoodixFpImagePipeline *pipeline = NULL;
    GoodixFpImagePipelineResult result;
    FpImage *image;

    if (!goodix_post_tls_lifecycle_copy_baseline (lifecycle,
                                                  session_baseline))
      {
        g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
                             "SIGFM capture has no session baseline");
        return FALSE;
      }
    if (!ctx->sigfm_baseline_valid)
      {
        memcpy (ctx->sigfm_baseline, session_baseline,
                sizeof ctx->sigfm_baseline);
        ctx->sigfm_baseline_valid = TRUE;
        ctx->sigfm_baseline_pinned_this_epoch = TRUE;
      }
    else
      ctx->sigfm_baseline_reused_this_epoch = TRUE;
    result = goodix_fpimage_pipeline_new_sigfm (
      ctx->sigfm_baseline, G_N_ELEMENTS (ctx->sigfm_baseline), samples,
      GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT, &pipeline);
    OPENSSL_cleanse (session_baseline, sizeof session_baseline);
    if (result != GOODIX_FPIMAGE_PIPELINE_OK)
      {
        g_set_error (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                     "SIGFM FpImage pipeline failed with result %u", result);
        return FALSE;
      }
    image = goodix_fpimage_pipeline_get_image (pipeline);
    fpi_image_device_image_captured (FP_IMAGE_DEVICE (ctx->device),
                                     g_object_ref (image));
    goodix_fpimage_pipeline_free (pipeline);
  }
#else
  goodix_device_context_emit_image_ready (
    ctx, samples, GOODIX_CANONICAL_IMAGE_SAMPLE_COUNT);
#endif
  if (ctx->terminal_fence)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                           "FpImage pipeline or framework delivery failed");
      return FALSE;
    }
  return TRUE;
}

static void
context_post_tls_finger_down (GoodixPostTlsLifecycle *lifecycle,
                              gpointer                user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) lifecycle;
  if (!ctx->operator_epoch)
    goodix_device_context_emit_finger_down (ctx);
}

static void
context_post_tls_release_tail (GoodixPostTlsLifecycle *lifecycle,
                               gpointer                user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) lifecycle;
  ctx->fresh_down_table = TRUE;
  if (ctx->operator_epoch)
    ctx->release_tail_complete = TRUE;
  else
    goodix_device_context_emit_release_tail_complete (ctx);
}

static void
context_post_tls_finger_up (GoodixPostTlsLifecycle *lifecycle,
                            gpointer                user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) lifecycle;
  if (ctx->login_series)
    login_maybe_report_release (ctx);
  else if (!ctx->operator_epoch)
    goodix_device_context_emit_finger_up_ready (ctx);
}

static void
login_maybe_report_release (GoodixDeviceContext *ctx)
{
  if (ctx->login_series && ctx->release_tail_complete &&
      ctx->state == GOODIX_DEVICE_CONTEXT_STATE_ACTIVE &&
      ((ctx->production_action == FPI_DEVICE_ACTION_VERIFY && ctx->production_verify_result_known) ||
       (ctx->production_action == FPI_DEVICE_ACTION_IDENTIFY && ctx->production_identify_result_known)))
    goodix_device_context_emit_finger_up_ready (ctx);
}

static void
context_post_tls_terminal (GoodixPostTlsLifecycle *lifecycle,
                           const GError           *error,
                           gpointer                user_data)
{
  GoodixDeviceContext *ctx = user_data;

  (void) lifecycle;
  context_protocol_failure (ctx, error);
}

static void
context_post_tls_plaintext (GBytes   *bytes,
                            gpointer  user_data)
{
  GoodixDeviceContext *ctx = user_data;

  if (ctx->terminal_fence)
    return;
  if (ctx->enrollment_binding != NULL)
    {
      g_autoptr(GError) error = NULL;

      if (!goodix_enrollment_fpi_usb_binding_handle_plaintext_chunk (
            ctx->enrollment_binding, bytes, &error))
        context_protocol_failure (ctx, error);
    }
  else if (ctx->post_tls_lifecycle != NULL)
    goodix_post_tls_lifecycle_handle_plaintext (ctx->post_tls_lifecycle, bytes);
}

static gboolean
context_enrollment_image (GoodixEnrollmentPipeline *pipeline,
                          guint                     stage_index,
                          FpImage                  *image,
                          gpointer                  user_data,
                          GError                  **error)
{
  GoodixDeviceContext *ctx = user_data;

  (void) pipeline;
  if (ctx->terminal_fence || image == NULL)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "enrollment image reached a fenced context");
      return FALSE;
    }
  if (!ctx->operator_epoch)
    {
#ifdef GOODIX_LIBFPRINT_CHICAGO
      size_t count = 0;
      const uint16_t *samples = goodix_enrollment_pipeline_get_pending_source_samples (pipeline, &count);
      (void) stage_index;
      return context_chicago_image (ctx, pipeline, samples, count, error);
#elif defined(GOODIX_LIBFPRINT_SIGFM)
      GoodixFpImagePipeline *sigfm_pipeline = NULL;
      GoodixFpImagePipelineResult result;
      GoodixEnrollmentDiversityDecision diversity_decision;
      GoodixEnrollmentDiversityObservation diversity_observation;
      GoodixEnrollmentSampleMetrics enrollment_metrics = { 0 };
      GoodixSigfmEnrollmentMetrics sigfm_metrics = { 0 };
      GoodixSigfmSample *metric_sample = NULL;
      GoodixSigfmResult sigfm_result;
      guint template_stage_target;
      int keypoints = 0;
      const guchar *image_data;
      gsize image_data_length = 0u;
      const uint16_t *samples;
      size_t sample_count = 0u;

      samples = goodix_enrollment_pipeline_get_pending_source_samples (
        pipeline, &sample_count);
      if (!ctx->sigfm_baseline_valid || samples == NULL)
        {
          g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
                               "SIGFM enrollment image lacks baseline or source raster");
          return FALSE;
        }
      result = goodix_fpimage_pipeline_new_sigfm (
        ctx->sigfm_baseline, G_N_ELEMENTS (ctx->sigfm_baseline),
        samples, sample_count, &sigfm_pipeline);
      if (result != GOODIX_FPIMAGE_PIPELINE_OK)
        {
          g_set_error (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                       "SIGFM enrollment preprocessing failed: %u", result);
          return FALSE;
        }
      if (ctx->enrollment_diversity == NULL)
        {
          goodix_fpimage_pipeline_free (sigfm_pipeline);
          g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
                               "SIGFM enrollment diversity state is absent");
          return FALSE;
        }
      image_data = fp_image_get_data (
        goodix_fpimage_pipeline_get_image (sigfm_pipeline),
        &image_data_length);
      /* Keep the policy local: obtain only keypoint count and an 8x8 spatial
       * coverage mask. Libfprint still owns the later asynchronous extraction
       * that creates the stored sample; no template or matcher format changes. */
      sigfm_result = goodix_sigfm_extract_pixels (
        image_data, image_data_length, &metric_sample, &keypoints);
      if (sigfm_result == GOODIX_SIGFM_OK)
        {
          sigfm_result = goodix_sigfm_sample_enrollment_metrics (
            metric_sample, &sigfm_metrics);
          goodix_sigfm_sample_free (metric_sample);
          metric_sample = NULL;
          if (sigfm_result != GOODIX_SIGFM_OK)
            {
              goodix_fpimage_pipeline_free (sigfm_pipeline);
              g_set_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
                           "SIGFM enrollment metrics failed: %u",
                           sigfm_result);
              return FALSE;
            }
          enrollment_metrics.sigfm_keypoints = sigfm_metrics.keypoints;
          enrollment_metrics.sigfm_coverage_mask =
            sigfm_metrics.coverage_mask;
        }
      else if (sigfm_result != GOODIX_SIGFM_KEYPOINT_GATE_FAILED)
        {
          goodix_fpimage_pipeline_free (sigfm_pipeline);
          g_set_error (error, G_IO_ERROR, G_IO_ERROR_FAILED,
                       "SIGFM enrollment precheck failed: %u", sigfm_result);
          return FALSE;
        }
      diversity_decision = goodix_enrollment_diversity_observe (
        ctx->enrollment_diversity, image_data, image_data_length,
        &enrollment_metrics);
      goodix_enrollment_diversity_get_last_observation (
        ctx->enrollment_diversity, &diversity_observation);
      g_message (
        "GOODIX_ENROLLMENT_POLICY_AUDIT contact=%u accepted=%u decision=%u keypoints=%u coverage_cells=%u aggregate_cells=%u raster_range=%u raster_contrast=%u nearest_mad=%u nearest_coverage=%u",
        diversity_observation.physical_attempt_count,
        diversity_observation.accepted_sample_count,
        diversity_observation.decision,
        diversity_observation.sigfm_keypoints,
        diversity_observation.sigfm_coverage_cells,
        diversity_observation.aggregate_coverage_cells,
        diversity_observation.raster_range,
        diversity_observation.raster_contrast,
        diversity_observation.nearest_mad,
        diversity_observation.nearest_coverage_percent);
      if (diversity_decision == GOODIX_ENROLLMENT_DIVERSITY_RETRY_POOR)
        {
          if (!goodix_enrollment_pipeline_retry_current_stage (pipeline,
                                                                error))
            {
              goodix_fpimage_pipeline_free (sigfm_pipeline);
              return FALSE;
            }
          g_debug ("enrollment contact %u rejected as poor sample; retry",
                   stage_index);
          fpi_image_device_retry_scan (FP_IMAGE_DEVICE (ctx->device),
                                       FP_DEVICE_RETRY_GENERAL);
          goodix_fpimage_pipeline_free (sigfm_pipeline);
          return TRUE;
        }
      if (diversity_decision == GOODIX_ENROLLMENT_DIVERSITY_FAILED)
        {
          goodix_fpimage_pipeline_free (sigfm_pipeline);
          g_set_error_literal (
            error, G_IO_ERROR, G_IO_ERROR_FAILED,
            "SIGFM enrollment fixed-21 policy failed; no physical-contact bound exists");
          return FALSE;
        }
      if (diversity_decision ==
          GOODIX_ENROLLMENT_DIVERSITY_ACCEPT_TERMINAL)
        {
          template_stage_target =
            goodix_enrollment_diversity_get_template_stage_target (
              ctx->enrollment_diversity);
          if (template_stage_target == 0u ||
              template_stage_target > (guint) G_MAXINT)
            {
              goodix_fpimage_pipeline_free (sigfm_pipeline);
              g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
                                   "SIGFM enrollment stage target must be in 1..G_MAXINT");
              return FALSE;
            }
          if (!goodix_enrollment_pipeline_finish_current_stage (pipeline,
                                                                 error))
            {
              goodix_fpimage_pipeline_free (sigfm_pipeline);
              return FALSE;
            }
          fpi_device_set_nr_enroll_stages (FP_DEVICE (ctx->device),
                                           (gint) template_stage_target);
          if (ctx->terminal_delivery_at_release_ready)
            {
              fpi_image_device_hold_enroll_completion (
                FP_IMAGE_DEVICE (ctx->device));
              ctx->terminal_enroll_completion_held = TRUE;
              ctx->terminal_enroll_completion_hold_count++;
            }
          g_debug ("enrollment diversity complete after %u contacts with %u template stages",
                   goodix_enrollment_diversity_get_physical_attempt_count (
                     ctx->enrollment_diversity),
                   template_stage_target);
        }
      fpi_image_device_image_captured (
        FP_IMAGE_DEVICE (ctx->device),
        g_object_ref (goodix_fpimage_pipeline_get_image (sigfm_pipeline)));
      goodix_fpimage_pipeline_free (sigfm_pipeline);
#else
      if (stage_index == GOODIX_SIGFM_ENROLL_REQUIRED_STAGES &&
          ctx->terminal_delivery_at_release_ready)
        {
          fpi_image_device_hold_enroll_completion (
            FP_IMAGE_DEVICE (ctx->device));
          ctx->terminal_enroll_completion_held = TRUE;
          ctx->terminal_enroll_completion_hold_count++;
        }
      fpi_image_device_image_captured (FP_IMAGE_DEVICE (ctx->device),
                                       g_object_ref (image));
#endif
    }
  return !ctx->terminal_fence;
}

static gboolean
context_enrollment_timestamp (guint                           stage_index,
                              GoodixEnrollmentCommandPurpose  purpose,
                              guint16                        *timestamp,
                              gpointer                        user_data,
                              GError                        **error)
{
  GoodixDeviceContext *ctx = user_data;

  (void) stage_index;
  (void) purpose;
  if (ctx->terminal_fence || timestamp == NULL)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "enrollment timestamp reached a fenced context");
      return FALSE;
    }
  *timestamp = production_timestamp ();
  return TRUE;
}

static gboolean
context_enrollment_auxiliary (GBytes   *plaintext,
                              gpointer  user_data,
                              GError  **error)
{
  GoodixDeviceContext *ctx = user_data;

  if (ctx->terminal_fence || ctx->enrollment_auxiliary == NULL)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "auxiliary enrollment B0 has no active consumer");
      return FALSE;
    }
  return ctx->enrollment_auxiliary (
    plaintext, ctx->enrollment_auxiliary_data, error);
}

static gboolean
context_enrollment_contact (guint      stage_index,
                            gboolean   present,
                            gpointer   user_data,
                            GError   **error)
{
  GoodixDeviceContext *ctx = user_data;

  (void) stage_index;
  if (ctx->terminal_fence)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "enrollment contact reached a fenced context");
      return FALSE;
    }
  if (present)
    {
      if (!ctx->operator_epoch)
        goodix_device_context_emit_finger_down (ctx);
    }
  else
    {
      ctx->fresh_down_table = TRUE;
      ctx->release_tail_complete = TRUE;
      if (!ctx->operator_epoch)
        goodix_device_context_emit_finger_up_ready (ctx);
    }
  return !ctx->terminal_fence;
}

static gboolean
context_enrollment_ready (GoodixEnrollmentFpiUsbBinding *binding,
                          gpointer                       user_data,
                          GError                       **error)
{
  GoodixDeviceContext *ctx = user_data;

  if (ctx->terminal_fence || binding != ctx->enrollment_binding ||
      !goodix_enrollment_fpi_usb_binding_needs_receive (binding))
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "enrollment receive continuation is not current");
      return FALSE;
    }
  if (goodix_fpi_usb_backend_get_outstanding (ctx->fpi_usb_backend) != 0u)
    return TRUE;
  return goodix_device_context_arm_receive (ctx, error);
}

static void
context_enrollment_failed (const GError *error, gpointer user_data)
{
  context_protocol_failure (user_data, error);
}

static gboolean
context_enrollment_first_arm_handoff (GoodixPostTlsLifecycle *lifecycle,
                                      GoodixFpiUsbBackend    *backend,
                                      guint64                 generation,
                                      gpointer                user_data,
                                      GError                **error)
{
  GoodixDeviceContext *ctx = user_data;
  GoodixEnrollmentFpiUsbBinding *binding;

  if (ctx->terminal_fence || lifecycle != ctx->post_tls_lifecycle ||
      backend != ctx->fpi_usb_backend || generation != ctx->generation ||
      ctx->pending_enrollment_events == NULL ||
      ctx->enrollment_binding != NULL ||
      !goodix_fpi_usb_backend_is_drained (backend))
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "enrollment first-arm handoff preconditions failed");
      return FALSE;
    }
  if (ctx->runtime_coordinator_audit.zero_fdt_seed)
    {
      guint8 learned_fdt[GOODIX_POST_TLS_FDT_TABLE_LENGTH] = { 0 };
      g_autofree gchar *digest = NULL;

      if (!goodix_post_tls_lifecycle_copy_learned_fdt (lifecycle,
                                                        learned_fdt))
        {
          g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
                               "zero-seed lifecycle has no learned FDT table");
          return FALSE;
        }
      digest = g_compute_checksum_for_data (G_CHECKSUM_SHA256, learned_fdt,
                                             sizeof learned_fdt);
      g_message ("GOODIX_ZERO_SEED_FDT_READY samples=%u learned=1 "
                 "fdt_sha256=%s pairing_writes=%u",
                 ctx->runtime_post_tls_audit.fdt_irq100_count,
                 digest,
                 ctx->runtime_coordinator_audit.pairing_write_count);
      OPENSSL_cleanse (learned_fdt, sizeof learned_fdt);
    }
#ifdef GOODIX_LIBFPRINT_CHICAGO
  if (!context_chicago_session_background (ctx, lifecycle, generation, error)) return FALSE;
#endif
#ifdef GOODIX_LIBFPRINT_SIGFM
  if (!goodix_post_tls_lifecycle_copy_baseline (
        lifecycle, ctx->sigfm_baseline))
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA,
                           "enrollment handoff has no decoded SIGFM baseline");
      return FALSE;
    }
  ctx->sigfm_baseline_valid = TRUE;
  ctx->sigfm_baseline_pinned_this_epoch = TRUE;
#endif
  binding = goodix_enrollment_fpi_usb_binding_new (
    ctx->pending_enrollment_events, backend, generation,
    ctx->enrollment_binding_audit, error);
  if (binding == NULL)
    return FALSE;
  ctx->pending_enrollment_events = NULL;
  ctx->enrollment_binding = binding;
  goodix_enrollment_fpi_usb_binding_set_error_callback (binding, context_enrollment_failed, ctx);
  return goodix_enrollment_fpi_usb_binding_set_ready_callback (
    binding, context_enrollment_ready, ctx, error);
}

static void
context_secure_phase (GoodixSecureSession *session,
                      GoodixSecurePhase    phase,
                      guint64              generation,
                      gpointer             user_data)
{
  GoodixDeviceContext *ctx = user_data;
  g_autoptr(GError) error = NULL;

  if (generation == ctx->generation && ctx->phase_observer != NULL)
    ctx->phase_observer (phase, generation, ctx->phase_observer_data);
  if (phase != GOODIX_SECURE_PHASE_STOP || generation != ctx->generation ||
      ctx->terminal_fence || ctx->post_tls_lifecycle == NULL)
    return;
  if (ctx->pairing_activation != NULL)
    {
      if (!goodix_pairing_activation_mark_tls_and_promote (
            ctx->pairing_activation, &error))
        {
          context_protocol_failure (ctx, error);
          return;
        }
    }
  else if (ctx->runtime_material != NULL &&
           ctx->runtime_coordinator_audit.decision ==
             GOODIX_RUNTIME_COORDINATOR_DECISION_READY_RETRY_TLS)
    {
      if (!goodix_runtime_coordinator_promote_after_tls (
            ctx->runtime_material, &error))
        {
          context_protocol_failure (ctx, error);
          return;
        }
      ctx->runtime_coordinator_audit.decision =
        GOODIX_RUNTIME_COORDINATOR_DECISION_READY_ACTIVE;
    }
  goodix_secure_session_set_post_tls_plaintext_callback (
    session, context_post_tls_plaintext, ctx);
  if (!goodix_secure_session_handoff_backend (session, &error) ||
      !goodix_post_tls_lifecycle_start (ctx->post_tls_lifecycle, &error))
    context_protocol_failure (ctx, error);
}

gboolean
goodix_device_context_configure_post_tls_lifecycle (
  GoodixDeviceContext         *ctx,
  const GoodixPostTlsMaterial *material,
  GoodixPostTlsAudit          *audit,
  GError                     **error)
{
  if (ctx == NULL || material == NULL || ctx->generation == 0 ||
      ctx->terminal_fence || ctx->post_tls_lifecycle != NULL ||
      ctx->secure_session != NULL)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "GoodixDeviceContext cannot configure post-TLS lifecycle");
      return FALSE;
    }
  ctx->post_tls_lifecycle = goodix_post_tls_lifecycle_new (
    ctx->fpi_usb_backend, ctx->generation, material, context_post_tls_image,
    context_post_tls_finger_down, context_post_tls_release_tail,
    context_post_tls_finger_up, context_post_tls_terminal, ctx, audit, error);
  if (ctx->post_tls_lifecycle != NULL && ctx->login_preparing)
    goodix_post_tls_lifecycle_prepare_login (ctx->post_tls_lifecycle, login_ready);
  return ctx->post_tls_lifecycle != NULL;
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
gboolean
goodix_device_context_test_login_post_tls (GoodixDeviceContext *ctx,
  const GoodixPostTlsMaterial *material, GoodixPostTlsAudit *audit, GError **error)
{
  g_return_val_if_fail (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_INACTIVE, FALSE);
  ctx->login_preparing = TRUE;
  ctx->generation = ++ctx->generation_seq;
  g_clear_object (&ctx->usb_cancellable);
  ctx->usb_cancellable = g_cancellable_new ();
  if (!goodix_fpi_usb_backend_begin_generation (ctx->fpi_usb_backend,
       ctx->generation, ctx->usb_cancellable, error))
    return FALSE;
  goodix_usb_router_begin_generation (ctx->usb_router, ctx->generation);
  goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING);
  return goodix_device_context_configure_post_tls_lifecycle (ctx, material, audit, error) &&
         goodix_post_tls_lifecycle_start (ctx->post_tls_lifecycle, error);
}
#endif

gboolean
goodix_device_context_configure_enrollment_graph (
  GoodixDeviceContext                *ctx,
  const GoodixEnrollmentModelConfig  *config,
  GoodixEnrollmentAuxiliaryB0Func     auxiliary_ready,
  gpointer                            auxiliary_data,
  GoodixEnrollmentPostTlsEventsAudit *events_audit,
  GoodixEnrollmentFpiUsbBindingAudit *binding_audit,
  GError                            **error)
{
  GoodixEnrollmentPostTlsEvents *events;

  if (ctx == NULL || config == NULL || auxiliary_ready == NULL ||
      ctx->generation == 0u || ctx->terminal_fence ||
      ctx->post_tls_lifecycle == NULL ||
      goodix_post_tls_lifecycle_get_phase (ctx->post_tls_lifecycle) !=
        GOODIX_POST_TLS_PHASE_NOT_STARTED ||
      ctx->secure_session != NULL || ctx->pending_enrollment_events != NULL ||
      ctx->enrollment_binding != NULL)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "GoodixDeviceContext cannot configure enrollment graph");
      return FALSE;
    }
  events = goodix_enrollment_post_tls_events_new (
    config, context_enrollment_image, context_enrollment_timestamp,
    context_enrollment_auxiliary, ctx, events_audit, error);
  if (events == NULL)
    return FALSE;
  if (!goodix_enrollment_post_tls_events_set_contact_callback (
        events, context_enrollment_contact, ctx, error) ||
      !goodix_post_tls_lifecycle_set_first_arm_handoff (
        ctx->post_tls_lifecycle, context_enrollment_first_arm_handoff, error))
    {
      goodix_enrollment_post_tls_events_free (events);
      return FALSE;
    }
  ctx->pending_enrollment_events = events;
  if (!ctx->operator_epoch &&
      fpi_device_get_current_action (FP_DEVICE (ctx->device)) == FPI_DEVICE_ACTION_ENROLL)
    goodix_enrollment_post_tls_events_enable_zero_recovery (events);
  ctx->terminal_delivery_at_release_ready =
    config->defer_terminal_stage_delivery_until_release_ready;
  ctx->enrollment_auxiliary = auxiliary_ready;
  ctx->enrollment_auxiliary_data = auxiliary_data;
  ctx->enrollment_binding_audit = binding_audit;
  return TRUE;
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
gboolean
goodix_device_context_has_pending_enrollment_graph (GoodixDeviceContext *ctx)
{
  return ctx != NULL && ctx->pending_enrollment_events != NULL;
}
#endif

gboolean
goodix_device_context_start_secure_session (
  GoodixDeviceContext               *ctx,
  const GoodixSecureSessionMaterial *material,
  GoodixSecureSessionScheduleFunc    schedule,
  gpointer                           schedule_data,
  GoodixSecureSessionAudit          *audit,
  GoodixTlsAudit                    *tls_audit,
  GError                           **error)
{
  if (ctx == NULL || ctx->secure_session != NULL || ctx->tls_server != NULL ||
      ctx->generation == 0 || ctx->terminal_fence ||
      ((ctx->operator_epoch ||
        goodix_fpimage_device_is_production_usb (ctx->device)) &&
       ctx->pre_session_rx_sync_audit.pre_session_rx_result !=
         GOODIX_PRE_SESSION_RX_SYNC_PASS))
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "GoodixDeviceContext cannot start secure session");
      return FALSE;
    }
  ctx->secure_session = goodix_secure_session_new (
    ctx->fpi_usb_backend, ctx->generation, material, schedule, schedule_data,
    context_secure_terminal, ctx, audit, tls_audit, error);
  if (ctx->secure_session == NULL)
    return FALSE;
  if (ctx->post_tls_lifecycle != NULL)
    goodix_secure_session_set_phase_callback (ctx->secure_session,
                                              context_secure_phase, ctx);
  if (!goodix_secure_session_start (ctx->secure_session, error) ||
      !goodix_device_context_arm_receive (ctx, error))
    {
      goodix_secure_session_cancel (ctx->secure_session,
                                    "secure-session start/receive failed");
      return FALSE;
    }
  return TRUE;
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
GoodixSecureSession *
goodix_device_context_get_secure_session (GoodixDeviceContext *ctx)
{
  return ctx != NULL ? ctx->secure_session : NULL;
}

GoodixPostTlsLifecycle *
goodix_device_context_get_post_tls_lifecycle (GoodixDeviceContext *ctx)
{
  return ctx != NULL ? ctx->post_tls_lifecycle : NULL;
}
#endif

#ifdef GOODIX_ENABLE_TEST_SEAMS
void
goodix_device_context_set_usb_submit_seam (GoodixDeviceContext *ctx,
                                            GoodixUsbSubmitSeam seam,
                                            gpointer user_data)
{
  g_return_if_fail (ctx != NULL);
  goodix_fpi_usb_backend_set_submit_seam (ctx->fpi_usb_backend, seam, user_data);
}

void
goodix_device_context_set_async_usb_submit_seam (GoodixDeviceContext *ctx,
                                                  GoodixUsbSubmitSeam seam,
                                                  gpointer user_data)
{
  g_return_if_fail (ctx != NULL);
  goodix_fpi_usb_backend_set_async_submit_seam (ctx->fpi_usb_backend, seam,
                                                user_data);
}
#endif

gboolean
goodix_device_context_arm_receive (GoodixDeviceContext *ctx, GError **error)
{
  g_return_val_if_fail (ctx != NULL, FALSE);
  return goodix_fpi_usb_backend_arm_receive (ctx->fpi_usb_backend,
                                             ctx->generation, error);
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
void
goodix_device_context_complete_receive (GoodixDeviceContext *ctx,
                                         guint64 submit_generation,
                                         const guint8 *data, gsize length,
                                         const GError *error)
{
  g_return_if_fail (ctx != NULL);
  /* Host/test injection seam.  The real backend completion path invokes the
   * registered in-completed callback, which performs receive re-arming so that
   * both synthetic and production IN completions share one follow-up policy. */
  goodix_fpi_usb_backend_complete_receive (ctx->fpi_usb_backend,
                                           submit_generation, data, length,
                                           error);
}
#endif

#ifdef GOODIX_ENABLE_TEST_SEAMS
void
goodix_device_context_set_post_tls_await_finger_on (GoodixDeviceContext *ctx,
                                                    gboolean             awaiting)
{
  g_return_if_fail (ctx != NULL);
  if (ctx->post_tls_lifecycle != NULL)
    goodix_post_tls_lifecycle_set_framework_await_finger_on (
      ctx->post_tls_lifecycle, ctx->generation, awaiting);
}

void
goodix_device_context_set_secure_phase_observer (
  GoodixDeviceContext                    *ctx,
  GoodixDeviceContextSecurePhaseObserver  observer,
  gpointer                                user_data)
{
  g_return_if_fail (ctx != NULL);
  ctx->phase_observer = observer;
  ctx->phase_observer_data = user_data;
}
#endif

#ifdef GOODIX_ENABLE_TEST_SEAMS
gboolean
goodix_device_context_begin_operator_epoch (GoodixDeviceContext *ctx,
                                             GCancellable        *cancellable,
                                             GError             **error)
{
  if (ctx == NULL || cancellable == NULL || ctx->operator_epoch ||
      ctx->generation != 0 || ctx->secure_session != NULL ||
      ctx->post_tls_lifecycle != NULL || ctx->poisoned)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "Goodix operator epoch cannot begin");
      return FALSE;
    }

  ctx->generation_seq++;
  if (ctx->generation_seq == 0)
    ctx->generation_seq++;
  ctx->generation = ctx->generation_seq;
  ctx->terminal_fence = FALSE;
  ctx->operator_epoch = TRUE;
  memset (&ctx->pre_session_rx_sync_audit, 0,
          sizeof ctx->pre_session_rx_sync_audit);
  ctx->pre_session_rx_sync_out_count_at_pass = 0;
  g_set_object (&ctx->usb_cancellable, cancellable);
  if (!goodix_fpi_usb_backend_begin_generation (ctx->fpi_usb_backend,
                                                ctx->generation,
                                                ctx->usb_cancellable, error))
    {
      ctx->operator_epoch = FALSE;
      ctx->generation = 0;
      return FALSE;
    }
  goodix_usb_router_begin_generation (ctx->usb_router, ctx->generation);
  goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_ACTIVE);
  return TRUE;
}
#endif

gboolean
goodix_device_context_begin_pre_session_rx_sync (GoodixDeviceContext *ctx,
                                                  GError **error)
{
  g_autoptr(GError) local_error = NULL;

  if (ctx == NULL ||
      (!ctx->operator_epoch &&
       !(goodix_fpimage_device_is_production_usb (ctx->device) &&
         ctx->state == GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING)) ||
      ctx->generation == 0 ||
      ctx->terminal_fence || ctx->secure_session != NULL ||
      ctx->pre_session_rx_sync_audit.pre_session_rx_result !=
        GOODIX_PRE_SESSION_RX_SYNC_NOT_STARTED)
    {
      g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_CLOSED,
                           "pre-session RX sync cannot begin");
      return FALSE;
    }

  memset (&ctx->pre_session_rx_sync_audit, 0,
          sizeof ctx->pre_session_rx_sync_audit);
  ctx->pre_session_rx_sync_audit.pre_session_rx_sync_started = TRUE;
  ctx->pre_session_rx_sync_audit.pre_session_rx_result =
    GOODIX_PRE_SESSION_RX_SYNC_ACTIVE;
  ctx->pre_session_rx_sync_started_us = pre_session_rx_sync_now (ctx);
  if (!goodix_fpi_usb_backend_begin_pre_session_sync (
        ctx->fpi_usb_backend, ctx->generation, &local_error) ||
      !goodix_fpi_usb_backend_arm_pre_session_sync_receive (
        ctx->fpi_usb_backend, ctx->generation,
        GOODIX_PRE_SESSION_RX_QUIET_TIMEOUT_MS, &local_error))
    {
      pre_session_rx_sync_fail (ctx, local_error);
      g_propagate_error (error, g_steal_pointer (&local_error));
      return FALSE;
    }
  ctx->pre_session_rx_sync_audit.pre_session_rx_max_outstanding =
    goodix_fpi_usb_backend_get_outstanding (ctx->fpi_usb_backend);
  return TRUE;
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
GoodixPreSessionRxSyncResult
goodix_device_context_get_pre_session_rx_sync_result (GoodixDeviceContext *ctx)
{
  return ctx != NULL ? ctx->pre_session_rx_sync_audit.pre_session_rx_result :
    GOODIX_PRE_SESSION_RX_SYNC_FAIL_CLOSED;
}

void
goodix_device_context_get_pre_session_rx_sync_audit (
  GoodixDeviceContext         *ctx,
  GoodixPreSessionRxSyncAudit *audit)
{
  g_return_if_fail (ctx != NULL && audit != NULL);
  *audit = ctx->pre_session_rx_sync_audit;
  audit->first_protocol_out_after_rx_sync =
    audit->pre_session_rx_result == GOODIX_PRE_SESSION_RX_SYNC_PASS &&
    goodix_fpi_usb_backend_get_out_submit_count (ctx->fpi_usb_backend) >
      ctx->pre_session_rx_sync_out_count_at_pass;
}

const gchar *
goodix_pre_session_rx_sync_result_name (GoodixPreSessionRxSyncResult result)
{
  static const gchar *const names[] = {
    "NOT_STARTED", "ACTIVE", "PASS", "FAIL_CLOSED"
  };

  return (guint) result < G_N_ELEMENTS (names) ? names[result] : "INVALID";
}
#endif

#ifdef GOODIX_ENABLE_TEST_SEAMS
void
goodix_device_context_set_pre_session_rx_sync_clock (
  GoodixDeviceContext             *ctx,
  GoodixPreSessionRxSyncClockFunc  clock_func,
  gpointer                         user_data)
{
  g_return_if_fail (ctx != NULL);
  g_return_if_fail (
    ctx->pre_session_rx_sync_audit.pre_session_rx_result !=
      GOODIX_PRE_SESSION_RX_SYNC_ACTIVE);
  ctx->pre_session_rx_sync_clock = clock_func;
  ctx->pre_session_rx_sync_clock_data = user_data;
}

void
goodix_device_context_stop_operator_epoch (GoodixDeviceContext *ctx)
{
  if (ctx == NULL || !ctx->operator_epoch)
    return;
  goodix_device_context_set_terminal_fence (ctx);
  ctx->operator_epoch = FALSE;
  ctx->generation = 0;
  goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
}

gboolean
goodix_device_context_operator_epoch_is_drained (GoodixDeviceContext *ctx)
{
  return ctx != NULL && goodix_fpi_usb_backend_is_drained (
                          ctx->fpi_usb_backend);
}
#endif

/* --- Test/host-only context accessors and backend assertions --- */

#ifdef GOODIX_ENABLE_TEST_SEAMS
GoodixDeviceContextState
goodix_device_context_get_state (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->state : GOODIX_DEVICE_CONTEXT_STATE_CLOSED;
}

guint64
goodix_device_context_get_generation (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->generation : 0;
}

gboolean
goodix_device_context_get_terminal_fence (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->terminal_fence : TRUE;
}

gboolean
goodix_device_context_get_release_tail_complete (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->release_tail_complete : FALSE;
}

gboolean
goodix_device_context_get_fresh_down_table (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->fresh_down_table : FALSE;
}

gboolean
goodix_device_context_get_poisoned (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->poisoned : FALSE;
}

const GError *
goodix_device_context_get_terminal_error (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->terminal_error : NULL;
}

guint
goodix_device_context_get_backend_command_count (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->backend.total_command_count : 0;
}

guint
goodix_in_memory_backend_get_arm_count (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->backend.arm_count : 0;
}

guint
goodix_in_memory_backend_get_disarm_count (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->backend.disarm_count : 0;
}

guint
goodix_in_memory_backend_get_rearm_count (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->backend.rearm_count : 0;
}

const gchar *
goodix_in_memory_backend_get_last_command (GoodixDeviceContext *ctx)
{
  return ctx ? ctx->backend.last_command : NULL;
}

void
goodix_device_context_set_fresh_down_table (GoodixDeviceContext *ctx,
                                            gboolean             fresh)
{
  g_return_if_fail (ctx != NULL);
  ctx->fresh_down_table = !!fresh;
  goodix_device_context_maybe_rearm (ctx);
}

void
goodix_device_context_set_deactivation_held (GoodixDeviceContext *ctx,
                                              gboolean             held)
{
  g_return_if_fail (ctx != NULL);
  ctx->deactivation_held = !!held;
}
#endif

static void
goodix_device_context_finish_deactivation (GoodixDeviceContext *ctx)
{
  g_autoptr(GError) error = NULL;

  g_return_if_fail (ctx != NULL);
  g_return_if_fail (ctx->deactivation_pending);
  g_return_if_fail (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING);
  if (!goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
    return;

  /* Cancellation/owner loss can arrive between physical release and this
   * deferred completion. Never carry that invalidated context forward. */
  if (ctx->login_reusable &&
      (ctx->poisoned || ctx->terminal_fence ||
       fpi_device_action_is_cancelled (FP_DEVICE (ctx->device))))
    {
      ctx->login_reusable = FALSE;
      goodix_device_context_set_terminal_fence (ctx);
      ctx->backend_vtable->disarm (ctx, ctx->backend_user_data);
      ctx->generation = 0;
      ctx->deactivation_nonquiescent = TRUE;
    }
  ctx->deactivation_pending = FALSE;
  if (ctx->login_reusable)
    {
      goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
      ctx->login_deadline = g_timeout_add_seconds (8, login_deadline, ctx);
      g_message ("GOODIX_LOGIN_NO_MATCH attempt=%u limit=3 release=1 next_explicit_verify_required=1",
                 ctx->login_attempts);
      fpi_image_device_deactivate_complete (FP_IMAGE_DEVICE (ctx->device), NULL);
      return;
    }
  if (ctx->deactivation_nonquiescent)
    {
      ctx->poisoned = TRUE;
      goodix_device_context_set_state (ctx,
                                       GOODIX_DEVICE_CONTEXT_STATE_POISONED);
    }
  else
    {
      goodix_device_context_set_state (ctx,
                                       GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
      if (goodix_fpimage_device_is_production_usb (ctx->device) &&
          (ctx->production_action == FPI_DEVICE_ACTION_VERIFY ||
           ctx->production_action == FPI_DEVICE_ACTION_IDENTIFY) &&
          !goodix_fpimage_device_close_completed_capture_epoch (
            ctx->device, ctx->production_action, &error))
        {
          goodix_device_context_set_poisoned (ctx, error);
          goodix_device_context_set_state (
            ctx, GOODIX_DEVICE_CONTEXT_STATE_POISONED);
        }
      else if (ctx->production_action == FPI_DEVICE_ACTION_IDENTIFY &&
               (!ctx->production_identify_result_success ||
                ctx->production_identify_result_match))
        {
          /* A match ends the fprintd duplicate-check without enrollment.  A
           * processing failure must likewise never authorize the handoff. */
          ctx->production_identify_enroll_handoff_armed = FALSE;
          if (!ctx->production_identify_result_success)
            {
              ctx->poisoned = TRUE;
              goodix_device_context_set_state (
                ctx, GOODIX_DEVICE_CONTEXT_STATE_POISONED);
            }
        }
      else if (ctx->production_action == FPI_DEVICE_ACTION_VERIFY &&
               !ctx->production_verify_result_success)
        {
          /* fprintd immediately calls fp_device_verify() again for a
           * FP_DEVICE_RETRY report.  Keep that same D-Bus action fenced;
           * only a clean host match/no-match permits a later explicit call. */
          ctx->poisoned = TRUE;
          goodix_device_context_set_state (
            ctx, GOODIX_DEVICE_CONTEXT_STATE_POISONED);
        }
    }
  fpi_image_device_deactivate_complete (FP_IMAGE_DEVICE (ctx->device),
                                        g_steal_pointer (&error));
}

static gboolean
goodix_device_context_complete_deactivation_idle (gpointer user_data)
{
  GoodixFpImageDevice *self = GOODIX_FPIMAGE_DEVICE (user_data);
  GoodixDeviceContext *ctx = goodix_fpimage_device_peek_context (self);

  if (ctx == NULL)
    return G_SOURCE_REMOVE;

  ctx->deactivation_completion_scheduled = FALSE;
  if (ctx->deactivation_pending &&
      ctx->state == GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING &&
      goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
    goodix_device_context_finish_deactivation (ctx);

  return G_SOURCE_REMOVE;
}

void
goodix_device_context_complete_deactivation (GoodixDeviceContext *ctx)
{
  g_return_if_fail (ctx != NULL);
  g_return_if_fail (ctx->deactivation_pending);
  g_return_if_fail (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_DEACTIVATING);
  if (!goodix_fpi_usb_backend_is_drained (ctx->fpi_usb_backend))
    return;

  /* Finger-off may synchronously enter deactivation from inside the post-TLS
   * lifecycle.  A clean VERIFY/IDENTIFY completion frees that lifecycle, so
   * finish it from the next main-loop turn after the emitting stack has
   * unwound.  This also guarantees that a consumer callback can request the
   * next explicit action only after the previous epoch is fully released.
   * A protocol/backend poison may happen before any host matcher exists, so
   * that path must complete from drain without waiting for an outcome. */
  if (!ctx->deactivation_nonquiescent && !ctx->poisoned &&
      (goodix_fpimage_device_is_production_usb (ctx->device) || ctx->login_series) &&
      (ctx->production_action == FPI_DEVICE_ACTION_VERIFY ||
       ctx->production_action == FPI_DEVICE_ACTION_IDENTIFY))
    {
      if ((ctx->production_action == FPI_DEVICE_ACTION_IDENTIFY &&
           !ctx->production_identify_result_known) ||
          (ctx->production_action == FPI_DEVICE_ACTION_VERIFY &&
           !ctx->production_verify_result_known))
        return;
      if (!ctx->deactivation_completion_scheduled)
        {
          ctx->deactivation_completion_scheduled = TRUE;
          g_idle_add_full (
            G_PRIORITY_DEFAULT_IDLE,
            goodix_device_context_complete_deactivation_idle,
            g_object_ref (ctx->device), g_object_unref);
        }
      return;
    }

  goodix_device_context_finish_deactivation (ctx);
}

/* --- Shared production event delivery and test injection --- */

static void
emit_terminal (GoodixDeviceContext *ctx, GError *error)
{
  goodix_device_context_disconnect_cancel_handler (ctx);
  goodix_device_context_set_terminal_fence (ctx);
  goodix_device_context_set_poisoned (ctx, error);
  ctx->generation = 0;

  if (ctx->state == GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING)
    {
      goodix_device_context_set_state (ctx,
                                       GOODIX_DEVICE_CONTEXT_STATE_INACTIVE);
      fpi_image_device_activate_complete (FP_IMAGE_DEVICE (ctx->device), error);
    }
  else
    {
      goodix_device_context_set_state (ctx,
                                       GOODIX_DEVICE_CONTEXT_STATE_POISONED);
      fpi_image_device_session_error (FP_IMAGE_DEVICE (ctx->device), error);
    }
}

void
goodix_device_context_emit_arm_complete (GoodixDeviceContext *ctx,
                                         GError              *error)
{
  g_return_if_fail (ctx != NULL);

  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;

  if (ctx->state != GOODIX_DEVICE_CONTEXT_STATE_ACTIVATING)
    return;

  if (error != NULL)
    {
      emit_terminal (ctx, g_error_copy (error));
      return;
    }

  goodix_device_context_disconnect_cancel_handler (ctx);
  ctx->activation_completed = TRUE;
  goodix_device_context_set_state (ctx, GOODIX_DEVICE_CONTEXT_STATE_ACTIVE);
  fpi_image_device_activate_complete (FP_IMAGE_DEVICE (ctx->device), NULL);
}

void
goodix_device_context_emit_finger_down (GoodixDeviceContext *ctx)
{
  goodix_device_context_emit_finger_down_for_generation (
    ctx, ctx != NULL ? ctx->generation : 0);
}

void
goodix_device_context_emit_finger_down_for_generation (GoodixDeviceContext *ctx,
                                                       guint64 generation)
{
  g_return_if_fail (ctx != NULL);

  if (goodix_device_context_is_stale_or_fenced (ctx) ||
      generation != ctx->generation)
    return;

  fpi_image_device_report_finger_status (FP_IMAGE_DEVICE (ctx->device), TRUE);
}

void
goodix_device_context_emit_image_ready (GoodixDeviceContext *ctx,
                                        const uint16_t      *samples,
                                        size_t               sample_count)
{
#ifdef GOODIX_LIBFPRINT_CHICAGO
  g_return_if_fail (ctx != NULL);
  if (goodix_device_context_is_stale_or_fenced (ctx)) return;
  g_autoptr(GError) chicago_error = NULL;
  if (!context_chicago_image (ctx, NULL, samples, sample_count, &chicago_error))
    context_protocol_failure (ctx, chicago_error);
  return;
#endif

  GoodixFpImagePipeline *pipeline = NULL;
  GoodixFpImagePipelineResult result;
  FpImage *image;

  g_return_if_fail (ctx != NULL);

  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;

  result = goodix_fpimage_pipeline_new (samples, sample_count, &pipeline);
  if (result != GOODIX_FPIMAGE_PIPELINE_OK)
    {
      g_autoptr(GError) error = NULL;
      error = g_error_new (FP_DEVICE_ERROR, FP_DEVICE_ERROR_DATA_INVALID,
                           "Goodix fake image pipeline failed: %d", result);
      emit_terminal (ctx, g_steal_pointer (&error));
      return;
    }

  image = goodix_fpimage_pipeline_get_image (pipeline);
  g_assert (image != NULL);

  /* Transfer an independent reference to FpImageDevice; the pipeline keeps its own. */
  fpi_image_device_image_captured (FP_IMAGE_DEVICE (ctx->device),
                                   g_object_ref (image));

  goodix_fpimage_pipeline_free (pipeline);
}

#if defined(GOODIX_LIBFPRINT_SIGFM) && defined(GOODIX_ENABLE_TEST_SEAMS)
void
goodix_device_context_emit_sigfm_image_ready (GoodixDeviceContext *ctx,
                                              const uint16_t      *baseline,
                                              const uint16_t      *samples,
                                              size_t               sample_count)
{
  GoodixFpImagePipeline *pipeline = NULL;
  GoodixFpImagePipelineResult result;

  g_return_if_fail (ctx != NULL);
  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;
  result = goodix_fpimage_pipeline_new_sigfm (
    baseline, sample_count, samples, sample_count, &pipeline);
  if (result != GOODIX_FPIMAGE_PIPELINE_OK)
    {
      emit_terminal (ctx, g_error_new (
        FP_DEVICE_ERROR, FP_DEVICE_ERROR_DATA_INVALID,
        "Goodix SIGFM image pipeline failed: %d", result));
      return;
    }
  fpi_image_device_image_captured (
    FP_IMAGE_DEVICE (ctx->device),
    g_object_ref (goodix_fpimage_pipeline_get_image (pipeline)));
  goodix_fpimage_pipeline_free (pipeline);
}
#endif

void
goodix_device_context_emit_release_tail_complete (GoodixDeviceContext *ctx)
{
  g_return_if_fail (ctx != NULL);

  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;

  ctx->release_tail_complete = TRUE;
}

void
goodix_device_context_emit_finger_up_ready (GoodixDeviceContext *ctx)
{
  g_return_if_fail (ctx != NULL);

  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;

  /* Release tail must complete before libfprint sees finger-off. */
  if (!ctx->release_tail_complete)
    return;

  fpi_image_device_report_finger_status (FP_IMAGE_DEVICE (ctx->device), FALSE);
}

#ifdef GOODIX_ENABLE_TEST_SEAMS
void
goodix_device_context_emit_cancelled (GoodixDeviceContext *ctx)
{
  g_return_if_fail (ctx != NULL);

  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;

  /* Cancellation is modelled as a terminal fence, not a device-side command. */
  goodix_device_context_set_terminal_fence (ctx);
  ctx->generation = 0;
}

void
goodix_device_context_emit_terminal_error (GoodixDeviceContext *ctx,
                                           GError              *error)
{
  g_return_if_fail (ctx != NULL);
  g_return_if_fail (error != NULL);

  if (goodix_device_context_is_stale_or_fenced (ctx))
    return;

  emit_terminal (ctx, g_error_copy (error));
}
#endif
